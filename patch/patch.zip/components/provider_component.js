// GENERATED CODE - DO NOT EDIT
// 由 ui_component_generator 从 lib/components/provider_component.dart 自动生成
// 重新生成：dart run build_runner build

import { CounterVm } from '../model/counter_vm.js';
import { NetworkVm } from '../model/network_vm.js';
import { ChangeNotifierProvider, Consumer, MultiProvider } from '../provider.js';
import { __h } from '../flutter.js';

// 组件 ProviderCard
export class ProviderCard {
  constructor() {
    this._modelA = new CounterVm({});
    this._modelB = new NetworkVm({});
  }
  _incA() {
    this._modelA.inc();
  }
  _resetA() {
    this._modelA.reset();
  }
  _loadUser() {
    this._modelB.loadUserInfo({"h": 1});
  }
  build() {
    return __h('Card', {}, [
        __h('Padding', {
            "padding": {
              "left": 16.0,
              "top": 16.0,
              "right": 16.0,
              "bottom": 16.0
            }
          }, [
            __h(MultiProvider, {
                "providers": [
                  __h(ChangeNotifierProvider, {
                      "model": "CounterVm",
                      "create": this._modelA
                    }),
                  __h(ChangeNotifierProvider, {
                      "model": "NetworkVm",
                      "value": this._modelB
                    })
                ],
                "child": __h('Column', {
                    "mainAxisSize": "min"
                  }, [
                    this._buildText(),
                    this._modelA.buildText(),
                    __h(Consumer, {
                        "model": "CounterVm",
                        "builder": "_consumerBuilder0"
                      }),
                    __h('Text', {
                        "data": "MultiProvider · 两个模型各自局部重建"
                      }),
                    __h('SizedBox', {
                        "height": 8
                      }),
                    __h(Consumer, {
                        "model": "NetworkVm",
                        "builder": "_consumerBuilder1"
                      }),
                    __h('Row', {
                        "mainAxisAlignment": "center"
                      }, [
                        __h('Button', {
                            "kind": "elevated",
                            "label": "加载用户信息",
                            "event": this.__bind("_loadUser")
                          })
                      ]),
                    __h('SizedBox', {
                        "height": 8
                      }),
                    __h(Consumer, {
                        "model": "CounterVm",
                        "builder": "_consumerBuilder2"
                      }),
                    __h('Row', {
                        "mainAxisAlignment": "center"
                      }, [
                        __h('Button', {
                            "kind": "elevated",
                            "label": "B +1",
                            "event": this.__bind("_incA")
                          }),
                        __h('SizedBox', {
                            "width": 12
                          }),
                        __h('Button', {
                            "kind": "elevated",
                            "label": "B Reset",
                            "event": this.__bind("_resetA")
                          })
                      ])
                  ])
              })
          ])
      ]);
  }
  _buildText() {
    return __h('Text', {
        "data": "test 1"
      });
  }
  _buildBadge() {
    var label = "";
    switch (this._modelA.count) {
      case 0:
        label = "B·零";
        break;
      case 1:
      case 2:
        label = "B·少";
        break;
      case 3:
      case 4:
        label = "B·多";
        break;
      default:
        label = "B·爆表";
      break;
    }
    var dots = "";
    for (let i = 0; (i < this._modelA.count); (i++)) {
      dots = __str(dots) + "·";
    }
    return __h('Text', {
        "data": __str(label) + __str(dots)
      });
  }
  dispose() {
    this._modelB.dispose();
  }
  _consumerBuilder0(value) {
      return this._buildBadge();
  }
  _consumerBuilder1(value) {
      return __h('Text', {
        "data": "加载用户信息：",
        "style": {
          "fontSize": 22,
          "fontWeight": "bold",
          "color": '#2196F3'
        }
      });
  }
  _consumerBuilder2(value) {
      return __h('Text', {
        "data": "B = " + __str(value.count),
        "style": {
          "fontSize": 22,
          "fontWeight": "bold",
          "color": '#4CAF50'
        }
      });
  }
}

