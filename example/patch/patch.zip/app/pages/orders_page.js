// GENERATED CODE - DO NOT EDIT
// 由 hot_patch_generator 从 lib/app/pages/orders_page.dart 自动生成
// 重新生成：dart run build_runner build

import { OrdersVm } from '../vm/orders_vm.js';
import { Order } from '../model/app_models.js';
import { AppRouter } from '../../base/app_router.js';
import { LoadErrorView } from '../widgets/load_error_view.js';
import { MiniButton } from 'detail_pages.js';
import { kBrand, kPrice } from 'detail_pages.js';
import { Axis, BorderRadius, BoxDecoration, BoxFit, Center, CircularProgressIndicator, ClipRRect, Color, Colors, Column, Container, CrossAxisAlignment, Divider, EdgeInsets, Expanded, FontWeight, GestureDetector, Image, LinearProgressIndicator, ListView, Padding, Row, SafeArea, SingleChildScrollView, SizedBox, Spacer, StatefulWidget, StatelessWidget, Text, TextOverflow, TextStyle } from '../../flutter.js';
import { ChangeNotifierProvider } from '../../provider.js';

// 组件 OrdersPage
export class OrdersPage extends StatelessWidget {
  constructor(args) {
    super(args);
    this.__applyProps(args);
  }
  __applyProps(args) {
    this.initialStatus = (args && args.initialStatus !== undefined) ? args.initialStatus : null;
  }
  build(context) {
    return new ChangeNotifierProvider({
      "create": (_) => { return (() => { const _t = new OrdersVm({initialStatus: this.initialStatus}); _t.load(); return _t; })(); },
      "child": (this.__k0 || (this.__k0 = new OrdersView({}))),
      "typeArguments": [
        "OrdersVm"
      ]
    });
  }
}

// 组件 OrdersView
export class OrdersView extends StatefulWidget {
  constructor(args) {
    super(args);
  }
  _statusColor(status) {
    return (() => { switch (status) {
        case "待付款": return kPrice;
        case "已完成": return new Color({value: 0xFF8B909A});
        default: return kBrand;
      } })();
  }
  _buildOrderItem(context, i) {
    var orders = context.read({ typeArguments: ["OrdersVm"] }).orders;
    var o = orders[i];
    return new _OrderCard({
      "order": o,
      "statusColor": this._statusColor(o.status),
      "onOpen": () => AppRouter.openOrder(o.no)
    });
  }
  build(context) {
    var vm = context.watch({ typeArguments: ["OrdersVm"] });
    var feed = vm.feed;
    if ((feed == null)) {
      var error = vm.feedError;
      if ((error != null)) {
        return new LoadErrorView({
          "message": error,
          "onRetry": (...__a) => vm.retry(...__a)
        });
      }
      return (this.__k0 || (this.__k0 = new Center({
        "child": new CircularProgressIndicator({})
      })));
    }
    return new Column({
      "crossAxisAlignment": CrossAxisAlignment.stretch,
      "children": [
        new Container({
          "color": Colors.white,
          "child": new SafeArea({
            "bottom": false,
            "child": new Padding({
              "padding": (this.__k1 || (this.__k1 = EdgeInsets.fromLTRB({
                "bottom": 10,
                "left": 8,
                "right": 8,
                "top": 6
              }))),
              "child": new SingleChildScrollView({
                "scrollDirection": Axis.horizontal,
                "child": new Row({
                  "children": [
                    ...(() => { var out = []; for (let s of feed.statuses) { out.push.apply(out, [new Padding({
                            "padding": (this.__k2 || (this.__k2 = EdgeInsets.symmetric({
                              "horizontal": 4
                            }))),
                            "child": new GestureDetector({
                              "onTap": () => { return vm.pickStatus(s); },
                              "child": new Container({
                                "padding": (this.__k3 || (this.__k3 = EdgeInsets.symmetric({
                                  "horizontal": 13,
                                  "vertical": 6
                                }))),
                                "decoration": new BoxDecoration({
                                  "color": (vm.status == s) ? (this.__k4 || (this.__k4 = new Color({
                                    "value": 0xFFE8F2FF
                                  }))) : Colors.white,
                                  "borderRadius": BorderRadius.circular({
                                    "radius": 15
                                  })
                                }),
                                "child": new Text({
                                  "style": new TextStyle({
                                    "fontSize": 13,
                                    "fontWeight": (vm.status == s) ? FontWeight.w700 : FontWeight.w500,
                                    "color": (vm.status == s) ? kBrand : (this.__k5 || (this.__k5 = new Color({
                                      "value": 0xFF5C6270
                                    })))
                                  }),
                                  "data": s
                                })
                              })
                            })
                          })]); } return out; })()
                  ]
                })
              })
            })
          })
        }),
        ...(vm.listLoading ? [(this.__k6 || (this.__k6 = new LinearProgressIndicator({
            "minHeight": 2
          })))] : []),
        new Expanded({
          "child": (vm.orders == null) ? (vm.ordersError != null) ? new LoadErrorView({
            "message": vm.ordersError,
            "onRetry": (...__a) => vm.retry(...__a)
          }) : (this.__k0 || (this.__k0 = new Center({
            "child": new CircularProgressIndicator({})
          }))) : vm.orders.isEmpty ? (this.__k7 || (this.__k7 = new Center({
            "child": new Text({
              "style": new TextStyle({
                "fontSize": 13,
                "color": new Color({
                  "value": 0xFF98A0AC
                })
              }),
              "data": "该状态下暂无订单"
            })
          }))) : ListView.separated({
            "padding": (this.__k8 || (this.__k8 = EdgeInsets.fromLTRB({
              "bottom": 20,
              "left": 12,
              "right": 12,
              "top": 12
            }))),
            "itemCount": vm.orders.length,
            "separatorBuilder": (context, index) => (this.__k9 || (this.__k9 = new SizedBox({
              "height": 10
            }))),
            "itemBuilder": (__a0, __a1) => this._buildOrderItem(__a0, __a1)
          })
        })
      ]
    });
  }
}

// 组件 _OrderCard
export class _OrderCard extends StatelessWidget {
  constructor(args) {
    super(args);
    this.__applyProps(args);
  }
  __applyProps(args) {
    this.order = (args && args.order !== undefined) ? args.order : null;
    this.statusColor = (args && args.statusColor !== undefined) ? args.statusColor : null;
    this.onOpen = (args && args.onOpen !== undefined) ? args.onOpen : null;
  }
  build(context) {
    var pending = (this.order.status == "待付款");
    return new GestureDetector({
      "onTap": this.onOpen,
      "child": new Container({
        "decoration": new BoxDecoration({
          "color": Colors.white,
          "borderRadius": BorderRadius.circular({
            "radius": 14
          })
        }),
        "child": new Column({
          "children": [
            new Padding({
              "padding": (this.__k0 || (this.__k0 = EdgeInsets.fromLTRB({
                "bottom": 10,
                "left": 14,
                "right": 14,
                "top": 12
              }))),
              "child": new Row({
                "children": [
                  new Text({
                    "style": (this.__k1 || (this.__k1 = new TextStyle({
                      "color": new Color({
                        "value": 0xFF8B909A
                      }),
                      "fontSize": 12
                    }))),
                    "data": "订单号 " + this.order.no
                  }),
                  (this.__k2 || (this.__k2 = new Spacer({}))),
                  new Text({
                    "style": new TextStyle({
                      "fontSize": 12.5,
                      "fontWeight": FontWeight.w700,
                      "color": this.statusColor
                    }),
                    "data": this.order.status
                  })
                ]
              })
            }),
            (this.__k3 || (this.__k3 = new Divider({
              "color": new Color({
                "value": 0xFFF0F2F6
              }),
              "height": 1
            }))),
            new Padding({
              "padding": (this.__k4 || (this.__k4 = EdgeInsets.all({
                "value": 12
              }))),
              "child": new Row({
                "crossAxisAlignment": CrossAxisAlignment.start,
                "children": [
                  new ClipRRect({
                    "borderRadius": BorderRadius.circular({
                      "radius": 10
                    }),
                    "child": Image.asset({
                      "width": 66,
                      "height": 66,
                      "fit": BoxFit.cover,
                      "errorBuilder": (context, e, s) => new Container({
                        "width": 66,
                        "height": 66,
                        "color": (this.__k5 || (this.__k5 = new Color({
                          "value": 0xFFE8EBF0
                        })))
                      }),
                      "name": this.order.img
                    })
                  }),
                  (this.__k6 || (this.__k6 = new SizedBox({
                    "width": 11
                  }))),
                  new Expanded({
                    "child": new Column({
                      "crossAxisAlignment": CrossAxisAlignment.start,
                      "children": [
                        new Text({
                          "maxLines": 1,
                          "overflow": TextOverflow.ellipsis,
                          "style": (this.__k7 || (this.__k7 = new TextStyle({
                            "fontSize": 14,
                            "fontWeight": FontWeight.w600
                          }))),
                          "data": this.order.title
                        }),
                        (this.__k8 || (this.__k8 = new SizedBox({
                          "height": 5
                        }))),
                        new Text({
                          "maxLines": 1,
                          "overflow": TextOverflow.ellipsis,
                          "style": (this.__k9 || (this.__k9 = new TextStyle({
                            "color": new Color({
                              "value": 0xFF8B909A
                            }),
                            "fontSize": 11.5
                          }))),
                          "data": this.order.spec
                        }),
                        (this.__k10 || (this.__k10 = new SizedBox({
                          "height": 6
                        }))),
                        (this.__k11 || (this.__k11 = new Text({
                          "data": "×1",
                          "style": new TextStyle({
                            "fontSize": 11,
                            "color": new Color({
                              "value": 0xFFA3A9B4
                            })
                          })
                        })))
                      ]
                    })
                  })
                ]
              })
            }),
            (this.__k3 || (this.__k3 = new Divider({
              "color": new Color({
                "value": 0xFFF0F2F6
              }),
              "height": 1
            }))),
            new Padding({
              "padding": (this.__k12 || (this.__k12 = EdgeInsets.fromLTRB({
                "bottom": 12,
                "left": 14,
                "right": 12,
                "top": 10
              }))),
              "child": new Row({
                "children": [
                  (this.__k13 || (this.__k13 = new Text({
                    "data": "合计 ",
                    "style": new TextStyle({
                      "fontSize": 12.5,
                      "color": new Color({
                        "value": 0xFF5C6270
                      })
                    })
                  }))),
                  new Text({
                    "style": (this.__k14 || (this.__k14 = new TextStyle({
                      "color": kPrice,
                      "fontSize": 16,
                      "fontWeight": FontWeight.w700
                    }))),
                    "data": "￥" + this.order.price
                  }),
                  (this.__k2 || (this.__k2 = new Spacer({}))),
                  ...(pending ? [new MiniButton({
                      "label": "取消",
                      "onTap": () => AppRouter.toast("已取消订单 " + this.order.no + "（演示）")
                    }), (this.__k15 || (this.__k15 = new SizedBox({
                      "width": 8
                    }))), new MiniButton({
                      "label": "去支付",
                      "primary": true,
                      "onTap": this.onOpen
                    })] : [new MiniButton({
                      "label": "查看详情",
                      "onTap": this.onOpen
                    })])
                ]
              })
            })
          ]
        })
      })
    });
  }
}

