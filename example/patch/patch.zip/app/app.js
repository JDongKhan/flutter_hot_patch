// GENERATED CODE - DO NOT EDIT
// 由 hot_patch_generator 从 lib/app/app.dart 自动生成
// 重新生成：dart run build_runner build

import { HomePage } from 'pages/home_page.js';
import { CommunityPage } from 'pages/community_page.js';
import { OrdersPage } from 'pages/orders_page.js';
import { MinePage } from 'pages/mine_page.js';
import { BottomNavigationBar, BottomNavigationBarItem, BottomNavigationBarType, Color, Colors, Icon, Icons, NeverScrollableScrollPhysics, Scaffold, StatefulWidget, TabBarView, TabController } from '../flutter.js';

// 组件 AppShell
export class AppShell extends StatefulWidget {
  constructor(args) {
    super(args);
  }
  build(context) {
    return new AppSubContent({});
  }
}

// 组件 AppSubContent
export class AppSubContent extends StatefulWidget {
  constructor(args) {
    super(args);
    this._tab = new TabController({length: 4, vsync: this});
    this._index = 0;
  }
  initState() {
    super.initState();
    print("--AppSubContent initState");
    this._tab.addListener(() => { this.setState(() => { this._index = this._tab.index; }); });
  }
  dispose() {
    this._tab.dispose();
    super.dispose();
  }
  _openTab(index) {
    this.setState(() => { this._index = index; });
    this._tab.animateTo(index);
  }
  didUpdateWidget(oldWidget) {
    super.didUpdateWidget(oldWidget);
    print("--AppSubContent didUpdateWidget");
  }
  build(context) {
    print("--AppSubContent build");
    return new Scaffold({
      "backgroundColor": (this.__k0 || (this.__k0 = new Color({
        "value": 0xFFF4F5F7
      }))),
      "body": new TabBarView({
        "controller": this._tab,
        "physics": (this.__k1 || (this.__k1 = new NeverScrollableScrollPhysics({}))),
        "children": [
          (this.__k2 || (this.__k2 = new HomePage({}))),
          (this.__k3 || (this.__k3 = new CommunityPage({}))),
          (this.__k4 || (this.__k4 = new OrdersPage({}))),
          (this.__k5 || (this.__k5 = new MinePage({})))
        ]
      }),
      "bottomNavigationBar": new BottomNavigationBar({
        "currentIndex": this._index,
        "onTap": this.__bindFn(0, [], (...__a) => this._openTab(...__a)),
        "type": BottomNavigationBarType.fixed,
        "backgroundColor": Colors.white,
        "selectedItemColor": (this.__k6 || (this.__k6 = new Color({
          "value": 0xFF0E7AFB
        }))),
        "unselectedItemColor": (this.__k7 || (this.__k7 = new Color({
          "value": 0xFF98A0AC
        }))),
        "selectedFontSize": 11,
        "unselectedFontSize": 11,
        "items": [
          new BottomNavigationBarItem({
            "icon": new Icon({
              "icon": Icons.home
            }),
            "label": "首页"
          }),
          new BottomNavigationBarItem({
            "icon": new Icon({
              "icon": Icons.article
            }),
            "label": "社区"
          }),
          new BottomNavigationBarItem({
            "icon": new Icon({
              "icon": Icons.shopping_cart
            }),
            "label": "订单"
          }),
          new BottomNavigationBarItem({
            "icon": new Icon({
              "icon": Icons.person
            }),
            "label": "我的"
          })
        ]
      })
    });
  }
}

