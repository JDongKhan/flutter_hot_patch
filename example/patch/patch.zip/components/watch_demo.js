// GENERATED CODE - DO NOT EDIT
// 由 hot_patch_generator 从 lib/components/watch_demo.dart 自动生成
// 重新生成：dart run build_runner build

import { CounterVm } from '../model/counter_vm.js';
import { Builder, Card, Colors, Column, EdgeInsets, ElevatedButton, FontWeight, MainAxisAlignment, MainAxisSize, Padding, Row, SizedBox, StatefulWidget, Text, TextStyle } from '../flutter.js';
import { ChangeNotifierProvider } from '../provider.js';

// 组件 WatchDemo
export class WatchDemo extends StatefulWidget {
  constructor(args) {
    super(args);
  }
  build(context) {
    return new Card({
      "child": new Padding({
        "padding": (this.__k0 || (this.__k0 = EdgeInsets.all({
          "value": 16
        }))),
        "child": new ChangeNotifierProvider({
          "create": (_) => { return new CounterVm(); },
          "child": new Column({
            "mainAxisSize": MainAxisSize.min,
            "children": [
              new Builder({
                "builder": (context) => {
                  var model = context.watch({ typeArguments: {"T": "CounterVm"} });
                  return new Column({
                    "mainAxisSize": MainAxisSize.min,
                    "children": [
                      (this.__k1 || (this.__k1 = new Text({
                        "data": "context.watch<CounterModel>"
                      }))),
                      new Text({
                        "style": (this.__k2 || (this.__k2 = new TextStyle({
                          "color": Colors.deepOrange,
                          "fontSize": 22,
                          "fontWeight": FontWeight.bold
                        }))),
                        "data": "count = " + model.count
                      }),
                      (this.__k3 || (this.__k3 = new SizedBox({
                        "height": 8
                      }))),
                      new Row({
                        "mainAxisAlignment": MainAxisAlignment.center,
                        "children": [
                          new ElevatedButton({
                            "onPressed": () => { return model.inc(); },
                            "child": (this.__k4 || (this.__k4 = new Text({
                              "data": "+1"
                            })))
                          }),
                          (this.__k5 || (this.__k5 = new SizedBox({
                            "width": 12
                          }))),
                          new ElevatedButton({
                            "onPressed": () => { context.read({ typeArguments: {"T": "CounterVm"} }).reset(); },
                            "child": (this.__k6 || (this.__k6 = new Text({
                              "data": "Reset"
                            })))
                          })
                        ]
                      })
                    ]
                  });
                }
              }),
              (this.__k7 || (this.__k7 = new SizedBox({
                "height": 12
              }))),
              (this.__k8 || (this.__k8 = new WatchCountLabel({})))
            ]
          }),
          "typeArguments": {"T": "CounterVm"}
        })
      })
    });
  }
}

// 组件 WatchCountLabel
export class WatchCountLabel extends StatefulWidget {
  constructor(args) {
    super(args);
  }
  build(context) {
    var model = context.watch({ typeArguments: {"T": "CounterVm"} });
    return new Text({
      "style": (this.__k0 || (this.__k0 = new TextStyle({
        "color": Colors.blue,
        "fontSize": 16
      }))),
      "data": "another State: count = " + model.count
    });
  }
}

