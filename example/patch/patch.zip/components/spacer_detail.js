// GENERATED CODE - DO NOT EDIT
// 由 hot_patch_generator 从 lib/components/spacer_detail.dart 自动生成
// 重新生成：dart run build_runner build

import { Alignment, Border, BorderRadius, BoxDecoration, Colors, Column, Container, CrossAxisAlignment, EdgeInsets, ElevatedButton, FontWeight, MainAxisSize, OutlinedButton, Row, SizedBox, Spacer, StatefulWidget, Text, TextStyle, Wrap } from '../flutter.js';

// 组件 SpacerDetail
export class SpacerDetail extends StatefulWidget {
  constructor(args) {
    super(args);
    this._flex = 1;
  }
  build(context) {
    return new Column({
      "mainAxisSize": MainAxisSize.min,
      "crossAxisAlignment": CrossAxisAlignment.stretch,
      "children": [
        new Container({
          "color": Colors.grey.shade100,
          "padding": (this.__k0 || (this.__k0 = EdgeInsets.all({
            "value": 12
          }))),
          "child": new Column({
            "crossAxisAlignment": CrossAxisAlignment.start,
            "children": [
              new Text({
                "style": (this.__k1 || (this.__k1 = new TextStyle({
                  "fontSize": 13,
                  "fontWeight": FontWeight.bold
                }))),
                "data": "Row：Spacer(flex: " + this._flex + ") 在中间，右侧 1 份"
              }),
              (this.__k2 || (this.__k2 = new SizedBox({
                "height": 8
              }))),
              new Row({
                "children": [
                  new Container({
                    "width": 40,
                    "height": 40,
                    "color": Colors.indigo,
                    "alignment": Alignment.center,
                    "child": (this.__k3 || (this.__k3 = new Text({
                      "data": "A",
                      "style": new TextStyle({
                        "color": Colors.white
                      })
                    })))
                  }),
                  new Spacer({
                    "flex": this._flex
                  }),
                  new Container({
                    "width": 40,
                    "height": 40,
                    "color": Colors.teal,
                    "alignment": Alignment.center,
                    "child": (this.__k4 || (this.__k4 = new Text({
                      "data": "B",
                      "style": new TextStyle({
                        "color": Colors.white
                      })
                    })))
                  }),
                  (this.__k5 || (this.__k5 = new Spacer({}))),
                  new Container({
                    "width": 40,
                    "height": 40,
                    "color": Colors.orange,
                    "alignment": Alignment.center,
                    "child": (this.__k6 || (this.__k6 = new Text({
                      "data": "C",
                      "style": new TextStyle({
                        "color": Colors.white
                      })
                    })))
                  })
                ]
              }),
              (this.__k2 || (this.__k2 = new SizedBox({
                "height": 8
              }))),
              new Wrap({
                "spacing": 12,
                "runSpacing": 8,
                "children": [
                  new OutlinedButton({
                    "onPressed": () => { this.setState(() => {
                        this._flex = 1;
                      }); },
                    "child": (this.__k7 || (this.__k7 = new Text({
                      "data": "flex 1"
                    })))
                  }),
                  new OutlinedButton({
                    "onPressed": () => { this.setState(() => {
                        this._flex = 2;
                      }); },
                    "child": (this.__k8 || (this.__k8 = new Text({
                      "data": "flex 2"
                    })))
                  }),
                  new OutlinedButton({
                    "onPressed": () => { this.setState(() => {
                        this._flex = 3;
                      }); },
                    "child": (this.__k9 || (this.__k9 = new Text({
                      "data": "flex 3"
                    })))
                  })
                ]
              })
            ]
          })
        }),
        (this.__k10 || (this.__k10 = new SizedBox({
          "height": 12
        }))),
        new SizedBox({
          "height": 220,
          "child": new Container({
            "padding": (this.__k0 || (this.__k0 = EdgeInsets.all({
              "value": 12
            }))),
            "decoration": new BoxDecoration({
              "border": Border.all({
                "color": Colors.grey.shade300
              }),
              "borderRadius": BorderRadius.circular({
                "radius": 12
              })
            }),
            "child": new Column({
              "crossAxisAlignment": CrossAxisAlignment.stretch,
              "children": [
                (this.__k11 || (this.__k11 = new Text({
                  "data": "Column：中间一个 Spacer()，底部按钮被顶到底",
                  "style": new TextStyle({
                    "fontSize": 13,
                    "color": Colors.black54
                  })
                }))),
                (this.__k5 || (this.__k5 = new Spacer({}))),
                new ElevatedButton({
                  "onPressed": () => {},
                  "child": (this.__k12 || (this.__k12 = new Text({
                    "data": "贴底按钮（由 Spacer 顶下来）"
                  })))
                })
              ]
            })
          })
        })
      ]
    });
  }
}

