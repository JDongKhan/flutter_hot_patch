// GENERATED CODE - DO NOT EDIT
// 由 hot_patch_generator 从 lib/base/app_router.dart 自动生成
// 重新生成：dart run build_runner build

import { appToast } from '../app/pages/detail_pages.js';
import '../flutter.js';

// 模型 AppRouter
export class AppRouter {
  constructor() {
  }
  static openHeroTarget(tag, label) {
    return _app_host_.invoke("openHeroTarget", Array.prototype.slice.call(arguments));
  }
  static openSearch() {
    return _app_host_.invoke("openSearch", Array.prototype.slice.call(arguments));
  }
  static openSpot(id) {
    return _app_host_.invoke("openSpot", Array.prototype.slice.call(arguments));
  }
  static async openCityPicker(current) {
    return _app_host_.invoke("openCityPicker", Array.prototype.slice.call(arguments));
  }
  static async openChannel(title, emoji) {
    return _app_host_.invoke("openChannel", Array.prototype.slice.call(arguments));
  }
  static openNotifications() {
    return _app_host_.invoke("openNotifications", Array.prototype.slice.call(arguments));
  }
  static openPost(id) {
    return _app_host_.invoke("openPost", Array.prototype.slice.call(arguments));
  }
  static openResource(id) {
    return _app_host_.invoke("openResource", Array.prototype.slice.call(arguments));
  }
  static openOrder(no) {
    return _app_host_.invoke("openOrder", Array.prototype.slice.call(arguments));
  }
  static async pop() {
    return _app_host_.invoke("pop", Array.prototype.slice.call(arguments));
  }
  static async openLogin() {
    return _app_host_.invoke("openLogin", Array.prototype.slice.call(arguments));
  }
  static async openOrders() {
    return _app_host_.invoke("openOrders", Array.prototype.slice.call(arguments));
  }
  static async openWidgetShowcase() {
    return _app_host_.invoke("openWidgetShowcase", Array.prototype.slice.call(arguments));
  }
  static async openDemoList() {
    return _app_host_.invoke("openDemoList", Array.prototype.slice.call(arguments));
  }
  static async toast(msg) {
    return _app_host_.invoke("toast", Array.prototype.slice.call(arguments));
  }
}

