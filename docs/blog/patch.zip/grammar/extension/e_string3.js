export const TestString3=registerExtension("String",{log3:function(){print("项目内日志3")}},{id:"lib/grammar/extension/e_string3.dart#TestString3"});
//# sourceMappingURL=e_string3.js.map