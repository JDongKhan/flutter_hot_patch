export const TagB=registerExtension("String",{tag:function(){return"B"}},{id:"lib/grammar/extension/e_tag.dart#TagB"});
//# sourceMappingURL=e_tag.js.map