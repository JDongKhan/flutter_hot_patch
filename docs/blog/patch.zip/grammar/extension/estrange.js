export class Estrange{constructor(){}log(){print("项目内日志 类")}}
//# sourceMappingURL=estrange.js.map