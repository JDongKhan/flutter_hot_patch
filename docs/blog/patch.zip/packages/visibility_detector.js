import{Component}from"../flutter.js";export class VisibilityDetector extends Component{static __fnProps=["onVisibilityChanged"]}
//# sourceMappingURL=visibility_detector.js.map