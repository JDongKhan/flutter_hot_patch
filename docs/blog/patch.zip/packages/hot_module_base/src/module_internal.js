export const modulePublicTag="public-tag";export const moduleHiddenTag="hidden-tag";
//# sourceMappingURL=module_internal.js.map