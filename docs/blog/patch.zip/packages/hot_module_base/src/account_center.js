export class AccountCenter{constructor(){}static async getUserName(){return _app_host_.invoke("getUserName",Array.prototype.slice.call(arguments))}}
//# sourceMappingURL=account_center.js.map