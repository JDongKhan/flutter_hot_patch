export class Network{constructor(){}static async post(__o){return _app_host_.invoke("post",arguments.length?arguments[0]:{})}}
//# sourceMappingURL=network.js.map