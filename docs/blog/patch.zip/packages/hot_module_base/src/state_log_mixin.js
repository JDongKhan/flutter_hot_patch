export class StateLogMixin{constructor(args){this.__ta=args&&args.typeArguments||{}}increment(count){return count+1}}
//# sourceMappingURL=state_log_mixin.js.map