export class HomeFloor{constructor(o){this.__applyProps(o)}__applyProps(o){this.type=o&&void 0!==o.type?o.type:"",this.vm=o&&void 0!==o.vm?o.vm:0}}
//# sourceMappingURL=floor_base.js.map