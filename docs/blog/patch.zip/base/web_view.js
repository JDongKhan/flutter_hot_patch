import"../flutter.js";export class WebView{constructor(){}static async open(t,e){return _app_host_.invoke("open",Array.prototype.slice.call(arguments))}}
//# sourceMappingURL=web_view.js.map