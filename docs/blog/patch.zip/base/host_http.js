import"../packages/dio.js";export class HostHttp{constructor(){}static async get(t){return _app_host_.invoke("httpGet",Array.prototype.slice.call(arguments))}}
//# sourceMappingURL=host_http.js.map