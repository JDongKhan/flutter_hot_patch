// CLI 行为探针：输出即断言，故允许 print。
// ignore_for_file: avoid_print, unnecessary_this

import 'dart:async';

/// Dart 侧行为基线：与 `stream_probe.mjs` 的用例逐条对应。
///
/// 用法（在 example/ 下）：
///   fvm dart tool/behavior_probe/stream_probe.dart
///   node tool/behavior_probe/stream_probe.mjs patch
///
/// 两份输出必须逐字一致；改 Stream / extension 语义时两边都要跑。
Future<void> main() async {
  // A 广播 pause：add / addError / close 期间缓冲，resume 后按序补发；close 等消费。
  {
    final log = <String>[];
    final c = StreamController<int>.broadcast();
    final sub = c.stream.listen(
      (v) => log.add('data:$v'),
      onError: (Object e) => log.add('err:$e'),
      onDone: () => log.add('done'),
    );
    sub.pause();
    c.add(1);
    c.addError('e1');
    var closed = false;
    unawaited(c.close().then((_) => closed = true));
    log.add('afterCloseCall');
    await Future<void>.delayed(const Duration(milliseconds: 20));
    log.add('closeDone=$closed');
    sub.resume();
    await Future<void>.delayed(const Duration(milliseconds: 30));
    print('A ${log.join('|')}');
  }

  // B 单订阅：首个订阅前 add 的事件被缓冲。
  {
    final got = <int>[];
    final c = StreamController<int>();
    c.add(1);
    await Future<void>.delayed(Duration.zero);
    c.stream.listen(got.add);
    await Future<void>.delayed(const Duration(milliseconds: 20));
    print('B ${got.join(',')}');
  }

  // C map：上游 error 不终止下游流。
  {
    final out = <Object>[];
    final c = StreamController<int>();
    c.stream.map((x) => x * 2).listen(
          out.add,
          onError: (Object e) => out.add('err:$e'),
          onDone: () => out.add('done'),
        );
    c.add(1);
    c.addError('boom');
    c.add(2);
    unawaited(c.close());
    await Future<void>.delayed(const Duration(milliseconds: 30));
    print('C ${out.join(',')}');
  }

  // D cancelOnError：提供 onError 时依然取消。
  {
    final out = <Object>[];
    final c = StreamController<int>();
    c.stream.listen(
      out.add,
      onError: (Object e) => out.add('err'),
      cancelOnError: true,
    );
    c.add(1);
    c.addError('x');
    c.add(2);
    await Future<void>.delayed(const Duration(milliseconds: 20));
    print('D ${out.join(',')}');
  }

  // E await for break：取消传播到上游（只生产一项）。
  {
    var produced = 0;
    Stream<int> gen() async* {
      for (var i = 0; i < 20; i++) {
        produced++;
        yield i;
      }
    }

    await for (final _ in gen()) {
      break;
    }
    await Future<void>.delayed(const Duration(milliseconds: 30));
    print('E $produced');
  }

  // F 同目标同名扩展的显式分派。
  print('F ${TagA('x').tag()} / ${TagB('x').tag()} / ${TagA('y').loud()}');

  // G 显式扩展 setter / 复合赋值（读 getter → 运算 → 写 setter）。
  final counter = Counter();
  LevelEx(counter).level = 2;
  LevelEx(counter).level += 1;
  print('G ${LevelEx(counter).level}/${counter.value}');

  // H 显式访问器的自增 / 自减 / 空合并赋值（读 getter → 运算 → 写 setter）。
  final c2 = Counter();
  LevelEx(c2).level = 2;
  LevelEx(c2).level += 1;
  final post = LevelEx(c2).level++;
  final pre = ++LevelEx(c2).level;
  LevelEx(c2).label ??= 'x';
  LevelEx(c2).label ??= 'y';
  print('H ${LevelEx(c2).level}/${c2.value}/$post/$pre/${LevelEx(c2).label}');

  // I List 语义：== 比较（indexOf / contains / remove）、默认排序、默认分隔符、
  //   length 写（构建期映射表把它们改名为 _indexOf / _sort / _join / _setLength）。
  final list = [Pair(1), Pair(2)];
  final idx = list.indexOf(Pair(2));
  final has = list.contains(Pair(1));
  final removed = list.remove(Pair(1));
  final sorted = ([Pair(3), Pair(1), Pair(2)]..sort())
      .map((p) => p.v)
      .join(',');
  final shrunk = [1, 2, 3]..length = 1;
  print('I $idx/$has/$removed/${list.length}/$sorted/${[1, 2].join()}'
      '/${shrunk.join('|')}');

  // J 单订阅流一生只可订阅一次：取消后再次 listen 必须抛 StateError。
  {
    final c = StreamController<int>();
    final sub = c.stream.listen((_) {});
    await sub.cancel();
    var error = 'none';
    try {
      c.stream.listen((_) {});
    } catch (e) {
      error = e.runtimeType.toString();
    }
    print('J $error');
  }

  // K onError 的第二参（Dart StackTrace / JS 栈字符串）都非空。
  {
    final c = StreamController<int>();
    final got = <String>[];
    c.stream.listen((_) {}, onError: (Object e, StackTrace st) {
      got.add('$e:${st.toString().isNotEmpty}');
    });
    c.addError('boom');
    await Future<void>.delayed(const Duration(milliseconds: 10));
    print('K ${got.join(',')}');
  }

  // L Iterable.map 惰性：调用时不执行回调，toList 才执行；可重复迭代。
  {
    var calls = 0;
    final it = [1, 2, 3].map((x) {
      calls++;
      return x * 2;
    });
    print('L before=$calls');
    print('L list=${it.toList().join(',')}/$calls/${it.toList().join(',')}');
  }

  // M where → map 链：惰性 + 可重复迭代（length / join 各自重新消费）。
  {
    final it = [1, 2, 3, 4].where((x) => x.isEven).map((x) => x * 10);
    print('M ${it.toList().join(',')}/${it.length}/${it.join('-')}');
  }

  // N 订阅前缓冲在 listen 返回后才异步交付（不在调用栈内同步回调）。
  {
    final c = StreamController<int>();
    c.add(1);
    var sync = true;
    c.stream.listen((_) => sync = false);
    print('N $sync');
  }

  // O done 交付后订阅自动移除（hasListener=false），close 的 Future 完成。
  {
    final c = StreamController<int>();
    c.stream.listen((_) {}, onDone: () {});
    var done = false;
    unawaited(c.close().then((_) => done = true));
    await Future<void>.delayed(const Duration(milliseconds: 20));
    print('O ${c.hasListener}/$done');
  }

  // P 唯一订阅取消后 add：事件无人接收，close 仍能完成。
  {
    final c = StreamController<int>();
    final sub = c.stream.listen((_) {});
    await sub.cancel();
    c.add(1);
    var done = false;
    unawaited(c.close().then((_) => done = true));
    await Future<void>.delayed(const Duration(milliseconds: 20));
    print('P $done');
  }

  // Q 从未被订阅的控制器：close 的 Future 不算提前完成（等 done 被交付）。
  {
    final c = StreamController<int>();
    var done = false;
    unawaited(c.close().then((_) => done = true));
    await Future<void>.delayed(const Duration(milliseconds: 20));
    print('Q $done');
  }

  // R 广播每个「最后一个订阅者离开」周期都触发 onCancel。
  {
    var cancels = 0;
    final c = StreamController<int>.broadcast(onCancel: () => cancels++);
    final s1 = c.stream.listen((_) {});
    await s1.cancel();
    final s2 = c.stream.listen((_) {});
    await s2.cancel();
    print('R $cancels');
  }

  // S await for 遇 error 退出：取消订阅（onCancel 触发、hasListener=false）。
  {
    var cancels = 0;
    final got = <int>[];
    final c = StreamController<int>(onCancel: () => cancels++);
    final f = () async {
      try {
        await for (final v in c.stream) {
          got.add(v);
          if (v == 1) c.addError('boom');
        }
      } catch (_) {}
    }();
    c.add(1);
    await f;
    await Future<void>.delayed(const Duration(milliseconds: 10));
    print('S ${got.join(',')}/$cancels/${c.hasListener}');
  }
}

class Pair implements Comparable<Pair> {
  Pair(this.v);

  final int v;

  @override
  bool operator ==(Object other) => other is Pair && other.v == v;

  @override
  int get hashCode => v;

  @override
  int compareTo(Pair other) => v.compareTo(other.v);
}

extension TagA on String {
  String tag() => 'A';

  /// 同名成员必须显式写出扩展（Dart 里 `this.tag()` 是歧义编译错误）。
  String loud() => '${TagA(this).tag()}!';
}

extension TagB on String {
  String tag() => 'B';
}

class Counter {
  int value = 0;
  String? note;
}

extension LevelEx on Counter {
  int get level => this.value ~/ 10;

  set level(int v) => this.value = v * 10;

  String? get label => this.note;

  set label(String? v) => this.note = v;
}
