// 实例对象句柄桥通用层（宿主侧）：**任意**「JS 侧有实例、宿主侧有对应真实对象」
// 的场景共用这一层——ScrollController / TabController / TextEditingController /
// ChangeNotifier 只是其中几类 kind，App 自定义类同样走它（kind 用 `obj/<类名>`）。
//
// 一个句柄桥 = kind 描述符组装（onCreate putIfAbsent、onOp 分派、onRelease
// 释放）+ `__handle` 解析；**对象本体与它的绑定信息全部寄存在绑定缓存里**
// （桶名 = 本桥的 kind，见 binding_cache.dart）——不再各占「controller / 回传
// 句柄 / attach 去重」三张全局表。各能力只留差异：create（真实对象构造，可拿
// meta）、onOp（方法分派）、Host 的 forward（回传载荷）。
//
// 回传句柄（meta.fn）与 attach 去重标记只对 Host 类控制器（Scroll/Tab/Text）
// 有意义；镜像类（ChangeNotifier）的 meta.fn 为 null，无害。
import 'package:flutter/widgets.dart';

import '../../../utils/hot_patch_log.dart';
import 'binding_cache.dart';
import 'handle_registry.dart';

/// 实例对象句柄桥（[T] 为宿主侧真实对象）。由能力文件的 `ensureXxxChannels()`
/// 或 App 自定义 `JsUiLibrary.ensureChannels()` 调 [ensure] 幂等完成 kind 注册。
///
/// 通用分派：目标对象实现 [JsHandleMembers] 时，`onOp` 直接传
/// [dispatchJsMember]，**不需要**为每个类再写一遍 switch。
///
/// **引用强度：强引用**（见 binding_cache.dart 的判定 2）——JS 侧句柄才是这些
/// 对象的寿命驱动者，未收到 release 前 Dart 侧唯一持有者就是本缓存，弱化会让
/// 「JS 还持着句柄、对象却被 GC」成为非确定性失效。
///
/// [T] 只要求是普通对象：控制器不一定是 [Listenable]（如 EasyRefreshController
/// 是纯控制类，既非 ChangeNotifier 也非 Listenable）。默认释放语义是
/// ChangeNotifier / AnimationController 调 dispose；类型不同、需要自己的释放
/// 逻辑时用 [onRelease] 覆盖。
class JsObjectBridge<T extends Object> {
  JsObjectBridge({
    required String kind,

    /// onCreate 阶段创建真实对象（putIfAbsent——与 Host 的兜底创建配合，
    /// 消息与 commit 到达顺序不定，哪端先建都复用同一实例）。为 null 时
    /// onCreate 只登记回传句柄，真实对象由 Host 带参创建（如 TabController
    /// 的 length/initialIndex 随 `__handle` 下发而非 meta）。
    T Function(String id, Object? meta)? create,

    /// 实例级 op 分派（call/get/set），controller 已按 id 解出且非空；
    /// id 未登记（已释放/尚未创建）时静默返回 null（与释放竞态共存）。
    required Object? Function(T controller, String op, Map payload) onOp,

    /// 释放钩子：覆盖默认的「ChangeNotifier / AnimationController 调 dispose」。
    /// 适用于自带 dispose 语义的非 Listenable 控制器（如 EasyRefreshController
    /// 需要在释放时解绑 EasyRefresh）。
    void Function(T controller)? onRelease,
  })  : _kind = kind,
        _create = create,
        _onOp = onOp,
        _onRelease = onRelease;

  /// 本桥的存储桶名 = 句柄 kind（`ctrl/Scroll` / `ctrl/Tab` / `ctrl/Text` /
  /// `notifier/ChangeNotifier` / `obj/<类名>`）：新增一类对象只注册一个 kind 即
  /// 自动获得统一缓存、统一日志与页面兜底回收。
  final String _kind;
  final T Function(String id, Object? meta)? _create;
  final Object? Function(T controller, String op, Map payload) _onOp;
  final void Function(T controller)? _onRelease;

  JsBindingCache get _cache => JsBindingCache.instance;

  bool _registered = false;

  /// 已告警过的「句柄尚未创建/已释放却收到 op」组合（释放竞态属正常，但不能
  /// 完全静默，否则调用方只看到 null、不知道为什么没执行）。
  final Set<String> _warnedMissingOps = {};

  /// 幂等注册 kind 描述符（重复调用短路，与 registerHandleKind 的 assert 配合）。
  void ensure() {
    if (_registered) return;
    _registered = true;
    registerHandleKind(
        _kind,
        JsHandleKind(
          onCreate: (id, meta, pageKey) {
            final create = _create;
            // 回传句柄一并记进同一条目（cached 的 create 重发幂等）。
            // 强引用：JS 侧句柄才是这些对象的寿命驱动者（见 binding_cache.dart）。
            _cache.putIfAbsent<T>(
              bucket: _kind,
              id: id,
              kind: _kind,
              // 登记方与类型名都给人看：日志里呈现为
              // `js:ctrl/Tab#11（TabController）· 页面=jsui_2 · 强引用 · … · 登记=控制器创建`。
              // 注意 TabController 这类真实对象由 Host 随句柄参数创建，此刻尚不存在，
              // 故类型名只能取自泛型 T，不能等实例的 runtimeType。
              owner: '控制器创建',
              weak: false,
              pageKey: pageKey,
              create: create == null ? null : () => create(id, meta),
              meta: {'fn': meta is Map ? meta['fn'] : null, 'type': T.toString()},
            );
          },
          onOp: (id, op, payload) {
            final c = controllerAt(id);
            if (c == null) {
              final key = '$id|$op';
              if (_warnedMissingOps.length >= 256) _warnedMissingOps.clear();
              if (_warnedMissingOps.add(key)) {
                JsLog.warn('$_kind: 句柄 $id 尚未创建或已释放，'
                    'op "$op" 已丢弃（按 null 返回）');
              }
              return null;
            }
            return _onOp(c, op, payload);
          },
          onRelease: (id) {
            final c = controllerAt(id);
            _cache.remove(_kind, id);
            if (c == null) return;
            final release = _onRelease;
            if (release != null) {
              release(c);
              return;
            }
            // AnimationController 等非 ChangeNotifier 的 Listenable 也实现了
            // dispose（AnimationController 有），按类型判断后统一释放。
            if (c is ChangeNotifier) c.dispose();
            if (c is AnimationController) c.dispose();
          },
        ));
  }

  /// 取真实 controller（未登记 / 已释放返回 null）。
  T? controllerAt(String id) => _cache.target<T>(_kind, id);

  /// 取/建真实 controller（Host 侧兜底创建：与 onCreate 复用同一实例）。
  T controllerOf(String id, T Function() create) =>
      controllerAt(id) ??
      _cache
          .putIfAbsent<T>(
            bucket: _kind,
            id: id,
            kind: _kind,
            owner: '宿主创建',
            weak: false,
            create: create,
          )
          .target!;

  /// 回传句柄 id（`meta.fn`）：Host 挂 listener 时经它 invoke 回 JS 镜像。
  Object? fnHandleOf(String id) => _cache.entry<T>(_kind, id)?.meta['fn'];

  /// 首次 attach 返回 true（同一 id 只挂一次转发——多视图共享同一 controller
  /// 时不重复回传）；回传句柄尚未到达（JS 的 create 未到）也返回 false。
  bool markAttachedOnFirst(String id) {
    final e = _cache.entry<T>(_kind, id);
    if (e == null || e.meta['fn'] == null) return false;
    if (e.meta['attached'] == true) return false;
    e.meta['attached'] = true;
    return true;
  }

  /// 从 props 的 controller 取值里解析句柄 id：JS 实例跨桥经 toJSON
  /// 序列化为 `{__handle: 'js:<kind>#N'}`。
  static String? idOf(Object? prop) {
    if (prop is Map) {
      final id = prop['__handle'];
      if (id is String) return id;
    }
    return null;
  }
}

/// 控制器桥接的通用 Host：按 id 取/建真实 controller（putIfAbsent——Host 若
/// 先于 create 消息构建，与 onCreate 复用同一实例），首次 attach 挂 listener
/// 并经 postFrame 回传一次初始快照（JS 镜像不依赖「先变化才更新」，构造后
/// 立即准确）。真实 controller 生命周期由 JS 侧句柄释放驱动（jsHandle
/// release → onRelease），Host 卸载不重复 dispose。
class JsControllerHost<T extends ChangeNotifier> extends StatefulWidget {
  const JsControllerHost({
    super.key,
    required this.bridge,
    required this.id,
    required this.create,
    required this.forward,
    required this.buildChild,
  });

  final JsObjectBridge<T> bridge;

  /// JS 侧控制器实例的句柄 id（如 'js:ctrl/Scroll#5'）。
  final String id;

  /// putIfAbsent 的兜底创建（可携带句柄下发的构造参数，如 TabController）。
  final T Function() create;

  /// controller 变化 → 回传 JS 实例镜像（闭包内自行 invoke）。
  final void Function(T controller, Object? handler) forward;

  /// 用（按 id 绑定好的）真实 controller 构建具体组件。
  final Widget Function(T controller) buildChild;

  @override
  State<JsControllerHost<T>> createState() => _JsControllerHostState<T>();
}

class _JsControllerHostState<T extends ChangeNotifier>
    extends State<JsControllerHost<T>> {
  late final T _controller = widget.bridge.controllerOf(widget.id, widget.create);

  @override
  void initState() {
    super.initState();
    // 同一 id 只挂一次转发（多视图共享同一 controller 时不重复回传）。
    if (widget.bridge.markAttachedOnFirst(widget.id)) {
      _controller.addListener(_forward);
      WidgetsBinding.instance.addPostFrameCallback((_) => _forward());
    }
  }

  void _forward() {
    final handler = widget.bridge.fnHandleOf(widget.id);
    if (handler == null) return;
    widget.forward(_controller, handler);
  }

  @override
  Widget build(BuildContext context) => widget.buildChild(_controller);
}

/// 「JS 侧按成员名调用宿主对象」的最小契约。
///
/// 为什么需要类自己分派：Dart 没有运行时反射，框架拿不到「字符串成员名 → 方法」
/// 的映射；而每个类把自己对外暴露的成员写清楚，本身就是它的职责。接入成本是
/// **一行一个成员**（`switch` 里一条 `case`），框架侧零改动。
///
/// [op] 取值与 JS 侧调用一一对应：
///   - `call`：`payload['method']` + `payload['args']`（数组）→ 调方法；
///   - `get` ：`payload['name']` → 读字段；
///   - `set` ：`payload['name']` + `payload['value']` → 写字段。
/// 返回非 JSON 值没有意义：JS 侧拿到的就是宿主回填的原样值（可 JSON 化即可）。
abstract interface class JsHandleMembers {
  Object? jsMember(String op, Map payload);
}

/// [JsObjectBridge] 的通用 onOp：目标对象实现 [JsHandleMembers] 就转给它。
///
/// 直接把 `dispatchJsMember` 传给 `onOp:` 即可——
/// `JsObjectBridge<NoteObject>(onOp: dispatchJsMember)`（形参逆变，无需包装闭包）。
Object? dispatchJsMember(Object target, String op, Map payload) =>
    target is JsHandleMembers ? target.jsMember(op, payload) : null;
