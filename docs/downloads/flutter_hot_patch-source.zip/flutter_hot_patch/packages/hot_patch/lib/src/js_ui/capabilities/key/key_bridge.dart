// ===== 能力：Key 句柄桥 =====
//
// Key 是**值**（元素 props 的 `key`），不是结点：JS 侧由 capabilities/key/key_js.dart
// 的代理类产出，随 props 序列化下发（`{__vkey:…}` / `{__okey:…}` / `{__handle:…}`），
// 宿主在渲染结点时还原成真实 Flutter Key（见 js_ui_widget 的 `_renderStoreNode`）。
//
// 与 ScrollController 共用同一套通用句柄层（capabilities/core/handle_registry.dart）：
//   - GlobalKey / UniqueKey：JS 侧 `reg(this, 'key/Global'|'key/Unique')` 登记，
//     通用通道 `jsHandle` 的 create 落到本文件描述符 → 创建**真实** GlobalKey() /
//     UniqueKey() 并按句柄 id 复用（GlobalKey 身份跨帧稳定）；scope=page，页面
//     销毁随句柄释放（onRelease 摘除映射）。
//   - ValueKey / ObjectKey / PageStorageKey：不登记句柄（纯值），宿主按值现造——
//     Flutter 的 ValueKey 相等即**值**相等，无需映射表（否则每次 build 都造新
//     实例，表会无限增长）；ObjectKey 跨语言保不住对象同一性，用身份 token 的
//     字符串等价复现（同一对象 token 相同、不同对象不同）；PageStorageKey 同样
//     是值相等，但宿主造的是**真实** PageStorageKey——它的滚动位置持久化是宿主
//     端行为，值本体（`__psk`）只是用来区分存储槽。
import 'package:flutter/widgets.dart';

import '../core/binding_cache.dart';
import '../core/handle_registry.dart';
import '../core/render_object_ops.dart';

/// Key 句柄的存储桶：句柄 id → 宿主侧真实 Key（GlobalKey / UniqueKey）。统一登记
/// 在绑定缓存里，页面销毁时由句柄释放摘除（见 binding_cache.dart 的「唯一缓存」）。
///
/// 引用强度：**强引用**——挂载期虽由 element 的 `widget.key` 持有，但离树期间
/// （懒槽位 / 跨父搬移）Dart 侧只有本缓存 + JS 句柄持有；弱化会让重挂时拿不到
/// 同一实例，[jsKeyOf] 退化成 `ValueKey(结点 id)` → 该子树 State 丢失。
const String _keyBucket = JsBindingBuckets.key;

/// `GlobalKey.currentState` 方法的宿主端实现：真实 GlobalKey → 真实 State。
///
/// key 层不认任何 State 类型：具体能力（如 AnimatedList）在初始化时按**方法名**
/// 注册自己的处理函数，key 层只做「句柄 → GlobalKey」的解析与分发。
typedef KeyStateOpHandler =
    Object? Function(GlobalKey key, Map<String, Object?> payload);

final Map<String, KeyStateOpHandler> _stateOps = {};

/// 注册 `GlobalKey.currentState.<op>` 的宿主实现（op 与 Dart 侧方法名一致）。
void registerKeyStateOp(String op, KeyStateOpHandler handler) {
  _stateOps[op] = handler;
}

bool _keyKindRegistered = false;

/// 幂等注册 Key 句柄 kind（由 js_ui_capabilities.ensureJsUiCapabilities 聚合调用）。
void ensureKeyChannels() {
  if (_keyKindRegistered) return;
  _keyKindRegistered = true;
  registerHandleKind(
    'key/Global',
    JsHandleKind(
      onCreate: (id, meta, pageKey) {
        // putIfAbsent：create 消息与首帧渲染（props 里的 key）到达顺序不定，
        // 同一句柄 id 必须始终对应同一个 GlobalKey 实例（换实例即丢 State）。
        JsBindingCache.instance.putIfAbsent<Key>(
          bucket: _keyBucket,
          id: id,
          kind: 'key/Global',
          owner: 'key/Global.onCreate',
          weak: false,
          pageKey: pageKey,
          create: () => GlobalKey(debugLabel: _labelOf(meta)),
        );
      },
      onOp: (id, op, payload) {
        // 「取位置 / 取尺寸」只能在宿主做：BuildContext / RenderObject 是宿主端概念，
        // JS 侧只有句柄 id、没有同步取值能力（见 capabilities/key/key_js.dart 的 RenderObject 代理）。
        // 这里还原真实 GlobalKey → 真实 BuildContext → 真实 RenderObject，把 Dart
        // 单源的整条语义补全：
        //   - `ctx.findRenderObject()?.showOnScreen()`：位置 + 滚动，void 语义；
        //   - `box.measure()`：RenderBox 的 `size` 与 `localToGlobal(Offset.zero)`
        //     都是同步属性，宿主算完回填（返回值经通道回填 JS Promise，见
        //     JsRuntimeManager.registerHostMethod）。
        final key = JsBindingCache.instance.target<Key>(_keyBucket, id);
        if (key is! GlobalKey) return null;
        // `currentState.<op>`：op 形如 `__state.<method>`。State 的方法签名属于具体
        // 组件，故按 **`Type.method`** 分发（Type 来自 `GlobalKey<T>` 的泛型实参），
        // 同名方法各自挂在自己的类型下，key 层不认任何 State 类型，也不会互相覆盖。
        if (op.startsWith('__state.')) {
          // key 由 renderer 直接挂在真实 widget 上（`key: c.key`），真实 State 就是
          // 它的 currentState，无需任何外层/映射 key。
          final state = key.currentState;
          if (state == null) return null;
          final method = op.substring('__state.'.length);
          // 类型优先取 JS 侧**泛型实参**（`GlobalKey<AnimatedListState>` 的 T）——
          // 与 `context.read<T>()` 同一原则：T 是参数，不是猜出来的。没声明泛型时
          // 才回退 runtimeType（并留痕，提示补上泛型）。
          final declared = payload['type'];
          final String typeName;
          if (declared is String && declared.isNotEmpty) {
            typeName = declared;
          } else {
            typeName = '${state.runtimeType}';
            // ignore: avoid_print - 运行时日志
            print(
              '[hot_patch] [WARN] GlobalKey 未声明泛型实参，按 runtimeType 推断：'
              '$typeName（建议写成 GlobalKey<$typeName>）',
            );
          }
          final handler = _stateOps['$typeName.$method'];
          if (handler == null) {
            // ignore: avoid_print - 运行时日志
            print('[hot_patch] [WARN] currentState 未登记的方法：$typeName.$method');
            return null;
          }
          // 能力实现直接 `key.currentState` 即可。
          return handler(key, payload.cast<String, Object?>());
        }
        // `__type`：JS 侧按它挑对应组件的 State 代理类（无代理类时退化为通用句柄）。
        if (op == '__type') {
          return key.currentState?.runtimeType.toString();
        }
        final ro = key.currentContext?.findRenderObject();
        if (op == 'showOnScreen') {
          ro?.showOnScreen();
          return null;
        }
        // 位置与尺寸的取值规则见 core/render_object_ops.dart（与 ctx 句柄共用）。
        if (op == 'measure') return renderObjectMeasurePayload(ro);
        return null;
      },
      onRelease: (id) => JsBindingCache.instance.remove(_keyBucket, id),
    ),
  );
  registerHandleKind(
    'key/Unique',
    JsHandleKind(
      onCreate: (id, meta, pageKey) => JsBindingCache.instance.putIfAbsent<Key>(
        bucket: _keyBucket,
        id: id,
        kind: 'key/Unique',
        owner: 'key/Unique.onCreate',
        weak: false,
        pageKey: pageKey,
        create: () => UniqueKey(),
      ),
      onRelease: (id) => JsBindingCache.instance.remove(_keyBucket, id),
    ),
  );
}

String? _labelOf(Object? meta) {
  final label = meta is Map ? meta['debugLabel'] : null;
  return label is String && label.isNotEmpty ? label : null;
}

/// 结点 props 里的序列化 key → 宿主真实 Key；无法识别（缺 key / 句柄已释放）
/// 返回 null，调用方退回 `ValueKey(结点 id)`（见 js_ui_widget）。
Key? jsKeyOf(Object? prop) {
  if (prop is! Map) return null;
  // ValueKey(对象值)：跨语言保不住对象同一性，JS 侧序列化成身份 token（与
  // Dart 的 `==` 对 Map/List 即同一性一致），这里用 token 串等价复现。
  final vtok = prop['__vtok'];
  if (vtok != null) return ValueKey<String>('vo:$vtok');
  // PageStorageKey：值相等，但必须造**真实** PageStorageKey（滚动位置按 key
  // 存进 PageStorage bucket，是宿主端行为）；对象值同 ValueKey 走身份 token。
  if (prop.containsKey('__psk')) {
    final pv = prop['__psk'];
    final value = (pv is Map && pv['__vtok'] != null)
        ? 'po:${pv['__vtok']}'
        : pv;
    return PageStorageKey<Object?>(value);
  }
  if (prop.containsKey('__vkey')) return ValueKey<Object?>(prop['__vkey']);
  final okey = prop['__okey'];
  // ObjectKey：身份 token 串等价复现（Dart 侧 identical 语义，见文件头）。
  if (okey != null) return ValueKey<String>('ok:$okey');
  final handle = prop['__handle'];
  if (handle is String)
    return JsBindingCache.instance.target<Key>(_keyBucket, handle);
  return null;
}
