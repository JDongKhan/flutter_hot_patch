import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart'
    show kDebugMode, kReleaseMode, defaultTargetPlatform, TargetPlatform;
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_js/flutter_js.dart';

import '../utils/hot_patch_assets.dart';
import '../utils/js_asset_resolver.dart';
import '../utils/remote_asset_loader.dart';
import '../utils/hot_patch_log.dart';

/// JS 运行时管理器：与底层 [JavascriptRuntime] **一对一**。
/// 每个 [JsRuntimeManager] 内部持有一个 [JavascriptRuntime]，所有与
/// JavascriptRuntime 相关的操作（创建、求值、通道注册、生命周期）都在
/// 本类内部消化；JsUiWidget 等使用方只接触 [JsRuntimeManager]，
/// 完全不感知底层运行时对象。
///
/// - **唯一实例**：全进程只有 [instance]（static 共享），所有 [JsUiWidget] 共用
///   同一个 JS 环境。**不支持、也不允许业务方自行创建第二个实例**：flutter_js
///   的消息桥与通道表本身是库级全局的，多实例并不能带来真正的隔离，只会让消息
///   串台/丢消息。页面级隔离统一由 `pageKey` 在 JS 侧完成。
/// - **生命周期**：默认实例由本类持有（app 生命周期内常驻），随进程结束销毁。
///
/// ## 消息通道：单一桥通道 `_app_bridge_` + 单一处理器表
///
/// JS → Flutter 的所有消息都打到**唯一的桥通道** `_app_bridge_`，消息体里
/// 用 `ch` 字段标示目标逻辑通道：
///
///   sendMessage('_app_bridge_', JSON.stringify({ ch: 'jsuiCommit', data }))
///
/// 其中 `data` 固定为 `{id, args}`。JS 侧对外只有**一个**出口
///   `_app_host_.invoke(channel, args)`：它把 `{id, args}` 交给宿主，宿主实现后用
/// `_app_host_.resolve(id, value)` 回填 Promise、实现抛错用
/// `_app_host_.reject(id, message)` 把异常抛回调用者（**宿主必定结算**：
/// 通道未注册也在 [_dispatch] 里回填 null，不留下永久悬空的 Promise）。框架内建通道（增量补丁
/// `jsuiCommit`、日志 `log`、native 通道）与业务 @HostInjected 方法
/// 共用这一张表。
///
/// 本类在**构造时**用 `_runtime.onMessage('_app_bridge_', _dispatch)` 订阅一次，
/// [_dispatch] 再按 `ch` 二次分发到 [globalMessageHandlers]。因此**注册与订阅
/// 完全解耦**：处理器可以在任何时机注册（包括第一个 manager 出现之前，如
/// main() 里直接调用），不需要「补接线」，也不会出现「channel 未接线 →
/// No channel xxx registered」。 [evaluate] 是纯求值入口，不掺注册副作用。
///
/// **对外扩展只有一个能力：[registerHostMethod] 注册一个宿主方法
/// （@HostInjected 方法，或框架内建通道），JS 侧 `_app_host_.invoke` 调用、
/// 宿主实现并回填结果。**
///
/// 页面隔离（多 JsUiWidget 共用单 runtime）由处理器**内部**按参数里的
/// 页面 key 自行路由（如 js_ui 的 `jsuiCommit`：payload 带 key，路由到
/// 对应 JsUiStore），分发层不再区分页面级/全局级。
///
/// [globalMessageHandlers] 必须是 static 全局唯一：
/// flutter_js 0.8.7（iOS/JavaScriptCore）的消息桥是库级全局的，
/// `sendMessage` 的 Dart 回调是 static 字段（由最后创建的 runtime 覆盖
/// 赋值），通道表也是 static Map（key=engineId）。若处理器表是实例级的，
/// 消息到达某个 manager 的通道回调后查不到属于另一个 manager 的处理器，
/// 就会串台/丢消息。
class JsRuntimeManager {
  /// 全局唯一实例（static 共享）：所有场景都使用它，不支持外部再构造。
  static final JsRuntimeManager instance = JsRuntimeManager._();

  /// 全局导航 key（可选）：全局级服务（如 toast 弹 SnackBar）用它定位
  /// ScaffoldMessenger。业务方在 MaterialApp.navigatorKey 传入。
  static GlobalKey<NavigatorState>? navigatorKey;

  /// JS 侧单桥通道名：所有 JS→宿主消息都打到这里，再按消息体 `ch` 分发。
  static const String _bridgeChannel = '_app_bridge_';

  /// 宿主注入「位置 + 具名」混合调用时，承载**位置实参**的哨兵键。
  ///
  /// 协议常量：由生成器 `hot_patch_generator` 产出（其 `hostPositionalKey`
  /// 是同一个值），运行时在这里解析。`@` 不是合法的 Dart 标识符字符，故不会
  /// 与任何具名形参重名，判定无歧义。
  static const String hostPositionalKey = '@args';

  /// 所有活跃 manager（static 跟踪）：宿主对 JS 侧 pending 的结算
  /// （`_app_host_.resolve` / `reject`，见 [_settleHost]）需要对每个 runtime
  /// 求值一次。
  static final Set<JsRuntimeManager> _instances = {};

  // ---------------------------------------------------------------------
  // 全局共享（static）：唯一消息处理器表
  // ---------------------------------------------------------------------

  /// 唯一处理器表（全局唯一）：通道名 → 处理器。
  /// [registerHostMethod] 注册的宿主方法在这里，全局一份；框架内建通道
  /// （`jsuiCommit` / `log` / native 通道）也走同一张表。
  static final Map<String, void Function(dynamic args)> globalMessageHandlers =
      {};

  /// 注册一个**宿主方法**（@HostInjected 通道；框架内建通道同用此入口）。
  ///
  /// 生成器把 `@HostInjected` 方法的**方法体**翻译为 JS 侧
  /// `_app_host_.invoke("通道名", 参数载荷)`（返回 Promise，可 await；载荷按实参
  /// 形态给数组/对象，见 [_hostCallArgs]）——调用点与 Dart 一比一，由该方法体
  /// 桥回宿主。本方法把该通道接到宿主实现 [impl]：收到 JS 的 `{id, args}` 后按
  /// `Function.apply(impl, 位置实参, 具名实参)` 调用——Dart 调用语义完整还原，
  /// 位置/具名实参**个数不限**，未传的参数走实现自身的默认值，返回值类型也不限。
  /// 之后把返回值经 `_app_host_.resolve(id, value)` 回填 JS 的 Promise；
  /// 实现抛错则经 `_app_host_.reject(id, message)` 把异常抛回 JS 调用者。
  ///
  /// 全局一份；通道名即 @HostInjected 注解里的名称（缺省为方法名），或框架
  /// 内建通道名。只写处理器表——桥通道在 manager 构造时已订阅。
  /// 通道名需唯一：debug 下重复注册会触发断言失败。
  static void registerHostMethod(String channel, Function impl) {
    // 同一通道注册两次会覆盖前一个实现，JS 侧调到的实现与预期不符且无从察觉。
    // debug 下直接断言让问题在启动时暴露；release 下断言被裁掉，但仍必须留痕。
    if (globalMessageHandlers.containsKey(channel)) {
      JsLog.warn(
        'registerHostMethod: 通道 "$channel" 已注册，'
        '本次注册将覆盖前一个实现（通道名必须唯一）',
      );
      assert(
        false,
        'registerHostMethod: 通道 "$channel" 已被注册——'
        '通道名必须唯一（重复注册会静默覆盖前一个实现）',
      );
    }
    globalMessageHandlers[channel] = (dynamic args) async {
      final map = args is Map ? args : const {};
      if (args is! Map) {
        JsLog.warn(
          'registerHostMethod("$channel"): 参数载荷不是对象'
          '（${args.runtimeType}），按空参数调用',
        );
      }
      final id = map['id']?.toString();
      final (positional, named) = _hostCallArgs(map['args']);
      try {
        final value = await Function.apply(impl, positional, named);
        _settleHost(id, value: value);
      } catch (e, s) {
        // 不静默：实现调用失败若悄悄回填 null，JS 侧只看到「结果是 null」，
        // 完全不知道宿主侧压根没调成功（具名参数不匹配就是这样被吞掉的）。
        // 现在把异常原样抛回 JS 调用者（reject → await 处抛出，可被 JS 自己的
        // try/catch 接住）；完整堆栈仍留在宿主日志里。
        JsLog.error(
          'registerHostMethod("$channel") 调用宿主实现失败: $e',
          error: e,
          stackTrace: s,
        );
        _settleHost(id, error: '$e');
      }
    };
  }

  // ---------------------------------------------------------------------
  // 宿主返回值编码（跨语言值的扩展点）
  // ---------------------------------------------------------------------

  /// 「宿主方法的返回值里出现非 JSON 对象」时的编码器表（按注册顺序匹配）。
  ///
  /// @HostInjected 方法的返回值由 [_settleHost] 用 `jsonEncode` 回填 JS；
  /// `ui.Image` 这类对象没有 JSON 形态，必须由**拥有该能力的能力库**登记
  /// 一个编码器（如 canvas 的图片句柄 `{__handle, width, height}`）。
  /// 核心不认识任何具体类型——与句柄 kind 一样，只在能力模块里登记。
  static final List<(bool Function(Object), Object? Function(Object))>
  _hostValueEncoders = [];

  /// 登记一个宿主返回值编码器：[encode] 把 [T] 实例转成可 JSON 序列化的值。
  ///
  /// 匹配按 `is T`；没有命中任何编码器的对象沿用 Dart 的默认语义（有
  /// `toJson` 就调它，否则抛 [JsonUnsupportedObjectError]——不静默变 null）。
  static void registerHostValueEncoder<T>(Object? Function(T value) encode) {
    _hostValueEncoders.add((
      (Object v) => v is T,
      (Object v) => encode(v as T),
    ));
  }

  /// [jsonEncode] 的 `toEncodable`：先查已登记的能力编码器，再回落默认语义。
  static Object? _encodeHostValue(Object? value) {
    if (value == null) return null;
    for (final (test, encode) in _hostValueEncoders) {
      if (test(value)) return encode(value);
    }
    try {
      return (value as dynamic).toJson();
    } catch (_) {
      throw JsonUnsupportedObjectError(value);
    }
  }

  /// 触发一次 JS 事件句柄并**等待其结果**（宿主侧 `Future<T>` 回调的通用入口）。
  ///
  /// 为什么需要它：宿主 → JS 的 `__jsui.invoke` 是单向的；而 Dart 侧返回
  /// `Future<T>` 的回调（`confirmDismiss` / EasyRefresh 的 `onRefresh` / 以后任何
  /// async 事件）在 JS 侧是 Promise，iOS/JavaScriptCore 又无法把 Promise 交回
  /// Dart。于是统一走 `__jsui.invokeAwait`：JS 执行句柄、await 结果，再经唯一
  /// JS→宿主出口把「token + 结果」回传到 [eventResultChannel]，这里按 token 结算。
  ///
  /// [handler] 是 JS 侧事件句柄 `{'__fn': id}`；形态不对时立即返回 null
  /// （等价于「没有这个回调」）。同步回调同样适用（结果原样返回）。
  static Future<Object?> invokeAwait(
    Object? handler, [
    List<Object?> args = const [],
  ]) {
    final id = handler is Map ? handler['__fn'] : null;
    if (id is! String) {
      JsLog.debug('invokeAwait: 回调句柄缺少 __fn，按「无回调」返回 null');
      return Future<Object?>.value(null);
    }
    _ensureEventResultChannel();
    final token = 'ev${++_eventSeq}';
    final completer = Completer<Object?>();
    _pendingEvents[token] = completer;
    // args 与 invoke 相同：内层数组 JSON 文本，外层字符串字面量。
    instance.evaluate(
      '__jsui.invokeAwait(${jsonEncode(id)}, ${jsonEncode(jsonEncode(args))}, '
      '${jsonEncode(token)});',
    );
    // 兜底超时：运行时销毁 / 句柄中途释放时回程永不到达，条目不能永远悬着。
    return completer.future.timeout(
      const Duration(seconds: 30),
      onTimeout: () {
        _pendingEvents.remove(token);
        JsLog.warn('invokeAwait 超时（30s，token=$token），按 null 结算');
        return null;
      },
    );
  }

  /// `invokeAwait` 的结果回传通道（JS 侧 `__sendEventResult`）。
  static const String eventResultChannel = 'jsuiEventResult';

  static final Map<String, Completer<Object?>> _pendingEvents = {};

  static int _eventSeq = 0;

  static bool _eventResultChannelRegistered = false;

  static void _ensureEventResultChannel() {
    if (_eventResultChannelRegistered) return;
    _eventResultChannelRegistered = true;
    registerHostMethod(eventResultChannel, (
      String token,
      String resultJson,
      String? error,
    ) {
      final completer = _pendingEvents.remove(token);
      if (completer == null || completer.isCompleted) {
        // 超时后回程才到 / 重复回程：正常竞态，但必须留痕，否则「回调结果被
        // 丢弃」看起来像业务没执行。
        JsLog.warn('[jsui] 收到未知或重复的 invokeAwait 回程 token=$token，已丢弃');
        return null;
      }
      if (error != null) {
        // 回调在 JS 侧抛错：按「无结果」结算（调用方按 Flutter 默认行为兜底），
        // 异常细节已由 JS 侧日志输出。
        JsLog.warn('[jsui] invokeAwait 回调抛错: $error');
        completer.complete(null);
        return null;
      }
      Object? value;
      if (resultJson.isNotEmpty) {
        try {
          value = jsonDecode(resultJson);
        } catch (e) {
          JsLog.warn(
            '[jsui] invokeAwait 结果不是合法 JSON（token=$token），'
            '按 null 结算: $e',
          );
          value = null;
        }
      }
      completer.complete(value);
      return null;
    });
  }

  /// 帧级 flush：宿主 begin frame 阶段驱动所有活跃 runtime 执行 JS 侧待处理
  /// 重建（`__jsui.flushPending`）。JS 的 setState 只标脏，宿主每帧统一执行一次，
  /// 同一帧内多次 setState 合并为一次 build（与 Flutter 的 setState 语义一致）。
  /// 请求入口见 builtin_host_methods 的 `jsuiRequestFrame`。
  static void flushJsUiPending() {
    for (final m in _instances.toList()) {
      m.evaluate(
        'if (typeof __jsui !== "undefined" && __jsui.flushPending) '
        '__jsui.flushPending();',
      );
    }
  }

  /// 帧回调：宿主 begin frame 阶段把「帧已开始」回传给所有活跃 runtime
  /// （`__jsui.frameTick(ms)`），供 JS 侧 `WidgetsBinding
  /// .addPersistentFrameCallback` 派发。与 [flushJsUiPending] 同入口、同帧：
  /// JS 侧回调里的 setState 会再次请求下一帧（见 widgets_binding_js）。
  static void tickJsUiFrames(Duration timeStamp) {
    final ms = timeStamp.inMilliseconds;
    evaluateAll(
      'if (typeof __jsui !== "undefined" && __jsui.frameTick) '
      '__jsui.frameTick($ms);',
    );
  }

  /// 对所有活跃 runtime 求值一次（宿主侧主动推送，如动画帧回传 value）。
  ///
  /// 与 [_settleHost] 同口径：持有目标句柄的 runtime 生效，其余按 id 查不到即
  /// no-op（见 JS 侧 `__jsui.invoke`），因此调用方无需知道句柄归属哪个 runtime。
  static void evaluateAll(String code) {
    for (final m in _instances.toList()) {
      m.evaluate(code);
    }
  }

  /// **详细缓存追踪开关**（debug-only，默认关）：等价于直接设置
  /// [JsLog.verboseCache]，但会**立刻**把 JS 侧的句柄日志切面装 / 卸，
  /// 不必等下一次运行时初始化。
  ///
  /// 打开后逐条打印双端缓存进出：Dart 侧 `[binding] + / - <条目摘要>`，JS 侧
  /// `[js-log] [binding] + / - JS <句柄摘要>`，两边摘要都以句柄 id 起头，可直接
  /// 按 id 对齐。关闭后仅剩包装内的一次布尔短路，不影响任何业务逻辑。
  static void setVerboseCacheTrace(bool on) {
    JsLog.verboseCache = on;
    _applyCacheTrace();
  }

  /// 把 [JsLog.verboseCache] 推给所有活跃 runtime（未就绪的跳过，下次
  /// [ensureJsUiRuntime] 完成时会再同步一次）。
  static void _applyCacheTrace() {
    if (!kDebugMode) return;
    final on = JsLog.verboseCache;
    evaluateAll(
      'if (typeof __jsui !== "undefined" && __jsui.setCacheVerbose) '
      '__jsui.setCacheVerbose($on);',
    );
  }

  /// 调试用：清除本地补丁缓存并重置模块缓存。
  ///
  ///   - 磁盘：删除 `<document>/hot_patch/` 下**全部** URL 的解压产物（含
  ///     协商缓存记录），下次加载重新下载 zip（见 [RemoteAssetLoader.clearCache]）；
  ///   - 内存：清空所有活跃 runtime 的已加载模块表与 JS 侧 `__modules`
  ///     （见 [invalidateModules]），强制重新 evaluate 最新产物。
  ///
  /// 清除后重新进入热更页面即拉取最新产物；已在屏上的 JS 页面需重进才刷新。
  static Future<void> clearCache() async {
    await RemoteAssetLoader.clearCache();
    for (final m in _instances.toList()) {
      m.invalidateModules();
    }
  }

  /// 结算 JS 侧 Promise（`_app_host_.resolve` / `_app_host_.reject`）。
  ///
  /// 对每个活跃 runtime 求值一次：持有该 id 的 runtime 生效，其余为 no-op
  /// （JS 侧按 id 查不到 pending 即直接返回）。
  ///
  /// 宿主**必须**二选一结算——`invoke` 一次就在 JS 侧建了一条 pending，
  /// 既不 resolve 也不 reject 会让 Promise 永久悬空、条目永久滞留（见 [host]）。
  /// [error] 非空即走 reject 路径；[id] 缺失（如内建 `send` 通道带 `args`
  /// 不带 id）时无事可做，直接返回。
  static void _settleHost(String? id, {Object? value, String? error}) {
    if (id == null || id.isEmpty) return;
    final reject = error != null;
    final code = reject
        ? '_app_host_.reject("$id", ${jsonEncode(error)});'
        : '_app_host_.resolve("$id", '
              '${jsonEncode(value, toEncodable: _encodeHostValue)});';
    final where = reject ? '_app_host_.reject' : '_app_host_.resolve';
    for (final m in _instances.toList()) {
      m._eval(code, where);
    }
  }

  /// JS 宿主调用的参数载荷 → (`位置实参`, `具名实参`)。
  ///
  /// 生成器（见 `_app_host_.invoke`）按实参形态给三种编码，这里对称解析：
  ///   - 数组 `[a, b]`            → 全是位置实参
  ///   - 对象 `{"times": 2}`      → 全是具名实参
  ///   - 对象带 [hostPositionalKey] → 混合（该键是位置实参，其余键是具名）
  ///
  /// 位置实参与具名实参的**个数都不设限**；具名键转成 [Symbol]
  /// （`Function.apply` 的具名表要求 `Map<Symbol, dynamic>`，`Symbol('times')`
  /// 等价于 `#times`）。未传的参数由实现自身的默认值兜底。
  static (List<dynamic>, Map<Symbol, dynamic>) _hostCallArgs(dynamic raw) {
    if (raw is List) return (raw, const {});
    if (raw is Map) {
      final pos = raw[hostPositionalKey];
      final named = <Symbol, dynamic>{};
      for (final e in raw.entries) {
        final key = e.key.toString();
        if (key == hostPositionalKey) continue;
        named[Symbol(key)] = e.value;
      }
      return (pos is List ? pos : const <dynamic>[], named);
    }
    return (const <dynamic>[], const <Symbol, dynamic>{});
  }

  // ---------------------------------------------------------------------
  // 实例状态：与 JavascriptRuntime 一对一
  // ---------------------------------------------------------------------

  /// 本 manager 独占的底层运行时（对外不可见，全部内部消化）。
  final JavascriptRuntime _runtime = getJavascriptRuntime();

  bool _jsUiInited = false;

  /// 内存中已加载的补丁包身份版本（见 `RemoteAssetBundle.version`）。
  ///
  /// 同一进程可能先后加载来自不同 URL / 不同批次打出的补丁包（页面 A、页面 B
  /// 各自指向不同 zip）。它们的模块路径（`components/x.js`）与运行时骨架不能
  /// 混用，因此必须按「包版本」整体判断是否失效，而不是只看某个 URL 的 fresh。
  String? _loadedBundleVersion;

  /// 当前内存里已加载补丁包的版本（调试/诊断用）；未加载过 remote 包时为 null。
  String? get loadedBundleVersion => _loadedBundleVersion;

  /// 记录本次要加载的补丁包版本；与内存中已加载的版本不一致时，清空模块缓存
  /// 与 JS 运行时标记，强制下一次 [ensureJsUiRuntime] 重新求值运行时、
  /// [loadModule] 重新加载全部模块。
  ///
  /// 返回 true 表示本次发生了整体失效（调用方据此通知活跃页注册表：其他已挂载
  /// 页面需要页面级重载）。
  ///
  /// **只认版本差异**：同一份身份版本（version + buildTime + protocol）即使被
  /// 重新下载（fresh=true）也不失效——避免页面级重载后再次触发切换，形成
  /// 「重载 → 又判切换 → 再重载」的循环。
  ///
  /// 必须在 [ensureJsUiRuntime] / [loadModule] 之前调用（见 JsUiWidget 的 boot）。
  bool syncBundleVersion(
    String? version, {
    required bool fresh,
    String? localRoot,
  }) {
    final loaded = _loadedBundleVersion;
    // 运行时还没初始化过 → 内存里没有可复用的东西，直接记录即可。
    // 已经初始化过且版本不同（含「asset 场景 null → remote 包」）→ 必须整体失效。
    final differs = _jsUiInited && version != loaded;
    if (!differs) {
      if (loaded == null && version != null) _loadedBundleVersion = version;
      if (version == null && _jsUiInited && !_warnedMissingBundleVersion) {
        _warnedMissingBundleVersion = true;
        JsLog.warn(
          '补丁包 manifest 缺少身份版本字段，'
          '后续版本切换将无法判定（请用配套生成器重新产出 manifest）',
        );
      }
      // 同一版本复用内存：资源根仍以本次加载的包为准（同一版本 = 同一份产物）。
      JsAssets.activate(localRoot);
      return false;
    }
    JsLog.log(
      '补丁包版本变化：memory=${loaded ?? '(none)'} '
      'bundle=${version ?? '(none)'} fresh=$fresh —— '
      '清除内存并重新加载 JS 运行时',
    );
    invalidateModules();
    _loadedBundleVersion = version;
    // 切换后资源解析跟随新包；回到 asset 场景（localRoot=null）时恢复纯 assets。
    if (localRoot != null) {
      JsAssets.activate(localRoot);
    } else {
      JsAssets.reset();
    }
    return true;
  }

  /// 已告警过「补丁包无身份版本」（避免每次加载都刷屏）。
  bool _warnedMissingBundleVersion = false;

  JsRuntimeManager._() {
    _instances.add(this);
    // 只订阅**一个**桥通道：所有 JS→宿主消息都打到这里，本类再按消息体
    // `ch` 字段二次分发（[_dispatch]）。订阅只发生这一次，与处理器注册
    // 时机完全解耦——不需要任何「补接线 / 防重」逻辑。
    _runtime.onMessage(_bridgeChannel, _dispatch);
  }

  /// 所有 JS 求值的统一入口（纯求值，无注册副作用）。
  /// code 内部按需寻址，如 `__jsui.invoke(...)` / `__jsui.mountRoot(...)`。
  ///
  /// 求值失败经 [_eval] 打日志（flutter_js 的 evaluate 不抛异常，
  /// 不查返回值就会静默失败）。
  JsEvalResult evaluate(String code) => _eval(code, 'evaluate');

  /// 求值 + **失败即抛**：给「失败必须让上层感知」的调用点用（典型是
  /// JsUiWidget 挂载组件——组件名在包里不存在时必须进错误态，而不是因为
  /// `isError` 只被记了日志、`root` 永远不下发而一直转圈）。
  ///
  /// 事件回传 / dispose 这类「失败只该记日志、不影响界面」的调用点仍用
  /// [evaluate]（在 UI 回调里抛异常会把一次点击变成崩溃）。
  JsEvalResult evaluateOrThrow(String code, {String where = 'evaluate'}) {
    final result = _eval(code, where);
    if (result.isError) {
      throw JsEvalException('JS eval failed [$where]: ${result.stringResult}');
    }
    return result;
  }

  /// 求值 + 错误检查：本类内所有 `_runtime.evaluate` 的统一出口。
  ///
  /// flutter_js 的 `evaluate` **不会抛异常**：JS 侧的语法/运行错误以
  /// [JsEvalResult.isError] + [JsEvalResult.stringResult]（JSC 下形如
  /// `ERROR: ...`）返回。所以每次求值都必须查 `isError` 并打日志，否则
  /// 注入失败会被静默吞掉——之后所有调用都是 undefined，却看不到任何报错。
  /// [where] 标明出错的是哪段注入/调用，便于定位。
  JsEvalResult _eval(String code, String where) {
    final result = _runtime.evaluate(code);
    if (result.isError) {
      final preview = code.replaceAll('\n', ' ').trim();
      final brief = preview.length > 80
          ? '${preview.substring(0, 80)}…'
          : preview;
      JsLog.error(
        'JS eval failed [$where]: ${result.stringResult} | code: $brief',
      );
    }
    return result;
  }

  /// 确保 js_ui 运行时骨架就位（幂等）。
  ///
  /// 注入 JS 运行时：`patch/runtime.js`（**构建期产物**，与组件产物同生命
  /// 周期）——运行环境全局（模块表 `__modules` / 日志全局）+ element/
  /// component/reconciler/context + 能力桥 + ChangeNotifier 基类 + 各能力
  /// 片段 + commit 协议。与具体组件无关；组件/模型/按 package 生成的 widget
  /// 模块仍走 [loadModule]。
  ///
  /// JS 源码全部在 `hot_patch_generator`（`builders/core_js_builder/js/runtime/**`），由
  /// `ui_runtime` builder 写成 `patch/runtime.js`：**JS 侧修复重出产物即可，
  /// 不需要发版 App**。
  ///
  /// 幂等：进程内只初始化一次。`runtime.js` 内部另有 `G.__jsui` 守卫，
  /// 同一 JS 环境重复求值直接返回，不会产生两份运行时状态。
  Future<void> ensureJsUiRuntime({
    String? localRoot,
    String? moduleAsset,
  }) async {
    if (_jsUiInited) return;
    // 编译模式 / 平台标志只有 Dart 侧知道（构建期无从得知），故在求值
    // runtime.js 之前以顶层全局注入，产物里裸引用 `kDebugMode` / `Platform`
    // 与 Dart 一比一。
    _eval(_jsUiEnvSource(), 'jsUiEnv');
    final asset = _runtimeAssetNear(moduleAsset);
    final source = await _readModule(asset, localRoot);
    final result = _eval(source, asset);
    final text = result.stringResult;
    if (result.isError ||
        text.startsWith('ERROR:') ||
        text.contains('\nERROR:')) {
      throw StateError('$asset evaluate failed: $text');
    }
    _jsUiInited = true;
    // 详细缓存追踪开关可能在运行时就绪前就被打开：这里补一次同步。
    _applyCacheTrace();
  }

  /// 运行时产物在补丁根目录下的文件名（与 `patch/<package>.js` 同级）。
  static const String runtimeJsAsset = 'runtime.js';

  /// JS 侧 UI 运行时骨架（`runtime.js`）是否已求值。
  ///
  /// 宿主向 JS 推送同步镜像（MediaQuery 等）之前必须确认：首帧可能早于
  /// `patch/runtime.js` 加载，此时 `__jsui*` 全局还不存在，求值只会报错。
  bool get isJsUiRuntimeReady => _jsUiInited;

  /// 运行时产物路径：优先跟随**当前模块所在补丁根目录**。
  ///
  /// 组件的入口可能是 `assets/patch/components/x.js`（asset 场景），也可能是
  /// 网络包解压后的 `components/x.js`（localRoot 场景）。两者向上找到 `patch/`
  /// 这一层，再把文件名换成 [runtimeJsAsset]——不需要任何配置或映射表。
  static String _runtimeAssetNear(String? moduleAsset) =>
      _assetNear(moduleAsset, runtimeJsAsset);

  /// 补丁根目录下的 [fileName]：入口可能带 `patch/` 前缀（asset 场景），也可能
  /// 是包内虚拟路径（网络包解压后的 localRoot 场景，此时直接拼文件名）。
  static String _assetNear(String? moduleAsset, String fileName) {
    if (moduleAsset == null) return fileName;
    const marker = 'patch/';
    final i = moduleAsset.lastIndexOf(marker);
    if (i < 0) return fileName;
    return '${moduleAsset.substring(0, i + marker.length)}$fileName';
  }

  /// 编译期标志：`kDebugMode` / `kReleaseMode` / `kInJsRuntime` / `Platform.isXxx`，
  /// 与 Dart 产物里的裸引用同名（`globalThis` 属性即全局变量）。
  /// `kInJsRuntime` 恒为 true：本段只在 JS 环境求值，原生侧的同名常量是 false。
  String _jsUiEnvSource() =>
      '''
(function () {
  var G = typeof globalThis !== 'undefined' ? globalThis : this;
  G.kDebugMode = $kDebugMode;
  G.kReleaseMode = $kReleaseMode;
  G.kInJsRuntime = true;
  G.Platform = {
    isAndroid: ${defaultTargetPlatform == TargetPlatform.android},
    isIOS: ${defaultTargetPlatform == TargetPlatform.iOS},
    isMacOS: ${defaultTargetPlatform == TargetPlatform.macOS},
    isWindows: ${defaultTargetPlatform == TargetPlatform.windows},
    isLinux: ${defaultTargetPlatform == TargetPlatform.linux},
    isFuchsia: ${defaultTargetPlatform == TargetPlatform.fuchsia}
  };
})();
''';

  // ---------------------------------------------------------------------
  // 模块加载器（ES module 支持）
  // ---------------------------------------------------------------------
  //
  // flutter_js 0.8.7 只有 evaluate（无原生 import/export 求值），因此这里
  // 做文本级模块加载：把产物的 import/export 预处理成脚本模式——
  //   - `export class X {...}`   -> `class X {...}`（收集导出名）
  //   - `import { A } from 'rel'` -> `const { A } = __modules['<abs>'];`
  //   - `import 'rel';`（副作用）-> 仅递归加载依赖，语句改写为注释
  //   - 模块尾部注册 `__modules['<jsAsset>'] = { X };`（JS 侧全局表，
  //     跨 evaluate 共享）
  // 依赖按相对路径递归加载（JsAssetResolver），同一 jsAsset 只执行一次。

  /// 模块加载：递归加载 import 依赖（先依赖后自身），再把自身预处理后
  /// evaluate 进 JS 全局（__modules 注册）。幂等：同 jsAsset 只执行一次。
  Future<void> loadModule(String jsAsset, {String? localRoot}) async {
    if (jsAsset.isEmpty) {
      JsLog.warn('loadModule: jsAsset 为空，已跳过');
      return;
    }
    // 已加载成功 → 短路。注意：只有**完整成功**才进 _loadedModules，
    // 失败（asset 缺失 / evaluate 出错）可再次重试。
    if (_loadedModules.contains(jsAsset)) {
      return;
    }
    // 加载中（防依赖环 + 防并发竞争）→ 复用首个加载的 completer，等它完成
    // 后再继续。同屏多个 JsUiWidget 用同一 manager 时，会并发调用 loadModule，
    // 若直接 return，后续 widget 的 __jsui.mountRoot 会在模块注册前执行 →
    // 找不到组件 → _rootId 为 null → 一直显示进度条。
    //
    // 「加载中」只由 [_loadingCompleters] 是否含该 key 表达；owner 用**本地
    // 变量**持有自己的 completer，结算前用 identical 校验仍归自己所有。
    // **不能**复读 `_loadingCompleters[jsAsset]!`：远程包 fresh 时双实例各自
    // 调一次 invalidateModules、同 key 也会被另一个 owner 覆盖，复读 + 空断言
    // 会在并发首屏炸「Null check operator used on a null value」。
    final inflight = _loadingCompleters[jsAsset];
    if (inflight != null) {
      return inflight.future;
    }
    final completer = Completer<void>();
    _loadingCompleters[jsAsset] = completer;
    // 无等待者时带错误的 Future 会报「未捕获异常」；挂忽略监听消除该噪声，
    // 各等待者仍从自己拿到的 `inflight.future` 收到同一错误。
    completer.future.ignore();
    try {
      // 网络补丁包：localRoot（URL 哈希本地唯一根目录）+ 虚拟路径拼出本地
      // 文件，存在即读本地，不存在回退内置 asset（rootBundle）。不维护任何
      // 映射表——文件系统即索引，与 asset 场景共用同一套相对 import 逻辑。
      final source = await _readModule(jsAsset, localRoot);
      final base = jsAsset.substring(0, jsAsset.lastIndexOf('/') + 1);

      // 1) 递归加载 import 依赖（相对路径，以当前模块目录为基准）
      for (final (_, rel) in _parseImports(source)) {
        final dep = JsAssetResolver.resolve(base, rel);
        await loadModule(dep, localRoot: localRoot);
      }

      // 2) 模块产物求值前确保运行时骨架（runtime.js：环境全局 __modules /
      //    标志 / console / reconciler）已加载 —— 幂等。
      await ensureJsUiRuntime(localRoot: localRoot, moduleAsset: jsAsset);

      // 3) 预处理（export class -> class + 尾部注册；import -> __modules 解构）
      //    后求值
      final processed = _preprocessModule(source, jsAsset, base);
      final evalResult = _runtime.evaluate(processed);
      // 模块被包进 IIFE，完成值恒为 undefined（真正的作用是 __modules
      // 注册这一副作用），因此返回值只在**出错**时有诊断价值——正常路径
      // 不再打印，成功由下面的 `module loaded` 体现。
      final text = evalResult.stringResult;
      if (evalResult.isError ||
          text.startsWith('ERROR:') ||
          text.contains('\nERROR:')) {
        JsLog.error('module eval failed: $jsAsset: $text');
        // evaluate 把异常序列化进返回值 → 视为加载失败，不进
        // _loadedModules，下次可重试。
        throw StateError('module evaluate failed: $text');
      }
      _loadedModules.add(jsAsset);
      // 不逐条打日志：一个页面连带依赖可能有几十个模块（model/xxx.js、flutter.js…），
      // 逐条会把「进入页面」的日志刷满。只记进本批次清单，由页面加载流程结束时
      // 一次性取走汇总（见 [drainLoadedModules]）。
      _loadedInBatch.add(jsAsset);
      _settleModule(jsAsset, completer);
    } catch (e, s) {
      // 读文件 / 依赖加载 / 求值任一失败：owner 与全部等待者一起拿到该异常
      // （可重试），不把等待者永久悬空。
      _settleModule(jsAsset, completer, error: e, stackTrace: s);
      rethrow;
    }
  }

  /// 结算本 owner 的模块加载（成功 / 失败统一走这里）。
  ///
  /// 只有表里那条**仍是本次登记的 completer** 时才摘除并结算：被
  /// [invalidateModules] 清理、或被另一个 owner 覆盖时静默返回——既不误结算
  /// 他人，也不对已被摘除的条目做空断言。
  void _settleModule(
    String jsAsset,
    Completer<void> completer, {
    Object? error,
    StackTrace? stackTrace,
  }) {
    if (!identical(_loadingCompleters[jsAsset], completer)) return;
    _loadingCompleters.remove(jsAsset);
    if (completer.isCompleted) return;
    if (error != null) {
      completer.completeError(error, stackTrace);
    } else {
      completer.complete();
    }
  }

  /// 读取模块源码：网络补丁（[localRoot] 非空）时用「本地根 + 虚拟路径」
  /// 拼文件路径，判断存在读本地；否则回退内置 asset。
  Future<String> _readModule(String jsAsset, String? localRoot) async {
    if (localRoot != null) {
      final file = File('$localRoot/$jsAsset');
      if (file.existsSync()) return file.readAsString();
      // 远程包里缺模块却静默读内置 asset，会让新旧产物混装、行为无法解释。
      // 允许回退（保证老包可跑），但每个文件至少告警一次。
      if (_assetFallbackWarned.add(jsAsset)) {
        JsLog.warn(
          '网络补丁缺少模块 "$jsAsset"（$localRoot），'
          '已回退内置 asset —— 新旧产物可能混装',
        );
      }
    }
    return rootBundle.loadString(jsAsset);
  }

  /// 已告警过的「远程包缺模块 → 回退内置 asset」路径（避免逐次刷屏）。
  static final Set<String> _assetFallbackWarned = {};

  /// 解析模块源码里的 import 语句：`import { A, B } from 'rel';` 与
  /// 副作用形态 `import 'rel';` -> [(名字列表, 'rel')]（副作用形态名字为空）。
  /// 只匹配生成器产物的单行 import 形态。
  ///
  /// **注释行先剔除**：宿主维护的模块（`js/<pkg>.js`）头注释里常有
  /// `//   import { X } from '../packages/<pkg>.js';` 这种用法示例，它不是依赖；
  /// 当成依赖会以本模块目录为基准再叠一层（`packages/packages/...`）导致
  /// 「模块不存在」而整页 boot 失败。
  static List<(List<String>, String)> _parseImports(String source) {
    final code = source
        .split('\n')
        .where((l) => !l.trimLeft().startsWith('//'))
        .join('\n');
    final re = RegExp(
      r"import\s*\{([^}]+)\}\s*from\s*[\x27\x22]([^\x27\x22]+)[\x27\x22]\s*;",
    );
    // 副作用 import：生成器为「源文件 import 了 package:X」的包模块补的依赖
    // （如 `import '../packages/provider.js';`），只需要加载、不需要绑定任何名字。
    final sideEffectRe = RegExp(
      r"^[ \t]*import\s*[\x27\x22]([^\x27\x22]+)[\x27\x22]\s*;[ \t]*$",
      multiLine: true,
    );
    // 命名空间 import：`import * as p from 'rel';`（Dart 的 import 前缀在产物
    // 里就是模块命名空间，用于消解同名类），同样只需要加载依赖。
    final namespaceRe = RegExp(
      r"^[ \t]*import\s*\*\s*as\s+[A-Za-z_$][\w$]*\s*from\s*"
      r"[\x27\x22][^\x27\x22]+[\x27\x22]\s*;[ \t]*$",
      multiLine: true,
    );
    // barrel 的转发：`export { A, B } from 'rel';`（本地依赖包入口产物）。
    // 目标模块必须先求值，本模块才能从 __modules 里取到这些名字再转发。
    final reExportRe = RegExp(
      r"^[ \t]*export\s*\{[^}]+\}\s*from\s*"
      r"[\x27\x22]([^\x27\x22]+)[\x27\x22]\s*;[ \t]*$",
      multiLine: true,
    );
    return [
      for (final m in re.allMatches(code))
        (
          m
              .group(1)!
              .split(',')
              .map((e) => e.trim())
              .where((e) => e.isNotEmpty)
              .toList(),
          m.group(2)!,
        ),
      for (final m in sideEffectRe.allMatches(code))
        (const <String>[], m.group(1)!),
      for (final m in namespaceRe.allMatches(code))
        (const <String>[], _namespaceSource(m.group(0)!)),
      for (final m in reExportRe.allMatches(code))
        (const <String>[], m.group(1)!),
    ];
  }

  /// 从 `import * as p from 'rel';` 里取出相对路径。
  static String _namespaceSource(String line) => RegExp(
    r"from\s*[\x27\x22]([^\x27\x22]+)[\x27\x22]",
  ).firstMatch(line)!.group(1)!;

  /// 文本级预处理：export class -> class + 尾部 __modules 注册；
  /// import 语句 -> `const { A, B } = __modules['<解析后绝对路径>'];`。
  /// 模块注册 key 与实例化寻址都用**绝对资产路径**（assets/...），
  /// 与 JsUiWidget 的 jsAsset 一致。
  static String _preprocessModule(String source, String jsAsset, String base) {
    var out = source;

    // export class/const/function -> class/const/function（收集导出名，同名模块去重）。
    // 扩展支持共享单例产物（export const X = {...}，如静态颜色类）与 export function。
    // 分类型替换，避免 'const' 被误换成 'class'。
    //
    // 允许行首缩进：产物里的值类区（flutter.js）沿用片段源码的缩进，
    // `export` 不在第 0 列；只认 `^export` 会把它们漏成非法语法（Unexpected
    // keyword 'export'）。缩进原样保留，替换只吃关键字。
    final exportReClass = RegExp(
      r"^([ \t]*)export\s+class\s+(\w+)",
      multiLine: true,
    );
    final exportReVar = RegExp(
      r"^([ \t]*)export\s+(const|function)\s+(\w+)",
      multiLine: true,
    );
    final exportNames = <String>[
      for (final m in exportReClass.allMatches(out)) m.group(2)!,
      for (final m in exportReVar.allMatches(out)) m.group(3)!,
    ];
    out = out.replaceAllMapped(
      exportReClass,
      (m) => '${m.group(1)}class ${m.group(2)}',
    );
    out = out.replaceAllMapped(
      exportReVar,
      (m) => '${m.group(1)}${m.group(2)} ${m.group(3)}',
    );

    // barrel 转发：`export { A, B } from 'rel';`（本地依赖包入口产物）。
    // 依赖已由 [loadModule] 先求值；这里解构成局部绑定并计入本模块导出，
    // 完成「原样透出」——否则 `export ... from` 在脚本模式下是非法语法。
    final reExportRe = RegExp(
      r"^([ \t]*)export\s*\{([^}]+)\}\s*from\s*[\x27\x22]([^\x27\x22]+)[\x27\x22]\s*;[ \t]*$",
      multiLine: true,
    );
    List<String> reExportNames(Match m) => m
        .group(2)!
        .split(',')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    for (final m in reExportRe.allMatches(out)) {
      exportNames.addAll(reExportNames(m));
    }
    out = out.replaceAllMapped(reExportRe, (m) {
      final abs = JsAssetResolver.resolve(base, m.group(3)!);
      return "${m.group(1)}const { ${reExportNames(m).join(', ')} } = "
          "__modules['$abs'];";
    });

    // import { A, B } from 'rel' -> const { A, B } = __modules['abs'];
    final importRe = RegExp(
      r"import\s*\{[^}]+\}\s*from\s*[\x27\x22][^\x27\x22]+[\x27\x22]\s*;",
    );
    out = out.replaceAllMapped(importRe, (m) {
      final inner = m.group(0)!;
      final namesMatch = RegExp(r"\{([^}]+)\}").firstMatch(inner)!;
      final relMatch = RegExp(
        r"from\s*[\x27\x22]([^\x27\x22]+)[\x27\x22]",
      ).firstMatch(inner)!;
      final names = namesMatch
          .group(1)!
          .split(',')
          .map((e) => e.trim())
          .where((e) => e.isNotEmpty)
          .toList();
      final abs = JsAssetResolver.resolve(base, relMatch.group(1)!);
      return "const { ${names.join(', ')} } = __modules['$abs'];";
    });

    // 命名空间 import（`import * as p from 'rel';`）：`p` 就是目标模块的导出
    // 对象——Dart 的 import 前缀在产物里靠它承接（同名类因此天然分开）。
    out = out.replaceAllMapped(
      RegExp(
        r"^([ \t]*)import\s*\*\s*as\s+([A-Za-z_$][\w$]*)\s*from\s*"
        r"[\x27\x22]([^\x27\x22]+)[\x27\x22]\s*;[ \t]*$",
        multiLine: true,
      ),
      (m) {
        final abs = JsAssetResolver.resolve(base, m.group(3)!);
        return "${m.group(1)}const ${m.group(2)} = __modules['$abs'];";
      },
    );

    // 副作用 import（`import 'rel';`）：依赖已由 [loadModule] 先求值，这里只
    // 把它改写成注释——产物是脚本模式求值，原生 import 语句会直接语法错误。
    final sideEffectRe = RegExp(
      r"^([ \t]*)import\s*[\x27\x22]([^\x27\x22]+)[\x27\x22]\s*;[ \t]*$",
      multiLine: true,
    );
    out = out.replaceAllMapped(
      sideEffectRe,
      (m) => '${m.group(1)}// 已加载 ${m.group(2)}',
    );

    // 模块尾部注册导出：__modules['jsAsset'] = { A, B };
    if (exportNames.isNotEmpty) {
      out += "\n__modules['$jsAsset'] = { ${exportNames.join(', ')} };";
    }

    // 整体包进 IIFE：class / const 声明局部化。flutter_js（iOS
    // JavaScriptCore）多次 evaluate 共享**全局词法环境**——顶层 class、
    // const 声明跨 evaluate 持久且同名重复声明会抛
    // `Can't create duplicate variable`（如 user 模块的 class User 与
    // 组件模块的 const { User } 冲突）。IIFE 内声明互不干扰，
    // 只有 var 全局表（__modules）跨 evaluate 可见。
    return '''
(function() {
$out
})();''';
  }

  /// 宿主侧已加载模块缓存（防重复加载/递归环）。
  final Set<String> _loadedModules = {};

  /// 最近一批新加载成功的模块路径（顺序即加载顺序：依赖先于自身）。
  ///
  /// 只记录、不打印——页面进入时可能连带几十个模块，逐条日志会把其它信息淹没。
  /// 由页面加载流程在结束时 [drainLoadedModules] 取走并汇总成一条；同屏多个
  /// 页面共用同一运行时，先取走的那个页面会带上全部（模块本身幂等，不会重复计入）。
  final List<String> _loadedInBatch = [];

  /// 取走并清空「本批次已加载模块」清单（调用方负责汇总成一条日志）。
  List<String> drainLoadedModules() {
    final out = List<String>.of(_loadedInBatch);
    _loadedInBatch.clear();
    return out;
  }

  /// 清除所有已加载模块缓存（远程 zip 更新后调用，强制下次重新 evaluate）。
  /// 同时清空 JS 侧 `__modules` 表——依赖模块（flutter.js / packages/provider.js 等）
  /// 下次也会重新加载，避免拿到旧类引用。
  ///
  /// **不清 [_loadingCompleters]**：in-flight 加载各由自己的 owner 用本地
  /// completer 持有，清表会让等待者失去结算对象（旧实现即由此在并发首屏炸
  /// 空断言）；保留后等待者仍等这次加载完成，且不会重复 evaluate 同一产物。
  ///
  /// **重置运行时标记**：新包里可能带**新版 `runtime.js`**（JS 修复随产物发布），
  /// 下一次 [loadModule] 必须重新求值它。runtime.js 内部按内容哈希判断版本，
  /// 哈希不同就原地重建整个 `__jsui`（同一进程内生效），哈希相同则短路
  /// （不重复初始化、不丢状态）。
  void invalidateModules() {
    final count = _loadedModules.length;
    _loadedModules.clear();
    _jsUiInited = false;
    _loadedBundleVersion = null;
    // 清单一并清空：清缓存后重新加载的那批，重新累计到下一个批次汇总里。
    _loadedInBatch.clear();
    // 清空 JS 侧模块注册表：下次 import 解构时 __modules['path'] 为空，
    // loadModule 会重新执行该模块代码并重新注册。
    // 注意：`for...in Object.keys()` 拿到的是数组下标（"0"/"1"），delete 它们
    // 什么也删不掉；必须按下标取回真实键名再 delete。
    _eval('''
      (function() {
        if (typeof __modules === 'object' && __modules) {
          var keys = Object.keys(__modules);
          for (var i = 0; i < keys.length; i++) { delete __modules[keys[i]]; }
        }
      })();
    ''', 'invalidateModules');
    JsLog.log('已清空内存中的 JS 模块与运行时标记（$count 个模块）');
  }

  /// 并发加载等待表：同 jsAsset 正在加载时，后续调用者 await 对应
  /// Completer，等首个加载完成后再继续（防 mount 在模块加载前执行）。
  final Map<String, Completer<void>> _loadingCompleters = {};

  /// 桥通道回调：解出消息体 `ch` 字段，二次分发到唯一处理器表。
  ///
  /// 信封格式（JS 侧 `_app_host_.invoke` / 内部 `send` 产出）：
  ///   `{ ch: <逻辑通道名>, data: {id, args} }`
  ///
  /// `ch` 定位通道；`data` 交给对应处理器（[registerHostMethod] 的包装按
  /// `{id, args}` 还原 Dart 调用语义）。因为处理器表是 static 全局唯一的，
  /// 无论消息路由到哪个 manager 的 runtime，都能找到正确处理器。
  ///
  /// **未注册通道必须在这里回填**：JS 侧 `_app_host_.invoke` 已经为该 id 建好
  /// 一条 pending，丢弃相当于既不 resolve 也不 reject——Promise 永久悬空、
  /// 条目永久滞留在 JS 的表里（宿主侧也没有第二处能认领这个 id）。按「方法
  /// 不存在」处理：留一条日志 + 回填 null 收尾。
  void _dispatch(dynamic raw) {
    if (raw is! Map) {
      JsLog.warn('桥消息不是对象（${raw.runtimeType}），已丢弃');
      return;
    }
    final channel = raw['ch']?.toString() ?? '';
    if (channel.isEmpty) {
      JsLog.warn('桥消息缺少 ch 字段，已丢弃: $raw');
      return;
    }
    final handler = globalMessageHandlers[channel];
    if (handler == null) {
      final data = raw['data'];
      final id = data is Map ? data['id']?.toString() : null;
      JsLog.warn('未注册的宿主通道 "$channel"（id=${id ?? '-'}）：回填 null 收尾');
      _settleHost(id, value: null);
      return;
    }
    handler(raw['data']);
  }
}

/// JS 求值失败（[JsRuntimeManager.evaluateOrThrow]）。
///
/// [toString] 直接给出可展示的诊断信息——不带 `Bad state:` 之类框架前缀，
/// 因为它会被直接投进 UI 的错误兜底视图。
class JsEvalException implements Exception {
  const JsEvalException(this.message);

  final String message;

  @override
  String toString() => message;
}
