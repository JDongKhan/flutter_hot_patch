/// Dart `extension` 声明 → JS 注册语句（`registerExtension(...)`）。
///
/// **翻译只有一条路径**：扩展成员体与类方法体共用 [translateClassMethodBody]
/// （同一个 FieldScope / 表达式渲染器），因此在扩展里写什么、能调什么，与在
/// 类里写什么**完全一致**——`this` 就是接收者、形参/局部变量同一套解析、
/// `return Text(...)` 同一套 widget 渲染、`@HostInjected` 同一张通道表。
///
/// 产物在**扩展声明处**发射（见 component_builder）：
///
///   export const StringLogExtension = registerExtension("String", {
///     logText: function (tag) { ... }
///   }, { id: "lib/src/x.dart#StringLogExtension" });
///
/// 调用点不需要任何处理：`'a'.logText('t')` 在 Dart 与 JS 里是同一个方法调用
/// 形态（成员由运行时【27.5】装到目标类型的原型上）。
///
/// 构建期只拒绝**运行时必然失败**的注册（扩展名撞类名 / 目标类型在 JS 侧没有
/// 对应构造函数），出声跳过，而不是产出必然报错的代码。
library;

import 'package:analyzer/dart/ast/ast.dart';
import 'package:analyzer/dart/ast/visitor.dart';
import 'package:build/build.dart' show log;

import '../class_info.dart';
import '../translator/js_member.dart';
import '../translator/js_translator.dart';
import '../translator/js_value.dart';
import '../translator/element2js.dart';
import '../../shared/host_injected.dart';
import '../../shared/js_class_defs.dart';
import '../../shared/paths.dart';
import '../../shared/runtime_global_types.dart';
import '../../shared/source_index.dart';
import '../../shared/source_location.dart';
import 'analyze_dart_class.dart';

/// 一个已翻译的 extension 声明（产物里的一条 `registerExtension(...)`）。
class ExtensionInfo {
  /// Dart 扩展名（产物里的 `export const <name>`）；无名扩展为空串（不 export）。
  final String name;

  /// 稳定标识 `<sourcePath>#<name>`：同 id 再注册时运行时会先卸载旧成员。
  final String id;

  /// 交给运行时的目标：JS 类引用（同一产物 / import 到）或类型名字面量。
  final String targetJs;

  /// 目标类的 import 语句（null = 不需要 import：同产物内的类 / 语言核心类型 /
  /// 运行时注入类型）。
  final String? targetImport;

  /// 原型成员：成员名 → JS 源码（函数体源码 / `{ get: ... }` 描述符）。
  final Map<String, String> membersJs;

  /// 静态成员：完整的对象字面量成员项（`foo: function () {...}` / `get foo() {...}`）。
  final List<String> staticsEntries;

  /// 成员体里构造调用到的类名（builder 据此递归翻译 / import）。
  final Set<String> dependencies;

  /// 成员体里实际用到的 widget 类型（package → {type}）。
  final Map<String, Set<String>> usedWidgetPackages;

  /// 成员体里用到的 import 前缀 → 模块产物路径（`import * as p` 的登记）。
  final Map<String, String> namespaceImports;

  const ExtensionInfo({
    required this.name,
    required this.id,
    required this.targetJs,
    this.targetImport,
    required this.membersJs,
    this.staticsEntries = const [],
    this.dependencies = const {},
    this.usedWidgetPackages = const {},
    this.namespaceImports = const {},
  });

  /// 注册语句（顶层语句：模块求值时执行一次，成员随产物装到目标原型上）。
  ///
  /// **成员必须由严格模式函数承载**：产物是脚本（非模块）求值，非严格模式下
  /// 以原始值作接收者调用方法时 `this` 会被**装箱**（`new String(...)`），
  /// 于是 Dart 里等价的 `this == 'a'` / `this.length` / 日志里的 `this` 全都
  /// 变成对象语义（`String(this)` 得到 `[object String]`、`__str(this)` 展开成
  /// `{0:'a'…}`）。严格函数的 `this` 才是接收者本身（与 Dart 一致）。严格模式
  /// 对嵌套函数**词法继承**，故整个成员表包一层即可。
  String toJs() {
    final call = StringBuffer()
      ..writeln('registerExtension($targetJs, (function () {')
      ..writeln('  "use strict";')
      ..writeln('  return {');
    for (final e in membersJs.entries) {
      call.writeln('    ${e.key}: ${e.value},');
    }
    call.write('  };\n})()');
    call.write(', { id: ${jsString(id)}');
    if (staticsEntries.isNotEmpty) {
      call.write(', statics: {');
      for (final e in staticsEntries) {
        call.write(' $e,');
      }
      call.write(' }');
    }
    call.write(' })');
    return name.isEmpty ? '$call;' : 'export const $name = $call;';
  }
}

/// 语言核心类型：Dart 类型名 → 运行时直接映射的 JS 内建（见 `__extensionTargetOf`）。
const Set<String> _coreTargets = {
  'int',
  'num',
  'double',
  'String',
  'bool',
  'List',
  'Iterable',
  'Set',
};

/// 明确没有单一 JS 对应物的目标类型（成员无处可挂 / 挂上去必然误伤其它对象）。
const Set<String> _unsupportedTargets = {
  'dynamic',
  'Object',
  'Map',
  'void',
  'Null',
  'Never',
  'Function',
};

/// 本文件（含 import 图）里可用的 extension 运算符：目标类型 → 运算符 → JS 成员名。
///
/// 调用点按**接收者静态类型**查表（类自身声明的实例运算符优先，见
/// `_operatorOwnerOf`）。同一目标 + 同一运算符出现多个声明时视为歧义，不登记——
/// Dart 侧隐式调用本就不合法，生成侧不静默择一。
///
/// 核心类型（int/num/double/String/bool/List/Map/Set/Iterable）不登记：这些类型
/// 已有对应实例运算符，Dart 的 extension 解析不会命中它们，登记只会误改原生运算。
Map<String, Map<String, String>> extensionOperatorsInScope(
  CompilationUnit unit,
  String sourcePath,
) {
  const coreWithOperators = {
    'int', 'num', 'double', 'String', 'bool',
    'List', 'Map', 'Set', 'Iterable', 'Object', 'dynamic',
  };
  final out = <String, Map<String, String>>{};
  final ambiguous = <String>{};
  void scan(CompilationUnit u, String file, {required bool sameFile}) {
    for (final d in u.declarations.whereType<ExtensionDeclaration>()) {
      // 具名 extension 被 hide / 未 show 时，其运算符不进入本文件的作用域；
      // 无名 extension 没有名字可供组合子过滤，import 即生效。
      final name = d.name?.lexeme;
      if (!sameFile &&
          name != null &&
          name.isNotEmpty &&
          !importedSymbolVisible(unit, sourcePath, file, name)) {
        continue;
      }
      final on = d.onClause?.extendedType;
      if (on == null) continue;
      final target = eraseType(on.toSource());
      if (target.isEmpty || coreWithOperators.contains(target)) continue;
      for (final m in d.members.whereType<MethodDeclaration>()) {
        if (m.isStatic || !m.isOperator) continue;
        final symbol = m.name.lexeme;
        final unary = (m.parameters?.parameters ?? const []).isEmpty;
        final jsName = operatorJsName(symbol, unary: unary);
        if (jsName == null) continue;
        final key = '$target:$symbol';
        if (ambiguous.contains(key)) continue;
        final bySymbol = out[target] ??= <String, String>{};
        final prev = bySymbol[symbol];
        if (prev != null && prev != jsName) {
          ambiguous.add(key);
          bySymbol.remove(symbol);
          continue;
        }
        bySymbol[symbol] = jsName;
      }
    }
  }

  scan(unit, sourcePath, sameFile: true);
  for (final e in libraryUnitsOf(unit, sourcePath)) {
    if (e.$1 != sourcePath) scan(e.$2, e.$1, sameFile: true);
  }
  for (final file in resolveImportFiles(unit, sourcePath)) {
    final u = parseUnitFile(file);
    if (u != null) scan(u, file, sameFile: false);
  }
  return out;
}

/// 本文件（含 import / export 转发图）可见的**具名 extension** → 分派信息。
///
/// 用途：显式调用 `E(x).m(...)` 必须按**扩展身份**分派（Dart 的第三条规则），
/// 不能退化成 `x.m()` 交给原型——同目标同名扩展时只有身份能区分。
/// 私有扩展只在声明它的 library 内可见，故跨文件扫描时不收 `_` 开头的名字。
Map<String, ExtensionScope> extensionScopesInScope(
  CompilationUnit unit,
  String sourcePath,
) {
  final out = <String, ExtensionScope>{};
  void scan(CompilationUnit u, String file,
      {required bool includePrivate, required bool sameFile}) {
    for (final d in u.declarations.whereType<ExtensionDeclaration>()) {
      final name = d.name?.lexeme;
      if (name == null || name.isEmpty) continue;
      if (!includePrivate && name.startsWith('_')) continue;
      if (!sameFile && !importedSymbolVisible(unit, sourcePath, file, name)) {
        continue;
      }
      if (out.containsKey(name)) continue;
      final members = <String, Set<ExtensionMemberKind>>{};
      for (final m in d.members) {
        if (m is! MethodDeclaration || m.isStatic || m.isOperator) continue;
        final kind = m.isGetter
            ? ExtensionMemberKind.getter
            : m.isSetter
                ? ExtensionMemberKind.setter
                : ExtensionMemberKind.method;
        (members[m.name.lexeme] ??= <ExtensionMemberKind>{}).add(kind);
      }
      final onType = d.onClause?.extendedType;
      out[name] = ExtensionScope(
        file,
        onType is NamedType ? onType.name2.lexeme : null,
        members,
      );
    }
  }

  scan(unit, sourcePath, includePrivate: true, sameFile: true);
  for (final e in libraryUnitsOf(unit, sourcePath)) {
    if (e.$1 != sourcePath) {
      scan(e.$2, e.$1, includePrivate: true, sameFile: true);
    }
  }
  for (final file in resolveImportFiles(unit, sourcePath)) {
    final u = parseUnitFile(file);
    if (u != null) {
      scan(u, file, includePrivate: false, sameFile: false);
    }
  }
  return out;
}

/// 构建期发现「同一目标类型上两个扩展声明了同名成员」：Dart 里隐式调用是
/// 歧义编译错误，产物不会安装该成员（显式 `E(x).m` 仍可用）。运行时不告知
/// 加载顺序，构建期先说清楚，避免把问题留到线上。
void warnExtensionConflicts(
  Map<String, ExtensionScope> scopes,
  String sourcePath,
) {
  final byTarget = <String, Map<String, List<String>>>{};
  for (final e in scopes.entries) {
    final target = e.value.target;
    if (target == null) continue;
    for (final member in e.value.members.keys) {
      (byTarget[target] ??= {}).putIfAbsent(member, () => []).add(e.key);
    }
  }
  for (final t in byTarget.entries) {
    for (final m in t.value.entries) {
      if (m.value.length < 2) continue;
      log.warning('[hot_patch_generator] $sourcePath: 扩展 ${m.value.join(' / ')} '
          '都在 ${t.key} 上声明了 ${m.key}：隐式调用在 Dart 里是歧义编译错误，'
          '产物不安装该成员；请改用显式调用（${m.value.first}(x).${m.key}）。');
    }
  }
}

/// 本库声明的全部 `extension`（含无名扩展）。
///
/// 给出 [sourcePath] 时扫描整个库（根 + part）——同库声明共享一份产物。
List<ExtensionDeclaration> extensionDeclarations(
  CompilationUnit unit, [
  String? sourcePath,
]) {
  final units = sourcePath == null
      ? [(sourcePath ?? '', unit)]
      : libraryUnitsOf(unit, sourcePath);
  return [
    for (final e in units)
      ...e.$2.declarations.whereType<ExtensionDeclaration>(),
  ];
}

/// 本库是否声明了 extension（纯扩展文件也必须产出产物）。
bool hasExtensionDeclaration(CompilationUnit unit, [String? sourcePath]) =>
    extensionDeclarations(unit, sourcePath).isNotEmpty;

/// 一个 extension 在**调用点**会出现的名字（用来判断本文件有没有用到它）。
///
///   - 实例成员（方法 / getter / setter）→ 成员名：`'a'.logText()` 里 `logText`
///     是标识符，与本文件任意标识符同名即视为用到；
///   - 静态成员 → 扩展名：`ExtName.foo()` 里 `ExtName` 是标识符；
///   - 扩展名本身也收：`providesX` 之类的成员名可能与扩展名重合。
///
/// 判定刻意**偏宽松**（任何同名标识符都算命中，不区分接收者类型——无类型解析
/// 时无法判定接收者是谁）：误判方向是「多导入一个产物」，代价只是多执行一次
/// 幂等注册；不会出现「用到却没导入」的漏判。
Set<String> extensionCallSiteNames(ExtensionDeclaration decl) {
  final out = <String>{};
  final name = decl.name?.lexeme;
  if (name != null && name.isNotEmpty) out.add(name);
  for (final member in decl.members.whereType<MethodDeclaration>()) {
    if (member.isStatic) {
      // 静态成员只能写成 `ExtName.foo()`，调用点出现的是扩展名（上面已收）。
      continue;
    }
    out.add(member.name.lexeme);
  }
  return out;
}

/// 本文件里出现过的全部标识符（宽松「用到」判据，见 [extensionCallSiteNames]）。
Set<String> identifierNamesIn(CompilationUnit unit) {
  final collector = _IdentifierCollector();
  unit.accept(collector);
  return collector.names;
}

/// 本产物**承载的全部代码**里出现过的标识符：本文件（含 extension 成员）
/// + 被 `with` 的 mixin 成员。
///
/// mixin 成员会被线性化进本产物，其方法体里的 `'x'.logText()` 同样要求声明
/// 该扩展的产物被加载；只扫本文件会漏掉「调用只写在 mixin 里」的场景。
Set<String> identifierNamesInProduct(CompilationUnit unit, String sourcePath) {
  final names = <String>{};
  for (final e in libraryUnitsOf(unit, sourcePath)) {
    names.addAll(identifierNamesIn(e.$2));
  }
  for (final d in _productHostClasses(unit, sourcePath)) {
    for (final (mixinDecl, _) in resolveMixinDeclRefs(d, unit, sourcePath)) {
      names.addAll(_identifierNamesOfMembers(mixinDecl.members));
    }
  }
  return names;
}

/// 本产物**承载的代码**能看见的源文件集合：本文件 import 图 + 被 `with` 的
/// mixin 声明文件的 import 图。
///
/// mixin 成员被线性化进本产物，写在 mixin 文件里的 `'x'.logText()` 同样需要
/// 该扩展的产物被加载；只扫本文件的 import 图看不到 mixin 文件 import 的
/// 扩展声明库（`import` 目标不逐层深入）。
Set<String> extensionScopeFiles(CompilationUnit unit, String sourcePath) {
  final files = <String>{...resolveImportFiles(unit, sourcePath)};
  // 同库 part：它们与根共享 import 图，产物也是同一份。
  for (final e in libraryUnitsOf(unit, sourcePath)) {
    if (e.$1 == sourcePath) continue;
    files.addAll(resolveImportFiles(e.$2, e.$1));
  }
  for (final d in _productHostClasses(unit, sourcePath)) {
    for (final (_, mixinFile) in resolveMixinDeclRefs(d, unit, sourcePath)) {
      final mixinUnit = parseUnitFile(mixinFile);
      if (mixinUnit == null) continue;
      files.addAll(resolveImportFiles(mixinUnit, mixinFile));
    }
  }
  return files;
}

/// 本产物承载代码的宿主类：本文件的公共类 + 其同文件 State 类。
///
/// `with` 子句通常写在**私有 State 类**上（`class _XState extends State<X>
/// with M`），只遍历公共类会看不到它携带的 mixin 成员——而那段代码确实会被
/// 线性化进本产物。
Iterable<ClassDeclaration> _productHostClasses(
  CompilationUnit unit, [
  String? sourcePath,
]) sync* {
  final units = sourcePath == null
      ? [(sourcePath ?? '', unit)]
      : libraryUnitsOf(unit, sourcePath);
  for (final e in units) {
    for (final d in e.$2.declarations.whereType<ClassDeclaration>()) {
      if (d.name.lexeme.startsWith('_')) continue;
      yield* classAndStateDecls(d, e.$2);
    }
  }
}

/// 任意成员表里出现过的标识符（与 [identifierNamesIn] 同一收集器）。
Set<String> _identifierNamesOfMembers(Iterable<ClassMember> members) {
  final collector = _IdentifierCollector();
  for (final m in members) {
    m.accept(collector);
  }
  return collector.names;
}

class _IdentifierCollector extends RecursiveAstVisitor<void> {
  final Set<String> names = {};

  @override
  void visitSimpleIdentifier(SimpleIdentifier node) {
    names.add(node.name);
    super.visitSimpleIdentifier(node);
  }

  @override
  void visitPrefixedIdentifier(PrefixedIdentifier node) {
    names.add(node.identifier.name);
    super.visitPrefixedIdentifier(node);
  }

  @override
  void visitPropertyAccess(PropertyAccess node) {
    names.add(node.propertyName.name);
    super.visitPropertyAccess(node);
  }
}

/// 成员体里把类型参数当**值**用的位置（`T.toString()` / `T == int` / `as T` 的
/// 表达式侧）。类型注解走 `NamedType`（名字是 Token），不会命中这里。
class _TypeParamValueUse extends RecursiveAstVisitor<void> {
  _TypeParamValueUse(this.names);

  final Set<String> names;
  final Set<String> found = {};

  @override
  void visitSimpleIdentifier(SimpleIdentifier node) {
    if (names.contains(node.name)) found.add(node.name);
    super.visitSimpleIdentifier(node);
  }
}

/// 一个扩展成员的声明种类（跟着声明走，不按名字存）。
enum _ExtMemberKind { method, getter, setter }

/// 扩展成员声明 → 方法模型 + 种类。
class _ExtMemberDecl {
  const _ExtMemberDecl({required this.kind, required this.method});

  final _ExtMemberKind kind;
  final ClassMethod method;
}

/// 一个扩展成员名的聚合槽位：同名 getter / setter 共用一个槽（Dart 允许），
/// 方法单独占 [methodValue]。
class _ExtMemberSlot {
  String? getBody;
  String? setBody;
  List<String> setParams = const [];

  /// 方法（含运算符）的函数表达式源码（已由 [jsMethodValue] 渲染）。
  String? methodValue;
}

/// 静态成员的聚合槽位：与实例成员同一模型（同名 get/set 合并、方法与字段互斥）。
/// 对象字面量里 `get x() {}` 与 `set x(v) {}` 可以并存，两个方向各发一项。
class _ExtStaticSlot {
  String? value;
  String? getBody;
  String? setBody;
  List<String> setParams = const [];
}

/// 翻译一个 extension → [ExtensionInfo]；构建期不成立的声明返回 null（已告警）。
///
/// [ownProduct]：本产物的身份（`patch/a/b.js`），用于判断目标类是否就在**同
/// 一个产物**里（是 → 直接传裸类名；否 → 从目标产物 import）。
/// [productOf]：类名 → 该类的**产物身份**（`patch/a/b.js`）；null = 该类在 JS
/// 侧没有产物。与类翻译共用同一份 import 图口径〔同文件 / import 源文件 /
/// 本地依赖包的包模块〕。
ExtensionInfo? translateExtension(
  ExtensionDeclaration decl,
  CompilationUnit unit,
  String sourcePath, {
  required String ownProduct,
  required Map<String, ClassInfo> classTable,
  required String? Function(String name) importResolver,
  Set<String> jsClassWidgets = const {},
  Set<String> delegateClassWidgets = const {},
  Set<String> ignoredTypes = const {},
  Set<String> globalConsts = const {},
  Set<String> classNamesInUnit = const {},
  String? Function(String name)? productOf,
  Map<String, String> prefixProducts = const {},
  Map<String, Map<String, String>> extensionOperators = const {},
  Map<String, ExtensionScope> extensionNames = const {},
}) {
  final name = decl.name?.lexeme;
  final label = name ?? '<unnamed>';
  if (name != null && classNamesInUnit.contains(name)) {
    log.warning(
      '[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $name 与本文件里的类名冲突，'
      '已跳过（Dart 里同名二者无法被引用）。',
    );
    return null;
  }
  final onClause = decl.onClause;
  if (onClause == null) {
    log.warning('[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 缺少 on 子句，'
        '已跳过。');
    return null;
  }
  final extendedType = onClause.extendedType;
  // 可空目标（`extension E on String?`）：null 接收者在 JS 侧没有原型可分派，
  // 只能靠编译期静态分派承接，而当前是原型注册方案 → 构建期直接拒绝，不产出
  // 必然失效的注册（Dart 里这类扩展允许在 null 上调用）。
  if (extendedType is NamedType && extendedType.question != null) {
    log.warning(
      '[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 的目标可空'
      '（${extendedType.toSource()}）：null 接收者无法在原型上分派，已跳过。',
    );
    return null;
  }
  final target = extendedType is NamedType
      ? extendedType.name2.lexeme
      : extendedType.toSource().trim();
  if (_unsupportedTargets.contains(target)) {
    log.warning(
      '[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 的目标 $target '
      '在 JS 侧没有单一类型（Map/Object/dynamic…），已跳过。',
    );
    return null;
  }
  if (hostWrapperTypes.contains(target)) {
    // 宿主 widget 的 JS 包装类是「构造即产出元素」：把成员挂到它的原型上不会
    // 作用到宿主真对象，属于必然无效的注册，构建期直接拒绝。
    log.warning(
      '[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 的目标 $target 是'
      '宿主 widget（JS 侧没有实体原型），已跳过。',
    );
    return null;
  }

  final classInfo = classTable[target];
  final targetPkg = classInfo == null ? null : packageNameOf(classInfo.sourceFile);
  if (classInfo != null &&
      targetPkg != null &&
      nonTranslatedPackages.contains(targetPkg)) {
    log.warning(
      '[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 的目标 $target '
      '来自未翻译的框架包（$targetPkg），JS 侧没有代理类，已跳过。',
    );
    return null;
  }
  final known = _coreTargets.contains(target) ||
      runtimeGlobalTypes().contains(target) ||
      runtimeTypeAliases().contains(target) ||
      jsClassWidgets.contains(target) ||
      classInfo != null;
  if (!known) {
    log.warning(
      '[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 的目标 $target '
      '在本文件可见范围内找不到 JS 侧实现，注册会失败，已跳过。',
    );
    return null;
  }

  // 目标表达式：能找到 JS 产物 → 直接传构造函数（同一个模块表保证是同一个类）；
  // 否则传类型名，由运行时按「核心映射 → 私有别名 → G[name]」解析。
  String targetJs;
  String? targetImport;
  final targetProduct = productOf?.call(target);
  if (targetProduct != null) {
    targetJs = target;
    if (targetProduct != ownProduct) {
      targetImport = "import { $target } from "
          "'${relativeProduct(ownProduct, targetProduct)}';";
    }
  } else if (jsClassWidgets.contains(target)) {
    // 有 JS 类、但不在本文件 import 图里的框架组件（provider 等）：按 package 模块取类。
    targetJs = target;
    targetImport = "import { $target } from "
        "'${relativeProduct(ownProduct, packageModulePath(widgetPackageOf(target)))}';";
  } else {
    targetJs = jsString(target);
    if (classInfo != null) {
      // 类在本文件可见（import 到的普通类），但没有可 import 的 JS 产物
      // （不在组件产物图里，也不在 package 模块里）。运行时按类型名 `G[name]`
      // 兜底，而生成的类都包在模块 IIFE 内、不挂 G → 注册会失败。
      // 出声提示（不阻断构建）：该扩展在 JS 侧不会生效。
      log.warning(
        '[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 的目标 $target '
        '在 ${classInfo.sourceFile} 里，但那个文件没有本文件可引用的 JS 产物'
        '（未被任何组件引用），该扩展在 JS 侧不会生效。',
      );
    }
  }

  // 成员建模：与类完全同一口径（getter / setter 都保留，static 另放）。
  // **kind 跟着声明走**，不放进「名字 → kind」的表：同名 getter / setter 是两个
  // 独立声明，按名字存 kind 会被后者覆盖（产物只剩 setter）。
  final memberDecls = <_ExtMemberDecl>[];
  for (final member in decl.members) {
    if (member is MethodDeclaration) {
      if (member.isStatic) continue;
      final memberName = member.name.lexeme;
      if (member.isOperator) {
        // extension 运算符：与类运算符同一张映射表（`__op$add` …），成员挂到
        // 目标原型；调用点按接收者静态类型改写成 `receiver.__op$xxx(...)`。
        final unary = (member.parameters?.parameters ?? const []).isEmpty;
        final jsName = operatorJsName(memberName, unary: unary);
        if (jsName == null) {
          log.warning('[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label'
              '.operator $memberName 暂不支持（JS 侧无等价成员），已跳过。');
          continue;
        }
        memberDecls.add(_ExtMemberDecl(
          kind: _ExtMemberKind.method,
          method: ClassMethod(
            name: jsName,
            params: jsMethodParams(member),
            isAsync: member.body.isAsynchronous,
            isVoid: isVoidReturn(member),
            returnsWidget: false,
            body: member.body,
            parameters: member.parameters,
            positionalParamCount: positionalParamCountOf(member),
            hasNamedParams: hasNamedParamOf(member),
            operatorSymbol: memberName,
          ),
        ));
      } else if (member.isGetter) {
        memberDecls.add(_ExtMemberDecl(
          kind: _ExtMemberKind.getter,
          method: ClassMethod(
            name: memberName,
            params: const [],
            isGetter: true,
            returnsWidget: returnsWidgetOf(member),
            body: member.body,
          ),
        ));
      } else if (member.isSetter) {
        memberDecls.add(_ExtMemberDecl(
          kind: _ExtMemberKind.setter,
          method: ClassMethod(
            name: memberName,
            params: jsMethodParams(member),
            isVoid: true,
            returnsWidget: false,
            body: member.body,
            parameters: member.parameters,
          ),
        ));
      } else {
        memberDecls.add(_ExtMemberDecl(
          kind: _ExtMemberKind.method,
          method: ClassMethod(
            name: memberName,
            params: jsMethodParams(member),
            isAsync: member.body.isAsynchronous,
            isVoid: isVoidReturn(member),
            returnsWidget: returnsWidgetOf(member),
            body: member.body,
            parameters: member.parameters,
            positionalParamCount: positionalParamCountOf(member),
            hasNamedParams: hasNamedParamOf(member),
          ),
        ));
      }
    } else if (member is ConstructorDeclaration) {
      log.warning('[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 里声明了'
          '构造函数（Dart 不允许），已忽略。');
    }
  }
  final memberMethods = [for (final d in memberDecls) d.method];

  // 静态成员：与实例成员同一条翻译规则。必须**先**收进 hostInfo，成员体翻译时
  // 裸引用静态字段 / 方法才能解析成 `<扩展名>.<name>`（此前 staticFields 为空，
  // 这些语句被静默丢弃）。
  final staticFields = <ClassField>[];
  final staticMethodInfos = <ClassMethod>[];
  final staticMethodByDecl = <MethodDeclaration, ClassMethod>{};
  for (final member in decl.members) {
    if (member is FieldDeclaration && member.isStatic) {
      for (final v in member.fields.variables) {
        staticFields.add(ClassField(
          name: v.name.lexeme,
          typeName: member.fields.type?.toSource() ?? 'dynamic',
          isStatic: true,
          initializer: v.initializer,
        ));
      }
    } else if (member is MethodDeclaration && member.isStatic) {
      final info = ClassMethod(
        name: member.name.lexeme,
        params: member.isGetter ? const [] : jsMethodParams(member),
        isGetter: member.isGetter,
        isAsync: member.body.isAsynchronous,
        isVoid: isVoidReturn(member),
        returnsWidget: returnsWidgetOf(member),
        body: member.body,
        parameters: member.parameters,
        positionalParamCount: positionalParamCountOf(member),
        hasNamedParams: hasNamedParamOf(member),
        isStatic: true,
      );
      staticMethodInfos.add(info);
      staticMethodByDecl[member] = info;
    }
  }

  // 依赖：整个扩展声明里出现的类型引用（成员体 / 初始化器 / 字段类型 /
  // `on` 目标），与类共用同一个收集器——不另写扩展专用的启发式。
  final used = <String, ClassInfo>{};
  for (final n in dependenciesOf(decl)) {
    final info = classTable[n];
    if (info != null) used[n] = info;
  }

  final hostFunctions = buildHostFunctions(unit, sourcePath);
  final modelClassNames = <String>{
    for (final e in classTable.entries)
      if (!e.value.isComponent) e.key,
  };
  final parseCtx = ElementTranslateContext(
    propByField: const {},
    actionByMethod: {
      for (final m in memberMethods)
        if (!m.isGetter && !m.isVoid) m.name: m.name,
    },
    methodNames: {for (final m in memberMethods) m.name},
    getterNames: {
      for (final m in memberMethods)
        if (m.isGetter) m.name,
    },
    sourcePath: sourcePath,
    importResolver: importResolver,
    globalConsts: globalConsts,
    hostFunctions: hostFunctions,
    jsClassWidgets: jsClassWidgets,
    delegateClassWidgets: delegateClassWidgets,
    ignoredTypes: ignoredTypes,
    modelClassNames: modelClassNames,
    prefixProducts: prefixProducts,
  );

  // 扩展没有实例字段：作用域里只有形参 / 局部变量 / 本扩展的其它成员（`this`
  // 就是接收者，故成员间调用落成 `this.xxx(...)`）。
  final hostInfo = ClassInfo(
    // 具名扩展的静态成员在 JS 侧挂在 `export const <扩展名>` 命名空间上；
    // 无名扩展没有可引用的命名空间（静态成员本就无法从 Dart 侧引用），
    // className 置空，避免产出 `<unnamed>._v` 这种非法标识符。
    name: name ?? '',
    sourceFile: sourcePath,
    instanceFields: const [],
    staticFields: staticFields,
    methods: [...memberMethods, ...staticMethodInfos],
    isComponent: false,
  );

  // 泛型扩展（`extension E<T> on List<T>`）：成员注册在**擦除后的目标原型**
  // 上（`List<T>` → `Array`），签名里的类型位置不受影响；但成员体里把 `T`
  // 当值用（`T.toString()` / `T == int`）时，接收者没有类型元信息可读——
  // 原型方案下无法还原，出声说明而不是让产物里留一个未定义名。
  final extTypeParams = [
    for (final tp
        in decl.typeParameters?.typeParameters ?? const <TypeParameter>[])
      tp.name.lexeme,
  ];
  if (extTypeParams.isNotEmpty) {
    final usedInBody = <String>{};
    for (final member in decl.members) {
      if (member is! MethodDeclaration) continue;
      final v = _TypeParamValueUse({...extTypeParams});
      member.body.accept(v);
      usedInBody.addAll(v.found);
    }
    if (usedInBody.isNotEmpty) {
      log.warning(
        '[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 的类型参数 '
        '${usedInBody.join(' / ')} 在成员体里按值使用；目标 $target 在 JS 侧只有'
        '「擦除后的原型」（无 typeArguments 元信息），这些用法运行时读不到类型名。'
        '仅类型位置（返回类型 / 形参类型 / 局部变量声明）可用。',
      );
    }
  }

  final membersJs = <String, String>{};
  // 按**名字**聚合成员：Dart 允许同名 `get x` / `set x` 共存，成员表里必须合并成
  // 一个 `{ get, set }` 描述符（按名字各写一项会让后写的一方覆盖前一方）。
  final memberSlots = <String, _ExtMemberSlot>{};
  parseCtx.withExprRenderer(() {
    for (final decl in memberDecls) {
      final m = decl.method;
      final body = translateClassMethodBody(
        hostInfo,
        m,
        used,
        hostFunctions: hostFunctions,
        renderer: parseCtx,
        globalConsts: globalConsts,
        depth: 0,
        extensionOperators: extensionOperators,
        extensionNames: extensionNames,
      );
      final slot = memberSlots.putIfAbsent(m.name, () => _ExtMemberSlot());
      switch (decl.kind) {
        case _ExtMemberKind.getter:
          slot.getBody = body;
        case _ExtMemberKind.setter:
          slot.setBody = body;
          slot.setParams = m.params;
        case _ExtMemberKind.method:
          // 方法（含运算符）与类方法共用同一条发射规则：生成器 / async / 参数
          // 约定全部一致，不再由 extension 自己拼函数头。
          slot.methodValue = jsMethodValue(
            params: jsSignatureParams(m),
            body: body,
            isAsync: m.isAsync,
            isGenerator: m.body?.isGenerator == true,
          );
      }
    }
  });
  for (final e in memberSlots.entries) {
    final slot = e.value;
    membersJs[e.key] = slot.methodValue ??
        jsAccessorValue(
          getBody: slot.getBody,
          setBody: slot.setBody,
          setParams: slot.setParams,
        );
  }

  // 静态成员：与实例成员同一条翻译（静态里成员裸引用落成 `<扩展名>.<name>`）。
  // 按名字聚合槽位：`static get x` / `static set x` 必须在同一个对象字面量里
  // 各发一项访问器（若把 setter 当普通方法发 `x: function(v){}`，同名 getter 会被
  // 这个 data property 覆盖）。
  final staticsEntries = <String>[];
  final staticSlots = <String, _ExtStaticSlot>{};
  for (final member in decl.members) {
    if (member is MethodDeclaration && member.isStatic) {
      final info = staticMethodByDecl[member]!;
      final body = parseCtx.withExprRenderer(() => translateClassMethodBody(
            hostInfo,
            info,
            used,
            hostFunctions: hostFunctions,
            renderer: parseCtx,
            globalConsts: globalConsts,
            depth: 0,
            extensionOperators: extensionOperators,
            extensionNames: extensionNames,
          ));
      final slot = staticSlots.putIfAbsent(info.name, () => _ExtStaticSlot());
      if (member.isGetter) {
        slot.getBody = body;
      } else if (member.isSetter) {
        slot.setBody = body;
        slot.setParams = info.params;
      } else {
        slot.value = jsMethodValue(
          params: jsSignatureParams(info),
          body: body,
          isAsync: info.isAsync,
          isGenerator: member.body.isGenerator,
        );
      }
    } else if (member is FieldDeclaration) {
      if (!member.isStatic) {
        log.warning('[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 里声明了'
            '实例字段（Dart 不允许），已忽略。');
        continue;
      }
      for (final v in member.fields.variables) {
        final value = literalToJs(v.initializer);
        if (value == null) {
          log.warning('[hot_patch_generator] ${sourceAt(sourcePath, decl)}: extension $label 的静态'
              '字段 ${v.name.lexeme} 初值不是编译期常量，已跳过。');
          continue;
        }
        staticSlots.putIfAbsent(v.name.lexeme, () => _ExtStaticSlot()).value = value;
      }
    }
  }
  for (final e in staticSlots.entries) {
    final slot = e.value;
    if (slot.getBody != null) {
      staticsEntries.add(jsLiteralAccessor(
        name: e.key,
        isGetter: true,
        body: slot.getBody!,
      ));
    }
    if (slot.setBody != null) {
      staticsEntries.add(jsLiteralAccessor(
        name: e.key,
        isGetter: false,
        body: slot.setBody!,
        setParams: slot.setParams,
      ));
    }
    if (slot.getBody == null && slot.setBody == null && slot.value != null) {
      staticsEntries.add('${e.key}: ${slot.value}');
    }
  }

  return ExtensionInfo(
    name: name ?? '',
    id: '$sourcePath#${name ?? '@on:$target'}',
    targetJs: targetJs,
    targetImport: targetImport,
    membersJs: membersJs,
    staticsEntries: staticsEntries,
    // 目标类本身也是依赖：同文件声明的目标类必须连带产出（`registerExtension(ProbeModel,
    // …)` 裸引用它）；类表里有它但本产物没有 → ReferenceError。
    dependencies: {
      ...parseCtx.dependencies,
      ...used.keys,
      if (classNamesInUnit.contains(target)) target,
    },
    usedWidgetPackages: parseCtx.usedWidgetPackages,
    namespaceImports: parseCtx.namespaceImports,
  );
}
