/// 全量类表：把文件（同文件 + 跨文件 import）的全部公共 Dart 类收集成
/// ClassInfo 索引——**包含** @PatchEntry 组件与 widget 类（打 isComponent
/// 标记）。翻译只有一个入口（translateClass）在这张表里按名字解析依赖。
library;

import 'package:analyzer/dart/ast/ast.dart';

import 'analyze_dart_class.dart';
import '../class_info.dart';
import '../translator/js_value.dart';
import '../../shared/source_index.dart';

/// 全量「类表」：把一个文件（同文件 + 跨文件 import）的全部公共 Dart 类
/// （非私有；**含抽象类**——`abstract class` 同样翻译成普通 JS class，抽象
/// 成员抛错兜底）收集成 ClassInfo 索引——**包含** @PatchEntry 组件与 widget
/// 类（打 [ClassInfo.isComponent] 标记），也包含 `@HostInjected` 类（其标注方法
/// 的实现留在宿主，JS 侧方法体改为 `_app_host_.invoke`）。
///
/// 翻译只有一个入口（[translateClass]）：任意类引用到的名字（字段类型、
/// 方法体构造、build 树自定义组件）都在这张表里按同一规则解析；widget 类
/// 条目标记 isComponent，不作为模型内联、组件类型字段不当模型构造。
Map<String, ClassInfo> buildClassTable(CompilationUnit unit, String sourcePath) {
  // 两阶段：先收集类声明，再据**全量类名表**求每个类的依赖
  // （referencedClassNames 统一在 dart2js 层，builder 不自行计算）。
  // 值里的 CompilationUnit 是类的声明单元（本类 / 所在 import 文件）——
  // 解析 with 子句的 mixin 声明需要它（resolveMixinDeclRefs）。
  final decls = <String, (ClassDeclaration, String, bool, CompilationUnit)>{};
  void addFile(
    ClassDeclaration d,
    String file,
    CompilationUnit from, {
    required bool sameFile,
    CompilationUnit? importer,
    String? importerPath,
  }) {
    final name = d.name.lexeme;
    if (name.startsWith('_') || decls.containsKey(name)) return;
    // import 的 show / hide：被隐藏 / 未 show 的类不进入可见类表。
    if (!sameFile &&
        importer != null &&
        importerPath != null &&
        !importedSymbolVisible(importer, importerPath, file, name)) {
      return;
    }
    // `@HostInjected` 类照常进表：类结构（含方法签名）在 JS 侧仍输出，只有被
    // 标注方法的**方法体**改为 `_app_host_.invoke`（见 ClassMethod.hostChannel），
    // 调用点是普通静态调用（`AppRouter.pop()`）。
    decls[name] = (d, file, isWidgetClassDecl(d), from);
  }

  for (final d in unit.declarations.whereType<ClassDeclaration>()) {
    addFile(d, sourcePath, unit, sameFile: true);
  }
  // 同库 part 文件：共享命名空间与同一份产物，按 sameFile 收（含私有类）。
  for (final e in libraryUnitsOf(unit, sourcePath)) {
    if (e.$1 == sourcePath) continue;
    for (final d in e.$2.declarations.whereType<ClassDeclaration>()) {
      addFile(d, e.$1, e.$2, sameFile: true);
    }
  }
  for (final file in resolveImportFiles(unit, sourcePath)) {
    final importUnit = parseUnitFile(file);
    if (importUnit == null) continue;
    for (final d in importUnit.declarations.whereType<ClassDeclaration>()) {
      addFile(d, file, importUnit,
          sameFile: false, importer: unit, importerPath: sourcePath);
    }
  }

  // 被 `with` 的跨文件 mixin：把 mixin 声明文件（及其 import 图）里的类并入
  // 类表——mixin 成员会被线性化进本产物，其中引用的类必须能在类表里按名字
  // 解析并生成 import。只随「实际被 with 的 mixin」展开，不做全量 import 闭包；
  // 新并入的类同样可能 `with` 别的 mixin，故按队列逐层展开（每个 mixin 文件
  // 只展开一次，线性复杂度）。
  final visitedMixinFiles = <String>{sourcePath};
  final pending = <(ClassDeclaration, String, CompilationUnit)>[
    for (final e in decls.values) (e.$1, e.$2, e.$4),
  ];
  while (pending.isNotEmpty) {
    final (decl, file, unit) = pending.removeLast();
    // StatefulWidget 的 `with` 写在**同文件的私有 State 类**上（私有类不在
    // 类表里），故必须按 widget + State 合并扫描。
    for (final cls in classAndStateDecls(decl, unit)) {
      for (final (_, mixinFile) in resolveMixinDeclRefs(cls, unit, file)) {
        if (!visitedMixinFiles.add(mixinFile)) continue;
        final mixinUnit = parseUnitFile(mixinFile);
        if (mixinUnit == null) continue;
        final sources = <(CompilationUnit, String, bool)>[
          for (final e in libraryUnitsOf(mixinUnit, mixinFile))
            (e.$2, e.$1, true),
          for (final f in resolveImportFiles(mixinUnit, mixinFile))
            if (parseUnitFile(f) case final u?) (u, f, false),
        ];
        for (final (sourceUnit, sourceFile, sameFile) in sources) {
          for (final d in sourceUnit.declarations.whereType<ClassDeclaration>()) {
            if (decls.containsKey(d.name.lexeme)) continue;
            addFile(d, sourceFile, sourceUnit,
                sameFile: sameFile,
                importer: sameFile ? null : mixinUnit,
                importerPath: sameFile ? null : mixinFile);
            if (decls.containsKey(d.name.lexeme)) {
              pending.add((d, sourceFile, sourceUnit));
            }
          }
        }
      }
    }
  }

  final names = decls.keys.toSet();
  final out = <String, ClassInfo>{};
  for (final e in decls.entries) {
    // 普通类同样可能 with mixin：mixin 的成员不再线性化进本类（由消费者产物
    // 的 application 类 + __mixinHard 承担），这里只建模类自身结构。
    out[e.key] = classInfoOf(
      ClassLikeDecl.ofClass(e.value.$1),
      e.value.$2,
      isComponent: e.value.$3,
      dependencies: referencedClassNames(e.value.$1).intersection(names),
    );
  }
  return out;
}

/// 类是否为 widget / 组件类：带 @PatchEntry 注解，或继承
/// StatefulWidget / StatelessWidget / InheritedWidget / State
/// （State 子类通常私有，已在收集处排除，这里仅作兜底）。
///
/// 产物判定（本文件根类收集、跨文件产物解析）与翻译层共用这一个口径。
bool isWidgetClassDecl(ClassDeclaration d) {
  if (findAnnotation(d.metadata, 'PatchEntry') != null) return true;
  final sup = d.extendsClause?.superclass;
  if (sup != null) {
    switch (eraseType(sup.toSource())) {
      case 'StatefulWidget':
      case 'StatelessWidget':
      case 'InheritedWidget':
      case 'State':
        return true;
    }
  }
  return false;
}