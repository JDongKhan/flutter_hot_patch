/// 渲染层：ClassInfo → JS 类声明字符串。
///
/// 只做字符串拼装：不遍历 AST、不做表达式翻译、不收集依赖。字段初值、方法体、
/// getter、builder 子树都已由 analyze_dart_class 预渲染进 [ClassInfo]。
library;

import 'package:build/build.dart' show log;

import '../class_info.dart';
import 'js_member.dart';
import 'js_value.dart';

/// 类声明 → JS（export 可选）。含 constructor / 方法 / getter / extends 基类，
/// 并数据驱动地追加方法。
///
/// 组件与普通类共用这一条渲染路径。方法体、getter、builder 子树都已由
/// analyze_dart_class 预渲染成 JS 字符串——本函数只负责拼装，不再遍历 AST。
/// **没有对外工厂函数**：元素的 type 就是类本身（宿主 widget 则是类型名字符串），
/// 由渲染层统一写成 `new Type(props)`；元素实例自带 `__element`。
/// [baseClass]：JS 基类名（见 `jsBaseClassOf`）；null = 不继承。项目类与 SDK
/// 基类都走原生 `extends`，`super` 链由引擎维护。
String renderClassDecl(
  ClassInfo info, {
  bool exported = false,
  String? baseClass,
}) {
  final b = StringBuffer();
  b.write(exported ? 'export class ' : 'class ');
  b.write(info.name);
  final base = baseClass ?? sdkBaseName(info);
  if (base != null) b.write(' extends $base');
  b.write(' {\n');

  // static 字段 → 类体内 `static f = <init>;`（与 Dart 源码同一形态）。
  // 求值时机由引擎保证：类定义时按源码声明序初始化，晚于方法定义，故字段
  // 初始化器里可以引用同类的静态方法。
  _writeStaticFields(b, info);

  // constructor：有无 this.x 构造形参决定形态（组件与普通类同一规则）：
  // 无参 → `constructor()`（JS 侧多传实参无害）；有参 → `constructor(args)`，
  // 构造参数**统一经 `__applyProps(args)` 派生**（构造参数 → 实例字段只有这一处
  // 映射，构造函数首行调用）。
  //
  // 为什么单独成方法：运行时 patch 复用组件实例时（props 变了）**不会重跑构造
  // 函数**，只更新实例的 `this.props`；参数↔字段映射若只写在构造函数里，子组件
  // 就会永远拿着旧 props 派生的字段（表现为「切换排序/筛选后列表内容不更新」）。
  // 运行时在 patch 的复用路径上会再调一次 `__applyProps(el.props)` 同步字段
  // （见 mini_react_js 的 patch）。
  //
  // 组件类与普通类同样是「构造即实例」：字段初始化照常写在构造里。
  // 翻译层发射 `new X(props)`，元素携带该实例；reconciler mount **直接复用**
  // 这个实例（不再 `new` 第二次），patch 复用旧实例、丢弃重建产生的新实例。
  // 组件实例必须保留 props（patch 复用实例时据此同步最新值）。
  if (info.isComponent) {
    // 组件类一定有 JS 基类（StatelessWidget / StatefulWidget / Component /
    // 项目内组件基类），props 由基类 `Component` 构造统一写入。
    b.write('  constructor(args) {\n');
  } else if (base != null) {
    // 有基类 → 构造统一收 args 并原样转发：父类构造里的 `__applyProps(args)`
    // 才能把同一份构造参数映射到父类字段（Dart 隐式/显式 super(...) 的等价物）。
    // 多传实参对无参父类无害。
    b.write('  constructor(args) {\n');
  } else {
    // 默认构造有初始化列表 / 构造体时也必须收 args（形参局部绑定要从 args 取）。
    b.write(info.ctorParams.isEmpty &&
            info.typeParams.isEmpty &&
            info.ctorParamJs.isEmpty
        ? '  constructor() {\n'
        : '  constructor(args) {\n');
  }
  if (base != null) b.write('    super(args);\n');
  if (info.ctorParams.isNotEmpty) b.write('    this.__applyProps(args);\n');
  // 类泛型：构造下发的 `typeArguments` 元信息（参数名 → 类型名）存到实例，
  // 方法体里的类型参数（`T == String` / `as T`）据此读运行时类型名。
  // 有构造形参时由 `__applyProps` 统一写入（见下），这里只补无参构造的路径。
  if (info.typeParams.isNotEmpty && info.ctorParams.isEmpty) {
    b.write('    this.__ta = (args && args.typeArguments) || {};\n');
  }
  // 默认构造的形参局部绑定 → 字段默认赋值 → 初始化列表 → 构造体：
  // 与 Dart 的「字段初始化器 → 初始化列表 → 构造体」顺序一致。
  for (final p in info.ctorParamJs) {
    b.write('    $p\n');
  }
  _writeFieldAssignments(b, info);
  for (final s in info.ctorInitJs) {
    b.write('    $s\n');
  }
  if (info.ctorBodyJs.isNotEmpty) b.write('${info.ctorBodyJs}\n');
  b.write('  }\n');

  // 构造参数 → 实例字段的唯一映射：构造函数首行调用；实例被 patch 复用
  // （props 变更）时由运行时再调一次 `__applyProps`，保证字段与最新 props 同步。
  if (info.ctorParams.isNotEmpty) {
    b.write('  __applyProps(args) {\n');
    for (final f in info.instanceFields) {
      if (!info.ctorParams.contains(f.name)) continue;
      b.write(
        '    this.${f.name} = (args && args.${f.name} !== undefined) '
        '? args.${f.name} : ${_fieldDefaultJs(f)};\n',
      );
    }
    if (info.typeParams.isNotEmpty) {
      b.write('    this.__ta = (args && args.typeArguments) || {};\n');
    }
    b.write('  }\n');
  }

  // 方法 + getter：方法体（含 getter、builder）已在收集阶段预渲染为 [bodyJs]，
  // 这里只拼装。缺失说明收集层漏译，出声告警而不是静默产出空方法体。
  // 生成器 / async / 访问器的发射规则只有一处（[jsClassMember] /
  // [jsClassAccessor]），与 extension 的成员表共用，不再各写一套。
  for (final m in info.methods) {
    final gen = m.body?.isGenerator == true;
    final raw = m.bodyJs;
    if (raw == null) {
      log.warning(
        '[hot_patch_generator] ${info.name}.${m.name} 缺少预渲染方法体'
        '（收集阶段应产出 bodyJs），已渲染为空方法体。',
      );
    }
    final body = (raw ?? '').trimRight();
    if (m.isSetter) {
      // Dart setter → JS 属性写访问器；赋值调用点 `x.name = v` 本来就按
      // PropertyAccess 翻译，两端天然对齐。
      b.write('${jsClassAccessor(
        name: m.name,
        isGetter: false,
        body: body,
        setParams: m.params,
        isStatic: m.isStatic,
      )}\n');
    } else if (m.isGetter) {
      b.write('${jsClassAccessor(
        name: m.name,
        isGetter: true,
        body: body,
        isStatic: m.isStatic,
      )}\n');
    } else {
      // 方法签名按调用约定生成：位置形参在前，具名实参（与类型实参）合并成
      // 一个尾参对象 `__o`（无具名时为泛型专用的 `__ta`）。方法体里的默认值
      // 前导与具名解构已由收集阶段写进 [ClassMethod.bodyJs]。
      b.write('${jsClassMember(
        name: m.name,
        params: jsSignatureParams(m),
        body: body,
        isStatic: m.isStatic,
        isAsync: m.isAsync,
        isGenerator: gen,
      )}\n');
    }
  }

  // 响应式 builder（ListenableBuilder/Consumer 等）现在一律以**内联闭包**
  // 下发（builder 协议唯一形态），因此不再生成实例子方法。

  // 命名构造：调用点 `X.b({...})` 的落点。类上必须有同名静态方法，否则运行时
  // 是 `X.b is not a function`。形参局部化、初始化列表、构造体 / factory 体都
  // 已在收集阶段译好，这里只拼装。
  for (final c in info.ctors) {
    b.write('  // 命名构造 ${info.name}.${c.name}'
        '${c.isFactory ? '（factory）' : ''}\n');
    b.write('  static ${c.name}(args) {\n');
    final ctorBody = c.bodyJs.trimRight();
    if (ctorBody.isNotEmpty) b.write('$ctorBody\n');
    b.write('  }\n');
  }

  b.write('}');
  return b.toString();
}

/// 静态字段 → 类体内 `static f = <init>;`。
///
/// 与实例字段同一个默认值口径（[ClassField.jsInitial] 已预渲染）：无初始化器
/// 时发射 `static f;`（Dart 里也等价于 null/零值，JS 侧为 undefined）。
void _writeStaticFields(StringBuffer b, ClassInfo info) {
  for (final f in info.staticFields) {
    final v = f.jsInitial ?? (f.initializer == null ? null : literalToJs(f.initializer));
    b.write('  static ${f.name}${v == null ? '' : ' = $v'};\n');
  }
}

/// 非构造参数字段的赋值语句（组件与普通类构造函数共用）。
void _writeFieldAssignments(StringBuffer b, ClassInfo info) {
  for (final f in info.instanceFields) {
    if (info.ctorParams.contains(f.name)) continue;
    b.write('    this.${f.name} = ${_fieldDefaultJs(f)};\n');
  }
}

/// 实例字段的 JS 默认值：翻译期预渲染好的 [ClassField.jsInitial] 优先，
/// 否则由字段初始化器字面量求值，都没有则 `undefined`。
///
/// 构造函数（非构造参数字段）与 `__applyProps`（构造参数字段在实参缺省时）
/// 共用这一处默认值口径，避免两处走样。
String _fieldDefaultJs(ClassField f) =>
    f.jsInitial ??
    (f.initializer != null
        ? (literalToJs(f.initializer) ?? 'undefined')
        : 'undefined');

/// ===========================================================================
/// 把类按「基类在前」稳定排序（DFS 后序）。
///
/// `class` 声明有 TDZ：`class A extends B` 必须在 B 求值之后。Dart 不要求基类
/// 先声明，构建期做这一次排序即可，产物里的类顺序与源码顺序无关。
List<ClassInfo> orderClassesByBase(
  List<ClassInfo> classes,
  String? Function(ClassInfo cls) baseOf,
) {
  final byName = {for (final c in classes) c.name: c};
  final out = <ClassInfo>[];
  final done = <String>{};
  final visiting = <String>{};
  void visit(ClassInfo c) {
    // visiting 命中 = 循环继承（Dart 里不合法），直接返回避免无限递归。
    if (done.contains(c.name) || !visiting.add(c.name)) return;
    if (byName[baseOf(c)] case final base?) visit(base);
    visiting.remove(c.name);
    if (done.add(c.name)) out.add(c);
  }

  for (final c in classes) {
    visit(c);
  }
  return out;
}

/// 统一入口：Dart 类 → JS 源码。
///
/// 只有这一处决定「类 → JS」的渲染：普通类（模型/状态类）与组件
/// （@PatchEntry widget，widget 与 state 已在建模期合并为同一 [ClassInfo]）
/// 全部走这里，没有任何按用途分叉的模式开关——所有差异都由 [ClassInfo] 数据
/// 驱动（类名、方法体、builder 子方法、字段的 JS 初值）。
///
/// 因此新增一种「类结构能力」只需改这一处，组件与普通类同时生效。
///
/// 参数：
///   - [exported]：类声明是否 `export`。
///   - [baseClass]：JS 基类名（`jsBaseClassOf` 解析），null = 不继承。
///
/// `@HostInjected` 方法体在收集阶段已换成 `_app_host_.invoke`（见
/// [ClassMethod.hostChannel]），渲染层不感知注解——所有方法都只按 [bodyJs] 拼装。
/// ===========================================================================
String dart2js(
  ClassInfo info, {
  bool exported = false,
  String? baseClass,
}) {
  return renderClassDecl(info, exported: exported, baseClass: baseClass);
}
