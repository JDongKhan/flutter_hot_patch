// ===== 能力：拖拽（JS 侧片段）=====
//
// 拖拽的语义是「把**任意 JS 值**从一个结点搬到另一个结点」：`Draggable.data`
// 可以是模型实例、闭包、数组。跨桥只有 JSON，这些值传过去就只剩一份快照
// （身份、闭包、方法全丢）。因此本片段建一张按**身份**索引的引用表：
//   - 元素构造时 `data` → `jsui_drag_N`，宿主只看到这个 id（它的唯一用途是与
//     Flutter 原生拖动系统对齐，宿主不需要认识数据内容）；
//   - 事件（onDragEnd / onAcceptWithDetails / onDragUpdate…）回到 JS 时按 id
//     换回原引用，于是 `details.data` 与 Dart 里 `draggable.data` 是**同一个
//     对象**，`details.data.name` / 方法调用 / 身份比较全部成立。
//
// 表按值只登记一次（对象按身份、标量按相等），体积 = 不同 data 值的个数，
// 不随拖动次数增长。
//
// 本片段与它的使用者（Draggable / LongPressDraggable / DragTarget 的组件类）
// 同属基础包 `patch/flutter.js`，故这里是模块级类，不做全局出口。
const String dragJsSource = r'''
  // ── data 身份表 + 事件详情还原：全部收在 DragData 里（唯一入口）──
  export class DragData {
    static __seq = 0;
    static __ids = new Map();
    static __refs = new Map();

    static ref(value) {
      if (value == null) { return null; }
      var id = DragData.__ids.get(value);
      if (id) { return id; }
      id = 'jsui_drag_' + (++DragData.__seq);
      DragData.__ids.set(value, id);
      DragData.__refs.set(id, value);
      return id;
    }

    static of(id) {
      if (id == null) { return null; }
      return DragData.__refs.has(id) ? DragData.__refs.get(id) : id;
    }

    static list(ids) {
      var out = [];
      if (!ids) { return out; }
      for (var i = 0; i < ids.length; i++) { out.push(DragData.of(ids[i])); }
      return out;
    }

    // 宿主只发 JSON（位置 → {dx, dy}，速度 → {pxPerSecond}）。
    static offset(json) {
      json = json || {};
      return new Offset({
        dx: json.dx == null ? 0 : json.dx,
        dy: json.dy == null ? 0 : json.dy,
      });
    }

    static updateDetails(json) {
      json = json || {};
      return {
        globalPosition: DragData.offset(json.globalPosition),
        localPosition: DragData.offset(json.localPosition),
        delta: DragData.offset(json.delta),
        primaryDelta: json.primaryDelta == null ? null : json.primaryDelta,
        sourceTimeStamp: json.sourceTimeStampUs == null
          ? null
          : new Duration({ microseconds: json.sourceTimeStampUs }),
      };
    }

    // `DraggableDetails`：字段与 Flutter 一致（**没有** `data`——负载要用用户
    // 自己的闭包变量），`velocity` 是 Velocity 实例。
    static draggableDetails(json) {
      json = json || {};
      return {
        wasAccepted: json.wasAccepted === true,
        offset: DragData.offset(json.offset),
        velocity: new Velocity({
          pixelsPerSecond: DragData.offset(json.velocity && json.velocity.pxPerSecond),
        }),
      };
    }

    static targetDetails(json) {
      json = json || {};
      return { data: DragData.of(json.data), offset: DragData.offset(json.offset) };
    }
  }
''';

// Draggable / LongPressDraggable 的 props 折算（同一份语义，两个组件模板各插一份，
// build 里调 `this.__sourceProps()`）。不设基类：这两个组件类排在本模块的值类区
// 之前，继承会撞 TDZ；同一段源码由生成器分别插进两个类即可，无重复实现。
const String dragSourcePropsMethodSource = '''
  // `data` 换成 id、四个事件下发普通函数（用户回调留在本侧，宿主只回传 id / 位置；
  // 函数在宿主 props 下发边界统一换成句柄，见 runtime 的 `__hostProps`）。
  __sourceProps() {
    var self = this;
    var p = self.props || {};
    var props = self.__propsExcept(
      ['data', 'onDragStarted', 'onDragUpdate', 'onDragEnd', 'onDragCompleted']);
    props.data = DragData.ref(p.data);
    // 普通函数即可：宿主 props 下发边界会换成句柄并按结点复用（见 __hostProps），
    // 用户回调留在本侧，宿主只回传 id / 位置。
    props.onDragStarted = function () {
      var f = self.props.onDragStarted;
      if (typeof f === 'function') { f(); }
    };
    props.onDragUpdate = function (json) {
      var f = self.props.onDragUpdate;
      if (typeof f === 'function') { f(DragData.updateDetails(json)); }
    };
    props.onDragEnd = function (json) {
      var f = self.props.onDragEnd;
      if (typeof f === 'function') { f(DragData.draggableDetails(json)); }
    };
    props.onDragCompleted = function () {
      var f = self.props.onDragCompleted;
      if (typeof f === 'function') { f(); }
    };
    return props;
  }''';

// DragTarget 的 props 折算：挂在类自身（build 里调 `this.__targetProps(context)`）。
//
// `builder(context, candidateData, rejectedData)` 只能在 JS 里执行（候选/被拒
// 数据只在悬停时由宿主产生），与 LayoutBuilder 同一方案：登记成句柄，宿主
// 回调时把**id 列表**带回来，本侧换回原值后执行 builder，结果作为 `child`
// 插槽随下一次 patch 回填。
//
// `onWillAccept` / `onWillAcceptWithDetails` 需要**同步**返回 bool，跨语言只能
// 异步，故不接（宿主侧恒接受），并用一条警告把这件事说清楚。
const String dragTargetPropsMethodSource = '''
  __targetProps(context) {
    var self = this;
    var p = self.props || {};
    var builder = p.builder;
    if (typeof builder !== 'function') {
      __warn('[DragTarget] builder 不是闭包');
      return null;
    }
    if (typeof p.onWillAccept === 'function' ||
        typeof p.onWillAcceptWithDetails === 'function') {
      __warn(
        '[DragTarget] onWillAccept / onWillAcceptWithDetails 需要同步返回值，' +
        '跨语言只能异步，已忽略（目标恒接受）'
      );
    }
    var props = self.__propsExcept(
      ['builder', 'onWillAccept', 'onWillAcceptWithDetails',
       'onAccept', 'onAcceptWithDetails', 'onMove', 'onLeave']);
    // 悬停时宿主会反复回调：同一次候选集合只重建一次子树（id 列表即身份签名）。
    props.builder = function (json) {
      json = json || {};
      var sig = (json.candidate || []).join('|') + '#' + (json.rejected || []).join('|');
      if (sig === self.__dragSig) { return; }
      self.__dragSig = sig;
      // 字段名不能叫 `__child`：那是 reconciler 记录本实例挂出的子宿主结点的
      // 内部字段，props 里再塞它会成环。
      self.__dragTargetChild = builder(
        context, DragData.list(json.candidate), DragData.list(json.rejected));
      self.setState(function () {});
    };
    props.onAccept = function (id) {
      var f = self.props.onAccept;
      if (typeof f === 'function') { f(DragData.of(id)); }
    };
    props.onAcceptWithDetails = function (json) {
      var f = self.props.onAcceptWithDetails;
      if (typeof f === 'function') { f(DragData.targetDetails(json)); }
    };
    props.onMove = function (json) {
      var f = self.props.onMove;
      if (typeof f === 'function') { f(DragData.targetDetails(json)); }
    };
    props.onLeave = function (id) {
      var f = self.props.onLeave;
      if (typeof f === 'function') { f(DragData.of(id)); }
    };
    if (self.__dragTargetChild != null) { props.child = self.__dragTargetChild; }
    return props;
  }''';
