/// 收集入口：Dart AST → 完整可渲染的 [ClassInfo]。
///
/// 本文件是「先收集、后渲染」的唯一收集层：
///   - classInfoOf：结构建模（字段 / 方法 / 构造参数 / mixin 线性化）；
///   - translateClass：在结构之上完成字段初值、方法体、getter、builder 子树与
///     依赖的预翻译，产出的 ClassInfo 可直接交给 dart2js；
///   - StatefulWidget 与 State 的合并发生在本层（收集期的特殊处理）。
///
/// 翻译只发生一次：渲染层不再遍历 AST，也不接收任何翻译上下文。
library;

import 'package:analyzer/dart/ast/ast.dart';
import 'package:analyzer/dart/ast/visitor.dart';
import 'package:build/build.dart' show log;
import '../class_info.dart';
import '../../shared/ctor_signatures.dart';
import '../../shared/host_injected.dart';
import '../../shared/js_class_defs.dart';
import '../translator/js_translator.dart';
import '../translator/js_value.dart';
import '../../shared/source_index.dart';
import '../../shared/source_location.dart';
import '../translator/element2js.dart';

/// 方法形参 → JS 形参名列表（解 DefaultFormalParameter 包裹）。
///
/// **一一对应**：Dart 是什么形参，JS 就是什么形参（形参名、顺序、个数完全一致），
/// 不做任何类型剔除——`BuildContext` 也有对应物（运行时以最近宿主祖先结点为锚
/// 的代理，由 build 传参）。形参名在作用域内保持裸引用；仅事件等延迟作用域因
/// 看不见形参，才由作用域别名译成 `this.context`（见 ElementTranslateContext._eventScope）。
/// 组件与普通类共用这一处。
/// 形参类型表（名 → 源码类型字符串）：只登记**有类型注解**的形参，供运算符
/// 重载的调用点判定「操作数静态类型是否可知」。
Map<String, String> _paramTypesOf(MethodDeclaration m) {
  final out = <String, String>{};
  for (final p in m.parameters?.parameters ?? const <FormalParameter>[]) {
    final inner = p is DefaultFormalParameter ? p.parameter : p;
    final name = inner.name?.lexeme;
    final type = switch (inner) {
      SimpleFormalParameter() => inner.type?.toSource(),
      FieldFormalParameter() => inner.type?.toSource(),
      SuperFormalParameter() => inner.type?.toSource(),
      FunctionTypedFormalParameter() => inner.returnType?.toSource(),
      _ => null,
    };
    if (name != null && name.isNotEmpty && type != null && type.isNotEmpty) {
      out[name] = type;
    }
  }
  return out;
}

List<String> jsMethodParams(MethodDeclaration m) {
  final out = <String>[];
  for (final p in m.parameters?.parameters ?? const <FormalParameter>[]) {
    final inner = p is DefaultFormalParameter ? p.parameter : p;
    final name = inner.name?.lexeme;
    if (name == null || name.isEmpty) continue;
    out.add(name);
  }
  return out;
}

/// 位置形参个数（含可选位置形参）。
///
/// `@HostInjected` 方法体的实参载荷据此拆分：调用点的通用约定是「位置实参在
/// 前、具名实参合并成尾参对象」，故前 N 个实参就是位置实参。
int positionalParamCountOf(MethodDeclaration m) =>
    (m.parameters?.parameters ?? const <FormalParameter>[])
        .where((p) => !p.isNamed)
        .length;

/// 方法是否声明了具名形参（`{...}`），见 [positionalParamCountOf]。
bool hasNamedParamOf(MethodDeclaration m) =>
    (m.parameters?.parameters ?? const <FormalParameter>[])
        .any((p) => p.isNamed);

/// 方法是否 `void`：返回类型为 `void`（箭头体译为语句，不产生 `return`）。
bool isVoidReturn(MethodDeclaration m) {
  final t = m.returnType?.toSource().trim();
  return t == 'void';
}

/// 方法返回值是否为 widget：显式返回类型里出现 `Widget`（`Widget` / `Widget?` /
/// `Future<Widget>` / `XxxWidget`）即视为 widget 方法，`return Text(...)` 走
/// widget 树渲染；返回模型等数据类型的普通方法（`User makeUser()`）按普通表达
/// 式翻译，不会被误判成组件占位节点。无显式返回类型时按 widget 处理（保守）。
bool returnsWidgetOf(MethodDeclaration m) {
  final t = m.returnType?.toSource().trim() ?? '';
  if (t.isEmpty) return true;
  return t.contains('Widget');
}

// ===========================================================================
// 建模层：Dart 类 → ClassInfo（含依赖发现）
//
// 组件（@PatchEntry widget）与普通类（模型 / 状态类 / 静态单例）都是 Dart 类，
// 走**同一处**建模：字段、方法、构造参数，以及**依赖发现**（本类引用到的其它
// 类名）都在这里求出来挂在 ClassInfo.dependencies 上。builder 不再关心「依赖
// 怎么算」，只按名字递归翻译 / 决定同文件内联还是跨文件 import。
// ===========================================================================

/// 类 / mixin 的统一声明视图：建模（[classInfoOf]）只依赖这些共同字段。
///
/// `mixin M { ... }` 与 `mixin class M { ... }` 在 JS 侧都按普通类产出（mixin
/// 不能实例化，但成员集合必须存在，供 `with` 的 application 类 import/复制）；
/// 二者与 `class` 走同一套字段 / 方法建模，差异只有 [extendsType] 与构造。
class ClassLikeDecl {
  const ClassLikeDecl({
    required this.name,
    required this.members,
    required this.node,
    this.typeParameters,
    this.extendsType,
    this.isAbstract = false,
  });

  factory ClassLikeDecl.ofClass(ClassDeclaration d) => ClassLikeDecl(
        name: d.name.lexeme,
        members: d.members,
        node: d,
        typeParameters: d.typeParameters,
        extendsType: d.extendsClause?.superclass.toSource(),
        isAbstract: d.abstractKeyword != null,
      );

  factory ClassLikeDecl.ofMixin(MixinDeclaration d) => ClassLikeDecl(
        name: d.name.lexeme,
        members: d.members,
        node: d,
        typeParameters: d.typeParameters,
      );

  final String name;
  final NodeList<ClassMember> members;
  final AstNode node;
  final TypeParameterList? typeParameters;

  /// `extends` 的源码类型名；mixin 恒为 null（`on` 约束不进 JS 继承链）。
  final String? extendsType;
  final bool isAbstract;
}

/// 方法体里是否出现 `super`（mixin 方法要用原生 super，就必须在本层重新发射）。
bool _methodUsesSuper(ClassMethod m) {
  final body = m.body;
  if (body == null) return false;
  final visitor = _SuperUseVisitor();
  body.accept(visitor);
  return visitor.found;
}

class _SuperUseVisitor extends RecursiveAstVisitor<void> {
  bool found = false;

  @override
  void visitSuperExpression(SuperExpression node) {
    found = true;
  }
}

/// `with` 解析出的声明 → 结构模型（纯 `mixin` 与 `mixin class` 同一口径）。
ClassInfo _mixinStructureOf(MixinDeclRef ref, String file) {
  final node = ref.node;
  return node is ClassDeclaration
      ? classInfoOf(ClassLikeDecl.ofClass(node), file)
      : classInfoOf(ClassLikeDecl.ofMixin(node as MixinDeclaration), file);
}

/// 提取类结构 → ClassInfo（结构建模**唯一入口**）。
///
/// 类表（buildClassTable）与翻译入口（translateClass）都从这里取结构，
/// 差异只靠参数显式化，不再有第二套「构造参数 / 字段 / 方法」行走：
///
///   - 构造：收集 this.x 形参名（DefaultFormalParameter 解包），带默认值的
///     一并记入 [ClassInfo.ctorDefaults]（JS 实例属性的兜底初值）。
///   - 字段：类型经 [fieldTypeName] 推断（无类型注解时从初始化器构造名推回），
///     **未过滤、按声明序**（模型构造的位置参数映射依赖此，见
///     modelCtorFromPartsJs）；可翻译性过滤与初值预渲染是翻译期的增强。
///   - 方法：getter 保留（渲染为 get 访问器），setter 跳过；static 方法带
///     [ClassMethod.isStatic] 收（JS 侧发射为类的静态成员，裸调用落成
///     `<类名>.<name>(...)`，与 Dart 的单一名字空间一致）。
///
/// [dependencies]：本类引用到的其它类名（由 [referencedClassNames] 与类表求交）。
/// [isComponent]：该类是 widget/组件类（@PatchEntry 或 Stateful/Stateless/
/// State 子类）——类表据此把它与普通模型类区分开（组件不作为模型内联、组件
/// 类型字段不当模型构造翻译）。
///
/// [mixins]：类 `with` 子句解析出的 mixin / mixin class 声明（见
/// resolveMixinDecls）。成员**不**在本类线性化：消费者产物生成 application
/// 类链（`ClassInfo.mixinApplications`），mixin 自身按原文件独立产出
/// （见 translateMixin）。
ClassInfo classInfoOf(
  ClassLikeDecl decl,
  String sourceFile, {
  Set<String> dependencies = const {},
  bool isComponent = false,
}) {
  final instanceFields = <ClassField>[];
  final staticFields = <ClassField>[];
  final methods = <ClassMethod>[];
  final ctorParams = <String>{};
  final ctorDefaults = <String, Expression>{};

  // 构造器 this.x 形参（DefaultFormalParameter 解包）；带默认值
  //（`this.banners = kBanners`）的一并记下，供翻译期做字段兜底初值。
  for (final m in decl.members) {
    if (m is ConstructorDeclaration) {
      for (final p in m.parameters.parameters) {
        final inner = p is DefaultFormalParameter ? p.parameter : p;
        if (inner is FieldFormalParameter) {
          ctorParams.add(inner.name.lexeme);
          if (p is DefaultFormalParameter && p.defaultValue != null) {
            ctorDefaults[inner.name.lexeme] = p.defaultValue!;
          }
        }
      }
    }
  }

  // MethodDeclaration → ClassMethod 的同一口径（类自身与 mixin 成员共用）：
  // getter 保留为 get 访问器；setter 跳过；static 保留并打 isStatic 标记。
  // `@HostInjected` 只标记方法（getter 没有可调用的通道），命中后方法体在
  // 翻译期整体改为 `_app_host_.invoke`（见 hostMethodBodyJs）。
  ClassMethod? methodOf(MethodDeclaration m) {
    // 只有「static + 非私有」的标注方法才是宿主通道（与注册清单同一判定，
    // 见 HostMethodDecl.usable）；其余标注（实例方法 / 私有）按普通方法翻译。
    final ownerPrivate = decl.name.startsWith('_');
    final hostChannel = m.isGetter ||
            !m.isStatic ||
            ownerPrivate ||
            m.name.lexeme.startsWith('_')
        ? null
        : hostChannelOf(m);
    if (m.isGetter) {
      return ClassMethod(
        name: m.name.lexeme,
        params: const [],
        isGetter: true,
        isStatic: m.isStatic,
        body: m.body,
      );
    }
    if (m.isSetter) {
      // JS 侧承载位：类体里的属性写访问器 `set name(v) { … }`；赋值调用点
      // `x.name = v` 本来就按 PropertyAccess 翻译，因此两端天然对齐。
      return ClassMethod(
        name: m.name.lexeme,
        params: jsMethodParams(m),
        isSetter: true,
        isStatic: m.isStatic,
        isVoid: true,
        returnsWidget: false,
        body: m.body,
        parameters: m.parameters,
        paramTypes: _paramTypesOf(m),
      );
    }
    if (m.isOperator) {
      // Dart 运算符重载：JS 无等价语法，成员改名为 `__op$<后缀>`；调用点在
      // 「操作数静态类型可判定」时按同一张表改写（见 _operatorOwnerOf）。
      final symbol = m.name.lexeme;
      final unary = (m.parameters?.parameters ?? const <FormalParameter>[])
          .isEmpty;
      final jsName = operatorJsName(symbol, unary: unary);
      if (jsName == null) {
        log.warning('[hot_patch_generator] ${sourceAt(sourceFile, m)}: '
            '${decl.name}.operator $symbol 暂不支持（JS 侧无等价成员），已跳过。');
        return null;
      }
      return ClassMethod(
        name: jsName,
        params: jsMethodParams(m),
        isStatic: m.isStatic,
        isVoid: isVoidReturn(m),
        returnsWidget: false,
        body: m.body,
        parameters: m.parameters,
        positionalParamCount: positionalParamCountOf(m),
        hasNamedParams: hasNamedParamOf(m),
        paramTypes: _paramTypesOf(m),
        operatorSymbol: symbol,
      );
    }
    // 可调用对象的 `call` 改名为 `invoke`（手册 `call(...)` 行）。
    final isCallMethod = !m.isStatic && m.name.lexeme == 'call';
    return ClassMethod(
      name: isCallMethod ? 'invoke' : m.name.lexeme,
      params: jsMethodParams(m),
      isAsync: m.body.isAsynchronous,
      isStatic: m.isStatic,
      isVoid: isVoidReturn(m),
      returnsWidget: returnsWidgetOf(m),
      body: m.body,
      parameters: m.parameters,
      hostChannel: hostChannel,
      paramTypes: _paramTypesOf(m),
      // 位置形参个数 / 是否含具名形参：宿主注入方法体据此拆分载荷；方法
      // tear-off 也用它生成精确形参（见 ElementTranslateContext.methodArity）。
      positionalParamCount: positionalParamCountOf(m),
      hasNamedParams: hasNamedParamOf(m),
      typeParams: [
        for (final t in m.typeParameters?.typeParameters ?? const <TypeParameter>[])
          t.name.lexeme,
      ],
    );
  }

  for (final m in decl.members) {
    if (m is FieldDeclaration) {
      for (final v in m.fields.variables) {
        final f = ClassField(
          name: v.name.lexeme,
          typeName: fieldTypeName(m, v),
          initializer: v.initializer,
          isStatic: m.isStatic,
          node: v,
        );
        if (m.isStatic) {
          staticFields.add(f);
        } else {
          instanceFields.add(f);
        }
      }
    } else if (m is MethodDeclaration) {
      final cm = methodOf(m);
      if (cm != null) methods.add(cm);
    }
  }

  String? superType = decl.extendsType;

  return ClassInfo(
    name: decl.name,
    sourceFile: sourceFile,
    superType: superType,
    instanceFields: instanceFields,
    staticFields: staticFields,
    methods: methods,
    ctorParams: ctorParams,
    ctorDefaults: ctorDefaults,
    isComponent: isComponent,
    // 可调用对象：声明了非 static 的实例方法 `call`。
    isCallable: decl.members
        .whereType<MethodDeclaration>()
        .any((m) => !m.isStatic && m.name.lexeme == 'call'),
    typeParams: [
      for (final t in decl.typeParameters?.typeParameters ?? const <TypeParameter>[])
        t.name.lexeme,
    ],
    dependencies: dependencies,
  );
}

/// 字段类型：优先显式类型注解；无注解时从初始化器推断
/// （`final _model = MyModel();` 在无 resolution 解析下 type 为 null，
/// 会退化成 dynamic 被当基础类型，需从构造名推回 MyModel）。
String fieldTypeName(FieldDeclaration member, VariableDeclaration variable) {
  final t = member.fields.type?.toSource();
  if (t != null && t.isNotEmpty) return t;
  final init = variable.initializer;
  if (init is InstanceCreationExpression) {
    return init.constructorName.type.name2.lexeme;
  }
  if (init is MethodInvocation &&
      init.target == null &&
      init.typeArguments == null) {
    final n = init.methodName.name;
    if (n.isNotEmpty && n[0] == n[0].toUpperCase()) return n;
  }
  return 'dynamic';
}

/// 一个类引用到的其它类名：**实例字段类型** + **方法体内构造调用** 的并集。
///
/// 依赖发现是「类 → ClassInfo」这一层的产物：组件与普通类共用同一处，builder
/// 只按名字递归翻译依赖组件、并按 ClassInfo.sourceFile 决定同文件内联还是跨
/// 文件 import。基础类型与 widget 构造名由调用方与类表求交后自然丢弃
/// （类表里只有真正的 Dart 类）。
///
/// mixin 声明的依赖单独按声明节点扫描（见 `resolveMixinDeclRefs` + `dependenciesOf`），
/// 不再并入本类：mixin 成员会产出在它自己的原文件产物里。
Set<String> referencedClassNames(AstNode decl) {
  return dependenciesOf(decl);
}

/// 任意声明节点里**值位置**引用的符号（构造 / 静态调用 / 顶层值前缀）。
///
/// 用于三方包 import 登记：只收产物里确实以值出现的名字，类型注解（JS 侧
/// 被擦除）不算，避免给模块 import 一堆未导出的符号。
Set<String> referencedValueNames(AstNode decl) {
  final collector = _TypeRefCollector();
  decl.accept(collector);
  return collector.valueNames;
}

/// 任意声明节点里出现的**全部类型引用**——依赖发现的唯一收集入口。
///
/// 以声明为节点整棵子树扫一遍，凡可能让产物产生「对另一个类的运行时引用」的
/// 位置都收：构造调用（`new X()` / `X()`）、静态成员（`X.fromJson()` /
/// `X.count`）、类型测试（`x is X`）、类型注解（字段 / 形参 / 返回 / 变量 /
/// 泛型实参）。整树扫描天然覆盖手写分支容易漏的宿主：构造函数体、初始化列表、
/// 形参默认值、字段初始化器。
///
/// 刻意**宁宽勿漏**：收上来的名字由调用方与类表求交，非项目类（widget、SDK、
/// 基础类型）自然丢弃。多收一个项目类只是多翻译一个产物；漏收会让产物里的
/// `import { X }` 指向不存在的模块（编译器依赖图宁可保守）。
Set<String> dependenciesOf(AstNode node) {
  final collector = _TypeRefCollector();
  node.accept(collector);
  return collector.names;
}

/// 类型引用收集器，见 [dependenciesOf]。
class _TypeRefCollector extends RecursiveAstVisitor<void> {
  final names = <String>{};

  /// 产物里**值位置**真实引用的符号（构造 / 静态调用 / 顶层值前缀）。
  ///
  /// 与 [names] 的区别：类型注解只进 [names]（JS 侧多被擦除），只有这里收的
  /// 名字才一定以值的形式出现在产物里，可安全用于三方包 import 登记。
  final valueNames = <String>{};

  /// `@HostInjected` 方法：Dart 实现留在宿主，JS 侧方法体只有
  /// `_app_host_.invoke(...)`，因此方法体里引用到的类型**不会**出现在产物里
  /// （不参与依赖传播 / import 生成）。
  @override
  void visitMethodDeclaration(MethodDeclaration node) {
    if (hostChannelOf(node) != null) return;
    super.visitMethodDeclaration(node);
  }

  @override
  void visitInstanceCreationExpression(InstanceCreationExpression node) {
    final type = node.constructorName.type;
    final name = type.name2.lexeme;
    names.add(name);
    // 带 import 前缀的构造（`p.X(...)`）在产物里保留 `p.X`，前缀 import 已经
    // 覆盖该符号，不需要也不应该再补一条具名 import。
    if (type.importPrefix == null) valueNames.add(name);
    super.visitInstanceCreationExpression(node);
  }

  /// 无 `new`/`const` 的构造（`MyModel()`）、静态调用（`MyModel.fromJson()`）、
  /// 静态字段访问（`MyColors.primary`）：无 resolution 时统一按「首字母大写的
  /// 标识符就是类名」的形态收前缀（与 [fieldTypeName] 同一启发式）。
  @override
  void visitMethodInvocation(MethodInvocation node) {
    final target = node.target;
    if (target == null && node.typeArguments == null) {
      _addClassLikeName(node.methodName.name);
      _addValueName(node.methodName.name);
    } else if (target is SimpleIdentifier) {
      _addClassLikeName(target.name);
      _addValueName(target.name);
    }
    super.visitMethodInvocation(node);
  }

  @override
  void visitPrefixedIdentifier(PrefixedIdentifier node) {
    _addClassLikeName(node.prefix.name);
    _addValueName(node.prefix.name);
    super.visitPrefixedIdentifier(node);
  }

  @override
  void visitPropertyAccess(PropertyAccess node) {
    final target = node.target;
    if (target is SimpleIdentifier) {
      _addClassLikeName(target.name);
      _addValueName(target.name);
    }
    super.visitPropertyAccess(node);
  }

  /// `x is T` → JS `x instanceof T`：T 的类定义必须存在。
  @override
  void visitIsExpression(IsExpression node) {
    names.add(eraseType(node.type.toSource()));
    super.visitIsExpression(node);
  }

  /// 类型注解：JS 侧多被擦除，但字段初值、`is`、模型构造都按类型名落地——
  /// 保守收，与类表求交。泛型实参一并收（`List<Spot>` → List + Spot）。
  @override
  void visitNamedType(NamedType node) {
    names.add(eraseType(node.toSource()));
    super.visitNamedType(node);
  }

  void _addClassLikeName(String n) {
    if (n.isNotEmpty && n[0] == n[0].toUpperCase()) names.add(n);
  }

  void _addValueName(String n) {
    if (n.isNotEmpty && n[0] == n[0].toUpperCase()) valueNames.add(n);
  }
}

// ===========================================================================
// 统一入口：Dart 类 → ClassInfo（方法体已预渲染为 JS）
//
// 翻译只有这一个入口 [translateClass]，内部唯一的分叉是：
//   - 类是 StatefulWidget（声明了 createState）→ 与同文件 State 类合并
//     （widget 构造参数 + State 字段/方法）；
//   - 其余类（普通模型 / ChangeNotifier / StatelessWidget / …）直接翻译自身。
//
// 分叉之后不再有任何「组件 / 普通类」两套逻辑：字段收集、方法体翻译、
// 依赖发现、widget 树渲染全部同一条路径。类引用到的其它类（普通类或自定义
// 组件）统一挂在 ClassInfo.dependencies 上，builder 只按名字递归翻译 /
// 决定同文件内联还是跨文件 import——「给一个入口，按依赖关系递归翻译」。
// ===========================================================================

// JS 运行时同名代理类（ScrollController / PageController / TextEditingController
// / TabController）的集合与构造翻译统一维护在 js_translator 的
// [jsRuntimeClassNames] / [jsRuntimeCtorJs]，字段初始化与内联构造共用一条路径。

/// 任意 Dart 类声明 → 已翻译的 [ClassInfo]（方法体 [ClassMethod.bodyJs]
/// 在本次调用中全部预渲染好，依赖 / 用到的 widget 类型也已收集齐）。
///
/// 参数：
///   - [decl]：待翻译类（@PatchEntry widget 类或普通类）。
///   - [unit]：所在编译单元（StatefulWidget 合并时在此查找同文件 State 类）。
///   - [classTable]：全量类表（含组件 / 普通类），字段类型与方法体
///     构造调用按名字解析；组件条目标记 [ClassInfo.isComponent]。
///   - [importResolver]：自定义组件名 → 依赖产物相对路径（null = 无 JS 产物，
///     运行时原生注入）。
///   - [isComponent]：是否作为组件产物输出（仅影响注释与 superType 处理：
///     State 合并时不把 `State<X>` / `StatefulWidget` 写成 JS 基类）。
///
/// 顶层 `@HostInjected` 函数名由本入口自行扫描（见 [buildHostFunctions]），
/// 用于顶层函数调用点的通道改写；类上的宿主方法在声明处标记（方法体改为
/// `_app_host_.invoke`），调用点与 Dart 一比一。组件与普通类同一条路径，
/// 调用方无需传参。
ClassInfo translateClass(
  ClassDeclaration decl,
  CompilationUnit unit,
  String sourcePath, {
  required Map<String, ClassInfo> classTable,
  required String? Function(String name) importResolver,
  Set<String> jsClassWidgets = const {},
  Set<String> delegateClassWidgets = const {},
  Set<String> ignoredTypes = const {},
  Set<String> globalConsts = const {},
  bool isComponent = false,
  Map<String, String> prefixProducts = const {},
  Map<String, Map<String, String>> extensionOperators = const {},
  Map<String, ExtensionScope> extensionNames = const {},
}) {
  // 顶层 `@HostInjected` 函数名：翻译层自己扫（本文件 + import 源文件）。
  // 类上的宿主方法不再走调用点改写（方法体在 JS 类里桥回宿主，见
  // [ClassMethod.hostChannel]），只有顶层函数需要这张表。
  final hostFunctions = buildHostFunctions(unit, sourcePath);

  // --- 唯一分叉：StatefulWidget → widget 类与同文件 State 类合并 ------------
  ClassDeclaration widgetClass = decl;
  ClassDeclaration hostClass = decl;
  final stateClassName = stateClassNameOf(decl);
  if (stateClassName != null) {
    for (final d in unit.declarations) {
      if (d is ClassDeclaration && d.name.lexeme == stateClassName) {
        hostClass = d;
        break;
      }
    }
    if (identical(hostClass, decl)) {
      throw FormatException('找不到 State 类 $stateClassName（需与 widget 同文件）');
    }
  }

  /// 本类（widget / State）的类型参数名：字段类型写成 `K` / `V` 这类类型变量时，
  /// JS 侧泛型擦除，字段仍可持有任意值（见 [_fieldTranslatable]）。
  final classTypeParams = <String>{
    for (final t
        in widgetClass.typeParameters?.typeParameters ?? const <TypeParameter>[])
      t.name.lexeme,
    for (final t
        in hostClass.typeParameters?.typeParameters ?? const <TypeParameter>[])
      t.name.lexeme,
  };

  // 结构建模唯一入口 classInfoOf：构造参数（含形参默认值）、实例字段
  //（fieldTypeName 推断、声明序）、方法（getter 保留、setter 跳过、
  // static 带 isStatic 收）都来自它，本函数只做翻译增强（可翻译性
  // 过滤 / 初值预渲染 / 方法体翻译 / native 通道识别）。
  // StatefulWidget 场景：widget 类出构造参数与参数字段，State 类出方法与
  // 状态字段。build 与其它返回 widget 的方法一视同仁，不做「是不是 build」的判断。
  //
  // mixin：解析 hostClass（State 类 / 普通类自身）的 with 子句。成员不再线性化
  // 进本类；每层 mixin 在消费者产物里生成 application 类，mixin 自身按原文件
  // 产物独立产出（见 class_info.dart 的 MixinApplication / 手册第 10 章）。
  final mixinRefs = resolveMixinDeclRefs(hostClass, unit, sourcePath);
  final mixinInfos = <(MixinDeclRef, String, ClassInfo)>[
    for (final (ref, file) in mixinRefs) (ref, file, _mixinStructureOf(ref, file)),
  ];
  final widgetInfo = classInfoOf(
    ClassLikeDecl.ofClass(widgetClass),
    sourcePath,
  );
  final hostInfo = identical(hostClass, widgetClass)
      ? widgetInfo
      : classInfoOf(ClassLikeDecl.ofClass(hostClass), sourcePath);
  final ctorArgs = widgetInfo.ctorParams;
  final ctorDefaults = widgetInfo.ctorDefaults;
  final methods = hostInfo.methods;

  // `@HostInjected` 类（有被标注的 static 方法）：整个类的实现都在宿主侧，
  // JS 侧只保留**类 + 被标注的方法**（方法体为 `_app_host_.invoke`）。字段、
  // 其它方法、基类、依赖与 import 一概不产出——它们只服务于宿主实现，放进来
  // 只会产生指向宿主才有的符号的悬空引用。调用点仍是普通静态调用
  // （`AppRouter.pop()`），与 Dart 一比一。
  final hostClassMethods = [
    for (final m in methods)
      if (m.hostChannel != null) m,
  ];
  if (hostClassMethods.isNotEmpty) {
    return ClassInfo(
      name: decl.name.lexeme,
      sourceFile: sourcePath,
      instanceFields: const [],
      staticFields: const [],
      methods: [
        for (final m in hostClassMethods)
          ClassMethod(
            name: m.name,
            params: m.params,
            isAsync: m.isAsync,
            isStatic: m.isStatic,
            isVoid: m.isVoid,
            returnsWidget: m.returnsWidget,
            body: m.body,
            bodyJs: hostMethodBodyJs(m),
            parameters: m.parameters,
            hostChannel: m.hostChannel,
            positionalParamCount: m.positionalParamCount,
            hasNamedParams: m.hasNamedParams,
          ),
      ],
      isComponent: isComponent,
      isAbstract: hostClass.abstractKeyword != null,
    );
  }

  // 依赖发现：字段类型 + 方法体构造调用（referencedClassNames）∩ 全量类表。
  // 类表同时包含组件与普通类——普通类方法体里构造自定义组件（如
  // CounterVm.buildText() → BannerCard()）与组件 build 里构造模型走同一套。
  // 内建 widget（宿主渲染 / JS 类）由统一翻译路径接管，不能再当模型类。
  final used = <String, ClassInfo>{};
  for (final name in referencedClassNames(hostClass)) {
    final info = classTable[name];
    if (info == null) continue;
    used[name] = info;
  }
  // mixin 成员（application 层里的字段 / 带 super 的方法）同样可能引用模型类；
  // 依赖按 **mixin 声明节点** 扫描，不并入 host 自身的依赖语义。
  for (final (ref, _, _) in mixinInfos) {
    for (final name in referencedClassNames(ref.node)) {
      final info = classTable[name];
      if (info == null) continue;
      used[name] = info;
    }
  }

  // 字段收集：基础类型 / JS 运行时类型 / 普通类类型字段进 JS 实例属性；
  // 组件类型与无 JS 等价物的对象类型字段跳过并告警（与组件/普通类无关，
  // 同一套规则）。
  final propByField = <String, String>{};
  final instanceFields = <ClassField>[];
  // 字段来源：StatefulWidget 场景下 **widget 类**的字段（构造参数，如
  // `OrdersPage.initialStatus`）与 State 类字段合并——运行时 `new Type(props)`
  // 把 widget 属性作为 args 传入，二者在 JS 侧就是同一个类的实例属性；State 内
  // 的 `widget.x` 因此能解析成 `this.x`（见 js_translator 的 widget 分支）。
  // classInfoOf 产出未过滤、声明序的实例字段，这里只合并去重（widget 字段
  // 优先）；可翻译性过滤与初值预渲染在下循环。
  final fieldDecls = <ClassField>[];
  final seenField = <String>{};
  for (final info in [if (stateClassName != null) widgetInfo, hostInfo]) {
    for (final f in info.instanceFields) {
      if (seenField.add(f.name)) fieldDecls.add(f);
    }
  }
  // 字段名全集：字段初始化器可能引用其它字段（`widget.x` → `this.x`），
  // 解析初值的作用域需先知道全部字段名（propByField 在下循环里才逐步填充）。
  final fieldNames = {for (final f in fieldDecls) f.name};
  for (final field in fieldDecls) {
    {
      final fieldName = field.name;
      final typeName = field.typeName;
      final erased = eraseType(typeName);
      final isBasic = isBasicType(typeName) || _valueSdkTypes.contains(erased);
      if (!_fieldTranslatable(typeName, classTable,
          typeParams: classTypeParams,
          sourcePath: sourcePath,
          node: field.node)) {
        // 对象类型字段（Controller/Widget/Key 等）没有 JS 等价物，自动跳过。
        log.warning(
          '[hot_patch_generator] ${sourceAt(sourcePath, field.node)}: '
          '跳过字段 $fieldName（类型 $typeName 不可翻译）',
        );
        continue;
      }
      final init = field.initializer;
      // 初值来源：字段初始化器，否则构造形参默认值（`this.x = <默认值>`）。
      // 两者都走同一条通用表达式翻译（顶层常量 / 集合字面量 / 模型构造都支持）。
      final defaultExpr = ctorDefaults[fieldName];
      final initScope = FieldScope(
        sourcePath: sourcePath,
        instanceFields: fieldNames,
        globalConsts: globalConsts,
      );
      final String initial;
      if (isBasic) {
        // 初始化器优先（如 `late String _status = widget.x ?? kOrderStatus.first`
        // → `(this.initialStatus ?? kOrderStatus[0])`）；不是编译期常量时再依次
        // 回退到构造形参默认值、类型默认值（String→''、bool→false、数字→0）。
        initial = literalToJs(init) ??
            (init == null ? null : rhsToJs(init, initScope, used)) ??
            (defaultExpr == null
                ? null
                : rhsToJs(defaultExpr, initScope, used)) ??
            _defaultInitial(typeName);
      } else {
        // 统一规则：任何类构造 → `new X({...})`（位置实参按源码签名映射）。
        // 无初始化器时回退类型默认值（容器→[]/{}），JS 侧漏传 props 仍能安全遍历。
        final ctorJs = init == null
            ? (defaultExpr == null
                ? null
                : rhsToJs(defaultExpr, initScope, used))
            : (valueCtorJs(init, initScope, used) ??
                (init is InstanceCreationExpression
                    ? modelCtorToJs(init, initScope, used)
                    : null));
        initial = ctorJs ??
            (init == null
                ? _defaultInitial(typeName)
                : (rhsToJs(init, initScope, used) ?? 'null'));
      }
      instanceFields.add(ClassField(
        name: fieldName,
        typeName: typeName,
        jsInitial: initial,
      ));
      propByField[fieldName] = fieldName;
    }
  }

  // static 字段：JS 侧是类体内 `static f = <init>`，初值与实例字段共用同一条
  // 求值链（字面量 / 值对象构造 / 通用表达式）。求值作用域只有 static 成员——
  // Dart 的 static 初始化器看不到实例成员。
  final staticDecls = <ClassField>[];
  final seenStatic = <String>{};
  for (final info in [if (stateClassName != null) widgetInfo, hostInfo]) {
    for (final f in info.staticFields) {
      if (seenStatic.add(f.name)) staticDecls.add(f);
    }
  }
  final staticNames = {for (final f in staticDecls) f.name};
  final staticMethods = {
    for (final m in methods)
      if (m.isStatic) m.name,
  };
  final staticScope = FieldScope(
    sourcePath: sourcePath,
    className: decl.name.lexeme,
    staticFields: staticNames,
    staticMethods: staticMethods,
    globalConsts: globalConsts,
  );

  // 类表里的普通类（模型）名：值位置上的构造只排除这些类与值对象，其余类
  // 构造一律按组件元素翻译——不再维护「哪些类型是 widget」的白名单。
  final modelClassNames = <String>{
    for (final e in classTable.entries)
      if (!e.value.isComponent) e.key,
  };

  // mixin 成员在运行时属于同一个实例（application 类链 / __mixinHard），
  // 因此**可见成员表**要并入 host 的解析上下文：host 方法里裸调用
  // `logState(...)`、读取 mixin 字段 `_hits` 都要落成 `this.xxx`。
  // 注意只并入“可见表”，不并入最终类的成员（成员仍在 mixin 产物/application 类）。
  final mixinInstanceMethods = <ClassMethod>[
    for (final (_, _, info) in mixinInfos)
      ...info.methods.where((m) => !m.isStatic),
  ];
  final mixinInstanceFields = <ClassField>[
    for (final (_, _, info) in mixinInfos)
      ...info.instanceFields.where((f) => !f.isStatic),
  ];
  for (final f in mixinInstanceFields) {
    propByField.putIfAbsent(f.name, () => f.name);
  }
  final visibleMethods = [...methods, ...mixinInstanceMethods];

  // 翻译上下文：实例字段表（propByField）+ 实例方法名表（actionByMethod）
  // ——widget 层据此解析标识符（`_count` → `this._count`）、区分本类实例
  // 方法与嵌套组件构造。普通类与组件同一个上下文。
  final parseCtx = ElementTranslateContext(
    propByField: propByField,
    actionByMethod: {
      for (final m in visibleMethods)
        if (!m.isGetter && !m.isStatic) m.name: m.name,
    },
    // 本类全部方法名（含非动作方法）；static 方法单列一张表，裸调用落成
    // `<类名>.m(...)`（Dart 的 static 与实例成员同一名字空间）。
    methodNames: {
      for (final m in visibleMethods)
        if (!m.isStatic) m.name,
    },
    // 方法位置形参个数（tear-off 生成精确形参用）。含具名形参时为 null——
    // 具名实参走尾参对象约定，只能 `...__a` 原样转发（保留缺省值语义）。
    methodArity: {
      for (final m in visibleMethods)
        m.name: (m.isGetter || m.hasNamedParams) ? null : m.positionalParamCount,
    },
    // getter 名（`_visiblePosts`）：JS 类里是 `get` 访问器，作为函数值传参时
    // 必须按值读，不能包装成调用（见 [ElementTranslateContext.getterNames]）。
    getterNames: {
      for (final m in visibleMethods)
        if (m.isGetter) m.name,
    },
    sourcePath: sourcePath,
    importResolver: importResolver,
    className: decl.name.lexeme,
    staticFieldNames: staticNames,
    staticMethodNames: staticMethods,
    globalConsts: globalConsts,
    hostFunctions: hostFunctions,
    jsClassWidgets: jsClassWidgets,
    delegateClassWidgets: delegateClassWidgets,
    ignoredTypes: ignoredTypes,
    modelClassNames: modelClassNames,
    prefixProducts: prefixProducts,
  );

  // static 字段初值：与实例字段走同一条通用表达式翻译（`new X({...})`）。
  // 值对象（`LinearGradient` / `BoxDecoration` / `Color` …）在 JS 侧有同名类
  // （运行时注入 + `toJSON`），因此这里不做「转成 JSON」的类型特判——
  // 与「所有 Dart 类都翻译成 JS 类」同一条原则。
  final staticFields = <ClassField>[];
  for (final field in staticDecls) {
    final typeName = field.typeName;
    if (!_fieldTranslatable(typeName, classTable,
        typeParams: classTypeParams,
        sourcePath: sourcePath,
        node: field.node)) {
      log.warning(
        '[hot_patch_generator] ${sourceAt(sourcePath, field.node)}: '
        '跳过静态字段 ${field.name}（类型 $typeName 不可翻译）',
      );
      continue;
    }
    final init = field.initializer;
    final initial = literalToJs(init) ??
        (init == null ? null : rhsToJs(init, staticScope, used)) ??
        (isBasicType(typeName) || _valueSdkTypes.contains(eraseType(typeName))
            ? _defaultInitial(typeName)
            : 'null');
    staticFields.add(ClassField(
      name: field.name,
      typeName: typeName,
      jsInitial: initial,
    ));
  }

  // 方法增强：classInfoOf 已建好结构（形参 / async / void / 返回 widget
  // 判定），这里只叠加翻译产物——预渲染方法体 [bodyJs] 与 native 通道识别
  //（方法体是 SnackBar 形式时整体改译 nativeToast）。getter 也在这里译好，
  // 渲染层不再需要回读 AST。
  ClassMethod buildMethod(ClassMethod cm, {String? bodyJs}) {
    if (cm.isGetter) {
      // getter 也要带上收集期译好的方法体（渲染层不再回读 AST）。
      return ClassMethod(
        name: cm.name,
        params: cm.params,
        isGetter: true,
        isStatic: cm.isStatic,
        body: cm.body,
        bodyJs: bodyJs,
        paramTypes: cm.paramTypes,
      );
    }
    final body = cm.body;
    final msg = body == null ? null : _snackMessage(body, parseCtx);
    return ClassMethod(
      name: cm.name,
      params: cm.params,
      isAsync: cm.isAsync,
      isStatic: cm.isStatic,
      isVoid: cm.isVoid,
      returnsWidget: cm.returnsWidget,
      body: cm.body,
      bodyJs: bodyJs,
      parameters: cm.parameters,
      isSetter: cm.isSetter,
      operatorSymbol: cm.operatorSymbol,
      paramTypes: cm.paramTypes,
      nativeChannel: msg != null ? 'nativeToast' : null,
      nativeMessage: msg,
      hostChannel: cm.hostChannel,
      positionalParamCount: cm.positionalParamCount,
      hasNamedParams: cm.hasNamedParams,
      typeParams: cm.typeParams,
    );
  }

  final proto = ClassInfo(
    name: decl.name.lexeme,
    sourceFile: sourcePath,
    // 组件（State 合并）不把 StatefulWidget/State 写成字段继承基类；但 JS 产物
    // 仍按 widget 自身的 extends 发射（`extends StatefulWidget / StatelessWidget`）。
    superType: isComponent ? null : decl.extendsClause?.superclass.toSource(),
    widgetSuperType:
        isComponent ? decl.extendsClause?.superclass.toSource() : null,
    instanceFields: [...instanceFields, ...mixinInstanceFields],
    staticFields: staticFields,
    methods: [
      for (final m in [...methods, ...mixinInstanceMethods]) buildMethod(m),
    ],
    ctorParams: {
      for (final f in instanceFields)
        if (ctorArgs.contains(f.name)) f.name,
    },
    isComponent: isComponent,
    // 方法体在 translateClassMethodBody 里按 proto 翻译，抽象标记必须在 proto
    // 上就位，抽象成员的「抛错兜底」才会生效。
    isAbstract: hostClass.abstractKeyword != null ||
        widgetClass.abstractKeyword != null,
    typeParams: [
      for (final t in decl.typeParameters?.typeParameters ?? const <TypeParameter>[])
        t.name.lexeme,
    ],
  );

  // 逐个方法翻译：唯一的方法体翻译器，组件与普通类、build 与其它方法完全
  // 同一条路径。parseCtx 在过程中收集依赖组件 / 用到的 widget 类型 /
  // 响应式 builder 子方法。
  //
  // 整类方法体都在**表达式渲染器**发布期间翻译：任意表达式位置的构造走属性
  // 管线（属性归一 + import 登记），静态类引用（`Overlay.of(context)`）按类
  // 定义所在文件解析。所有类同一路径——不区分「是不是组件」，也不区分
  // 「是不是返回 widget 的方法」。
  final translated = parseCtx.withExprRenderer(() => <ClassMethod>[
    for (final m in methods)
      buildMethod(
        m,
        bodyJs: translateClassMethodBody(proto, buildMethod(m), used,
            hostFunctions: hostFunctions,
            renderer: parseCtx,
            globalConsts: globalConsts,
            extensionOperators: extensionOperators,
            extensionNames: extensionNames),
      ),
  ]);

  // 命名构造（`X.b` / `factory X.b`）：调用点翻译成 `X.b({...})`，类上必须有
  // 同名静态方法承接。无名构造由 `constructor(args)` 承担，不在这一步。
  final ctors = parseCtx.withExprRenderer(() => _translateNamedCtors(
        decl,
        proto,
        used,
        hostFunctions: hostFunctions,
        globalConsts: globalConsts,
        renderer: parseCtx,
      ));

  // 无名构造（默认构造）：初始化列表 / 构造体落在 `constructor(args)` 里。
  // StatefulWidget 的 State 类构造在合并产物里没有独立落点（实例由 widget
  // 构造创建），有内容时告警而不是静默丢弃。
  final unnamed = parseCtx.withExprRenderer(() => _translateUnnamedCtor(
        decl,
        proto,
        used,
        instanceFields,
        hostFunctions: hostFunctions,
        globalConsts: globalConsts,
        renderer: parseCtx,
      ));
  if (!identical(hostClass, widgetClass)) {
    for (final m in hostClass.members.whereType<ConstructorDeclaration>()) {
      if ((m.name?.lexeme ?? '').isEmpty &&
          (m.initializers.isNotEmpty || m.body is! EmptyFunctionBody)) {
        log.warning('[hot_patch_generator] ${hostClass.name.lexeme} 的默认构造'
            '体在 State 合并产物中没有独立落点，已跳过。');
      }
    }
  }

  // --- mixin application 类链（dart2js 结构） -------------------------------
  // `with M1, M2` → 消费者产物里生成 `_C_Base_M1 extends Base`、
  // `_C_Base_M1_M2 extends _C_Base_M1`，最终 C 继承最后一层。mixin 自身仍是
  // 原文件产物里的独立类：不带 super 的成员留在 mixin 类里，由 `__mixinHard`
  // 复制；带 super 的方法在本层重新发射，原生 `super` 指向上一层。
  final mixinApps = <MixinApplication>[];
  if (mixinInfos.isNotEmpty) {
    final hostFieldNames = {for (final f in instanceFields) f.name};
    final hostBase = jsBaseClassOf(proto, classTable);
    final firstNamePrefix = hostBase == null
        ? '_${proto.name}'
        : '_${proto.name}_${hostBase.split('<').first.trim()}';
    // 合成类也要能被 jsBaseClassOf 解析（原生 super 的 hasJsBase 判据）。
    final layerClasses = <String, ClassInfo>{...classTable};
    if (hostBase != null) {
      layerClasses.putIfAbsent(
        hostBase,
        () => ClassInfo(
          name: hostBase,
          sourceFile: sourcePath,
          instanceFields: const [],
          staticFields: const [],
          methods: const [],
        ),
      );
    }
    var prevName = hostBase;
    for (final (ref, file, info) in mixinInfos) {
      final layerName = mixinApps.isEmpty
          ? '${firstNamePrefix}_${ref.name}'
          : '${mixinApps.last.layer.name}_${ref.name}';
      final layerBase = prevName;

      // mixin 实例字段：由这一层 application 构造函数在 `super(args)` 之后
      // 初始化，顺序天然是 Base → M1 → M2 → 最终类。
      final layerFieldNames = {
        ...hostFieldNames,
        for (final f in info.instanceFields)
          if (!f.isStatic) f.name,
      };
      final layerInitScope = FieldScope(
        sourcePath: sourcePath,
        instanceFields: layerFieldNames,
        globalConsts: globalConsts,
      );
      final layerFields = <ClassField>[];
      // 本层可见的类型参数 = 消费者类自身的 + 该 mixin 声明的（字段写成 `T`
      // 时同样是类型变量，JS 侧擦除）。
      final layerTypeParams = <String>{
        ...classTypeParams,
        if (ref.node case final MixinDeclaration mixin)
          for (final t in mixin.typeParameters?.typeParameters ??
              const <TypeParameter>[])
            t.name.lexeme,
      };
      for (final f in info.instanceFields) {
        if (f.isStatic) continue;
        if (!_fieldTranslatable(f.typeName, classTable,
            typeParams: layerTypeParams,
            sourcePath: sourcePath,
            node: f.node)) {
          log.warning(
            '[hot_patch_generator] ${sourceAt(sourcePath, f.node)}: '
            '跳过 mixin 字段 ${ref.name}.${f.name}'
            '（类型 ${f.typeName} 不可翻译）',
          );
          continue;
        }
        final init = f.initializer;
        final initial = literalToJs(init) ??
            (init == null ? null : rhsToJs(init, layerInitScope, used)) ??
            _defaultInitial(f.typeName);
        layerFields.add(ClassField(
          name: f.name,
          typeName: f.typeName,
          jsInitial: initial,
        ));
      }

      // 带 super 的方法：从 mixin 声明重新翻译到本层（原生 super 指向上一层）。
      final structural = <ClassMethod>[
        for (final m in info.methods)
          if (!m.isStatic && _methodUsesSuper(m)) m,
      ];
      final layerProto = ClassInfo(
        name: layerName,
        sourceFile: sourcePath,
        superType: layerBase,
        instanceFields: layerFields,
        staticFields: const [],
        // 作用域里要看到 mixin 的全部成员（方法体可能调用同类其它方法）；
        // 本层实际**发射**的只有带 super 的 structural。
        methods: info.methods,
        typeParams: info.typeParams,
      );
      layerClasses[layerName] = layerProto;
      final layerMethods = parseCtx.withExprRenderer(() => <ClassMethod>[
        for (final m in structural)
          buildMethod(
            m,
            bodyJs: translateClassMethodBody(
              layerProto,
              m,
              layerClasses,
              hostFunctions: hostFunctions,
              renderer: parseCtx,
              globalConsts: globalConsts,
              extensionOperators: extensionOperators,
              extensionNames: extensionNames,
            ),
          ),
      ]);
      final layer = ClassInfo(
        name: layerName,
        sourceFile: sourcePath,
        superType: layerBase,
        instanceFields: layerFields,
        staticFields: const [],
        methods: layerMethods,
        isAbstract: false,
        typeParams: info.typeParams,
        dependencies: {
          ...referencedClassNames(ref.node).intersection(classTable.keys.toSet()),
          ...parseCtx.dependencies,
        },
        usedWidgetPackages: parseCtx.usedWidgetPackages,
        namespaceImports: parseCtx.namespaceImports,
      );
      layerClasses[layerName] = layer;
      mixinApps.add(MixinApplication(
        mixinName: ref.name,
        sourceFile: file,
        layer: layer,
      ));
      prevName = layerName;
    }
  }

  final thirdPartyBase = _thirdPartyBaseOf(proto);

  // 三方包符号登记：值位置引用到的名字，若其声明属于「有宿主 JS 模块」的包，
  // 产物里必然以同名符号出现（构造 `RxInt(0)`、顶层值 `Get.put`），必须 import。
  final thirdPartyRefs = <String, Set<String>>{};
  void collectThirdPartyValues(AstNode node) {
    for (final name in referencedValueNames(node)) {
      final pkg = thirdPartyPackageOf(name);
      if (pkg != null) (thirdPartyRefs[pkg] ??= <String>{}).add(name);
    }
  }

  collectThirdPartyValues(hostClass);
  for (final (ref, _, _) in mixinInfos) {
    collectThirdPartyValues(ref.node);
  }
  final usedWidgetPackages = <String, Set<String>>{
    for (final e in parseCtx.usedWidgetPackages.entries) e.key: {...e.value},
  };
  for (final e in thirdPartyRefs.entries) {
    (usedWidgetPackages[e.key] ??= <String>{}).addAll(e.value);
  }
  if (thirdPartyBase != null) {
    (usedWidgetPackages[thirdPartyBase.$1] ??= <String>{}).add(thirdPartyBase.$2);
  }

  return ClassInfo(
    name: decl.name.lexeme,
    sourceFile: sourcePath,
    superType: proto.superType,
    widgetSuperType: proto.widgetSuperType,
    instanceFields: instanceFields,
    staticFields: staticFields,
    methods: translated,
    ctors: ctors,
    ctorParams: proto.ctorParams,
    ctorParamJs: unnamed.params,
    ctorInitJs: unnamed.inits,
    ctorBodyJs: unnamed.body,
    isComponent: isComponent,
    isAbstract: decl.abstractKeyword != null || hostClass.abstractKeyword != null,
    isCallable: proto.isCallable ||
        mixinInfos.any((e) => e.$3.isCallable),
    typeParams: proto.typeParams,
    // 依赖 = widget 树里的自定义组件（parseCtx 收集）+ 字段类型 / 方法体
    // 构造调用命中的类（含跨文件组件，如 CounterVm → BannerCard）。
    // 组件若 extends 项目内的另一个组件，基类也要能被 import（SDK 基类
    // StatelessWidget / StatefulWidget 由 flutter.js 导出，不进这里）。
    dependencies: {
      ...parseCtx.dependencies,
      ...used.keys,
      if (_projectBaseName(proto.widgetSuperType, classTable) case final b?) b,
    },
    usedWidgetPackages: usedWidgetPackages,
    namespaceImports: parseCtx.namespaceImports,
    mixinApplications: mixinApps,
  );
}

/// 基类来自三方包时 → (包名, 基类名)；否则 null。
///
/// 与 [jsBaseClassOf] 的三方分支同一判据（声明文件 → 包 → 宿主 `js/` 有模块）。
/// 该类在 JS 侧按原生 `extends` 继承基类，产物必须 import 这个符号。
(String, String)? _thirdPartyBaseOf(ClassInfo proto) {
  final t = proto.superType;
  if (t == null) return null;
  final name = t.split('<').first.trim();
  if (name.isEmpty) return null;
  final pkg = thirdPartyPackageOf(name);
  return pkg == null ? null : (pkg, name);
}

/// 纯 `mixin M { ... }` → 独立类产物（按声明源文件路径落盘）。
///
/// 与 [translateClass] 的区别只有「没有构造 / 没有 extends」：字段与方法仍是
/// 同一条翻译路径。带 `super` 的方法不在本模块发射——它在 `with` 的
/// application 类里按原生 super 重新发射（见 translateClass 的 mixin 层）。
ClassInfo translateMixin(
  MixinDeclaration decl,
  CompilationUnit unit,
  String sourcePath, {
  required Map<String, ClassInfo> classTable,
  required String? Function(String name) importResolver,
  Set<String> jsClassWidgets = const {},
  Set<String> delegateClassWidgets = const {},
  Set<String> ignoredTypes = const {},
  Set<String> globalConsts = const {},
  Map<String, String> prefixProducts = const {},
  Map<String, Map<String, String>> extensionOperators = const {},
  Map<String, ExtensionScope> extensionNames = const {},
}) {
  final hostFunctions = buildHostFunctions(unit, sourcePath);
  final structure = classInfoOf(ClassLikeDecl.ofMixin(decl), sourcePath);

  final used = <String, ClassInfo>{};
  for (final name in referencedClassNames(decl)) {
    final info = classTable[name];
    if (info != null) used[name] = info;
  }

  // 实例字段：初值口径与普通类完全一致（字面量 / 表达式 / 类型默认值）。
  final fieldNames = {for (final f in structure.instanceFields) f.name};
  final instanceFields = <ClassField>[];
  final propByField = <String, String>{};
  final mixinTypeParams = {
    for (final t in decl.typeParameters?.typeParameters ?? const <TypeParameter>[])
      t.name.lexeme,
  };
  for (final f in structure.instanceFields) {
    if (!_fieldTranslatable(f.typeName, classTable,
        typeParams: mixinTypeParams,
        sourcePath: sourcePath,
        node: f.node)) {
      log.warning(
        '[hot_patch_generator] ${sourceAt(sourcePath, f.node)}: '
        '跳过 mixin 字段 ${decl.name.lexeme}.${f.name}'
        '（类型 ${f.typeName} 不可翻译）',
      );
      continue;
    }
    final init = f.initializer;
    final initScope = FieldScope(
      sourcePath: sourcePath,
      instanceFields: fieldNames,
      globalConsts: globalConsts,
    );
    final initial = literalToJs(init) ??
        (init == null ? null : rhsToJs(init, initScope, used)) ??
        _defaultInitial(f.typeName);
    instanceFields.add(ClassField(
      name: f.name,
      typeName: f.typeName,
      jsInitial: initial,
    ));
    propByField[f.name] = f.name;
  }

  // static 字段 / 方法：mixin 类上的同名静态成员，调用点按类名访问。
  final staticNames = {for (final f in structure.staticFields) f.name};
  final staticMethods = {
    for (final m in structure.methods)
      if (m.isStatic) m.name,
  };
  final staticScope = FieldScope(
    sourcePath: sourcePath,
    className: decl.name.lexeme,
    staticFields: staticNames,
    staticMethods: staticMethods,
    globalConsts: globalConsts,
  );
  final staticFields = <ClassField>[];
  for (final f in structure.staticFields) {
    if (!_fieldTranslatable(f.typeName, classTable,
        typeParams: mixinTypeParams,
        sourcePath: sourcePath,
        node: f.node)) {
      continue;
    }
    final init = f.initializer;
    final initial = literalToJs(init) ??
        (init == null ? null : rhsToJs(init, staticScope, used)) ??
        (isBasicType(f.typeName) || _valueSdkTypes.contains(eraseType(f.typeName))
            ? _defaultInitial(f.typeName)
            : 'null');
    staticFields.add(ClassField(
      name: f.name,
      typeName: f.typeName,
      isStatic: true,
      jsInitial: initial,
    ));
  }

  final modelClassNames = <String>{
    for (final e in classTable.entries)
      if (!e.value.isComponent) e.key,
  };
  final parseCtx = ElementTranslateContext(
    propByField: propByField,
    actionByMethod: {
      for (final m in structure.methods)
        if (!m.isGetter && !m.isStatic) m.name: m.name,
    },
    methodNames: {
      for (final m in structure.methods)
        if (!m.isStatic) m.name,
    },
    methodArity: {
      for (final m in structure.methods)
        m.name: (m.isGetter || m.hasNamedParams) ? null : m.positionalParamCount,
    },
    getterNames: {
      for (final m in structure.methods)
        if (m.isGetter) m.name,
    },
    sourcePath: sourcePath,
    importResolver: importResolver,
    className: decl.name.lexeme,
    staticFieldNames: staticNames,
    staticMethodNames: staticMethods,
    globalConsts: globalConsts,
    hostFunctions: hostFunctions,
    jsClassWidgets: jsClassWidgets,
    delegateClassWidgets: delegateClassWidgets,
    ignoredTypes: ignoredTypes,
    modelClassNames: modelClassNames,
    prefixProducts: prefixProducts,
  );

  final proto = ClassInfo(
    name: decl.name.lexeme,
    sourceFile: sourcePath,
    instanceFields: instanceFields,
    staticFields: staticFields,
    methods: [
      for (final m in structure.methods)
        if (!_methodUsesSuper(m)) m,
    ],
    typeParams: [
      for (final t in decl.typeParameters?.typeParameters ?? const <TypeParameter>[])
        t.name.lexeme,
    ],
  );
  final translated = parseCtx.withExprRenderer(() => <ClassMethod>[
    for (final m in proto.methods)
      ClassMethod(
        name: m.name,
        params: m.params,
        isAsync: m.isAsync,
        isGetter: m.isGetter,
        isStatic: m.isStatic,
        isVoid: m.isVoid,
        returnsWidget: m.returnsWidget,
        body: m.body,
        bodyJs: translateClassMethodBody(proto, m, used,
            hostFunctions: hostFunctions,
            renderer: parseCtx,
            globalConsts: globalConsts,
            extensionOperators: extensionOperators,
            extensionNames: extensionNames),
        parameters: m.parameters,
        isSetter: m.isSetter,
        operatorSymbol: m.operatorSymbol,
        paramTypes: m.paramTypes,
        positionalParamCount: m.positionalParamCount,
        hasNamedParams: m.hasNamedParams,
        typeParams: m.typeParams,
      ),
  ]);

  return ClassInfo(
    name: decl.name.lexeme,
    sourceFile: sourcePath,
    instanceFields: instanceFields,
    staticFields: staticFields,
    methods: translated,
    isCallable: structure.isCallable,
    typeParams: proto.typeParams,
    dependencies: {
      ...parseCtx.dependencies,
      ...used.keys,
    },
    usedWidgetPackages: parseCtx.usedWidgetPackages,
    namespaceImports: parseCtx.namespaceImports,
  );
}

/// 命名构造 → 类上的同名静态方法（`static b(args) { ... }`）。
///
/// 调用点把构造实参按源码签名映射成 props 对象（`X.b(1, k: v)` →
/// `X.b({x: 1, k: v})`），因此静态方法只收一个 `args`，所有形参在方法体开头
/// 局部化成同名常量。
///
/// - 生成式构造：先 `new X(args)`（this.x 形参由 `constructor(args)` 应用），
///   再执行初始化列表的字段赋值，最后执行构造体；`this` 落点是 `__o`。
/// - factory 构造：直接翻译构造体（Dart 的 factory 里不允许 `this`）。
///
/// 无法等价翻译的初始化项（`super(...)` / `this.other(...)`）显式告警并跳过。
List<ClassCtor> _translateNamedCtors(
  ClassDeclaration decl,
  ClassInfo proto,
  Map<String, ClassInfo> classes, {
  required Set<String> hostFunctions,
  required Set<String> globalConsts,
  ExprRenderer? renderer,
}) {
  final cn = decl.name.lexeme;
  final instanceMethods = {
    ...objectMethodNamesOf(proto, classes),
    if (sdkBaseName(proto) != null) 'notifyListeners',
  };
  // 第一遍：只收集签名（形参名 / 是否 factory）。第二遍翻译构造体时需要看到
  // **全部**命名构造（构造体可能调用本类的另一个命名构造，前后顺序无关）。
  final decls = <_NamedCtorDecl>[];
  for (final c in decl.members.whereType<ConstructorDeclaration>()) {
    final name = c.name?.lexeme;
    // 无名构造由 `constructor(args)` 承接，不发射静态方法。
    if (name == null || name.isEmpty) continue;
    final params = <String>[];
    final positional = <String>[];
    final named = <String>{};
    final defaults = <String, Expression>{};
    for (final p in c.parameters.parameters) {
      final inner = p is DefaultFormalParameter ? p.parameter : p;
      final n = inner.name?.lexeme;
      if (n == null || n.isEmpty) continue;
      params.add(n);
      if (p.isNamed) {
        named.add(n);
      } else {
        positional.add(n);
      }
      if (p is DefaultFormalParameter && p.defaultValue != null) {
        defaults[n] = p.defaultValue!;
      }
    }
    decls.add(_NamedCtorDecl(
      decl: c,
      name: name,
      isFactory: c.factoryKeyword != null,
      params: params,
      positional: positional,
      named: named,
      defaults: defaults,
    ));
  }
  if (decls.isEmpty) return const <ClassCtor>[];
  // 类表里当前类的条目尚未带上 ctors（本函数正在生成它），用一份带签名的
  // 视图参与第二遍翻译，这样构造体里的 `X.other(...)` 能按源码签名映射 props。
  final localClasses = <String, ClassInfo>{
    ...classes,
    cn: (classes[cn] ?? proto).copyWith(ctors: [
      for (final d in decls)
        ClassCtor(
          name: d.name,
          bodyJs: '',
          isFactory: d.isFactory,
          positional: d.positional,
          named: d.named,
        ),
    ]),
  };
  final out = <ClassCtor>[];
  for (final d in decls) {
    final c = d.decl;
    final scope = FieldScope(
      instanceFields: d.isFactory
          ? const {}
          : {for (final f in objectFieldsOf(proto, classes)) f.name},
      params: d.params.toSet(),
      methods: d.isFactory ? const {} : instanceMethods,
      // 构造初始化器里的值位置同样要区分 getter（读值）与方法 tear-off（绑定）。
      getterNames: d.isFactory ? const {} : objectGetterNamesOf(proto, classes),
      className: cn,
      staticFields: {for (final f in proto.staticFields) f.name},
      staticMethods: {
        for (final m in proto.methods)
          if (m.isStatic) m.name,
      },
      // 类泛型：静态方法从调用点下发的 `args.typeArguments` 取实参。
      typeParams: {
        for (final t in proto.typeParams) t: '((args && args.typeArguments) || {})["$t"]',
      },
      hostFunctions: hostFunctions,
      globalConsts: globalConsts,
      thisRef: d.isFactory ? 'this' : '__o',
    );
    final b = StringBuffer();
    // 构造体里的构造调用先走 valueCtorJs：rhsToJs 的 constructionHook 会用
    // 「类自身字段作用域」渲染实参，把构造形参误当成实例字段（`this.title`）。
    String? ctorAware(Expression e) =>
        valueCtorJs(e, scope, localClasses) ?? rhsToJs(e, scope, localClasses);
    for (final p in d.params) {
      final dv = d.defaults[p];
      final dj = dv == null ? null : ctorAware(dv);
      if (dj != null && dj != 'undefined') {
        b.writeln('    const $p = args.$p !== undefined ? args.$p : $dj;');
      } else {
        b.writeln('    const $p = args.$p;');
      }
    }
    if (!d.isFactory) {
      b.writeln('    const __o = new $cn(args);');
      for (final init in c.initializers) {
        if (init is ConstructorFieldInitializer) {
          final v = ctorAware(init.expression);
          if (v == null) {
            log.warning('[hot_patch_generator] $cn.${d.name} 初始化列表项无法翻译，'
                '已跳过：${init.toSource()}');
            continue;
          }
          b.writeln('    __o.${init.fieldName.name} = $v;');
        } else if (init is AssertInitializer) {
          final cond = exprToJs(init.condition, scope, localClasses);
          final msg =
              init.message == null ? null : exprToJs(init.message!, scope, localClasses);
          if (cond == null) continue;
          b.writeln('    assert($cond${msg == null ? '' : ', $msg'});');
        } else {
          log.warning('[hot_patch_generator] $cn.${d.name} 初始化项 '
              '${init.toSource()} 无法等价翻译（基类构造已由 new 承接），已跳过。');
        }
      }
    }
    final body = c.body;
    if (body is ExpressionFunctionBody) {
      // factory 的箭头体（`factory X.b(...) => X.other(...)`）：按**值表达式**
      // 翻译，走 rhsToJs 的构造统一规则（`X.other(...)` → `X.other({...})`）。
      final v = ctorAware(body.expression);
      if (v == null) {
        log.warning('[hot_patch_generator] $cn.${d.name} 构造体表达式无法翻译，'
            '已丢弃：${body.expression.toSource()}');
      } else {
        b.writeln('    return $v;');
      }
    } else {
      b.write(translateMethodBody(
        body,
        scope,
        localClasses,
        renderer: renderer,
        returnExpressionBody: true,
        returnsWidget: false,
        depth: 2,
      ));
    }
    if (!d.isFactory) b.writeln('    return __o;');
    out.add(ClassCtor(
      name: d.name,
      bodyJs: b.toString(),
      isFactory: d.isFactory,
      positional: d.positional,
      named: d.named,
    ));
  }
  return out;
}

/// 无名构造（默认构造）→ `constructor(args)` 内的三段语句。
///
/// 与命名构造同一套规则（[ConstructorFieldInitializer] / [AssertInitializer]
/// 翻译、`super(...)` / `this.other(...)` 跳过并告警），差别只在落点：
///   - [params]：形参局部绑定 `const p = args.p;`（供初始化列表 / 构造体引用）；
///   - [inits]：初始化列表 → `this.x = <expr>;`（排在字段默认赋值之后，
///     等价于 Dart 的「字段初始化器 → 初始化列表 → 构造体」）；
///   - [body]：构造体语句。
///
/// 没有初始化列表 / 构造体的空构造（widget 的 `const A({super.key})`）返回全空，
/// 既有 `constructor()` / `constructor(args)` 形态不变。
({List<String> params, List<String> inits, String body}) _translateUnnamedCtor(
  ClassDeclaration decl,
  ClassInfo proto,
  Map<String, ClassInfo> classes,
  List<ClassField> instanceFields, {
  required Set<String> hostFunctions,
  required Set<String> globalConsts,
  ExprRenderer? renderer,
}) {
  const empty = (params: <String>[], inits: <String>[], body: '');
  ConstructorDeclaration? c;
  for (final m in decl.members) {
    if (m is ConstructorDeclaration && (m.name?.lexeme ?? '').isEmpty) {
      c = m;
      break;
    }
  }
  if (c == null || c.factoryKeyword != null) return empty;

  final paramNames = <String>[];
  final defaults = <String, Expression>{};
  for (final p in c.parameters.parameters) {
    final inner = p is DefaultFormalParameter ? p.parameter : p;
    final n = inner.name?.lexeme;
    if (n == null || n.isEmpty) continue;
    paramNames.add(n);
    if (p is DefaultFormalParameter && p.defaultValue != null) {
      defaults[n] = p.defaultValue!;
    }
  }

  // 初始化列表只能引用形参与静态成员（Dart 禁止 `this`），因此作用域不给
  // 实例字段 / 实例方法——把裸字段名当 `this.x` 会改变语义。
  final initScope = FieldScope(
    params: paramNames.toSet(),
    className: proto.name,
    staticFields: {for (final f in proto.staticFields) f.name},
    staticMethods: {
      for (final m in proto.methods)
        if (m.isStatic) m.name,
    },
    typeParams: {
      for (final t in proto.typeParams)
        t: '((args && args.typeArguments) || {})["$t"]',
    },
    hostFunctions: hostFunctions,
    globalConsts: globalConsts,
  );
  final inits = <String>[];
  for (final init in c.initializers) {
    if (init is ConstructorFieldInitializer) {
      final v = rhsToJs(init.expression, initScope, classes);
      if (v == null) {
        log.warning('[hot_patch_generator] ${proto.name} 默认构造初始化列表项'
            '无法翻译，已跳过：${init.toSource()}');
        continue;
      }
      inits.add('this.${init.fieldName.name} = $v;');
    } else if (init is AssertInitializer) {
      final cond = exprToJs(init.condition, initScope, classes);
      final msg =
          init.message == null ? null : exprToJs(init.message!, initScope, classes);
      if (cond == null) continue;
      inits.add('assert($cond${msg == null ? '' : ', $msg'});');
    } else {
      log.warning('[hot_patch_generator] ${proto.name} 默认构造初始化项 '
          '${init.toSource()} 无法等价翻译（基类构造已由 new 承接），已跳过。');
    }
  }

  // 构造体：实例成员可读（`this` 落点是 JS 构造器本身），与命名构造同一条
  // 方法体翻译器。
  final bodyScope = FieldScope(
    instanceFields: {for (final f in instanceFields) f.name},
    params: paramNames.toSet(),
    methods: {
      for (final m in proto.methods)
        if (!m.isGetter && !m.isStatic) m.name,
    },
    getterNames: {
      for (final m in proto.methods)
        if (m.isGetter) m.name,
    },
    className: proto.name,
    staticFields: {for (final f in proto.staticFields) f.name},
    staticMethods: {
      for (final m in proto.methods)
        if (m.isStatic) m.name,
    },
    typeParams: {
      for (final t in proto.typeParams)
        t: '((args && args.typeArguments) || {})["$t"]',
    },
    hostFunctions: hostFunctions,
    globalConsts: globalConsts,
    thisRef: 'this',
  );
  final body = c.body;
  String bodyJs = '';
  if (body is BlockFunctionBody) {
    bodyJs = translateMethodBody(
      body,
      bodyScope,
      classes,
      renderer: renderer,
      returnExpressionBody: false,
      returnsWidget: false,
      depth: 2,
    );
  } else if (body is! EmptyFunctionBody) {
    log.warning('[hot_patch_generator] ${proto.name} 默认构造体形态无法翻译，'
        '已跳过：${body.toSource()}');
  }

  if (inits.isEmpty && bodyJs.isEmpty) return empty;
  final params = <String>[];
  for (final n in paramNames) {
    final dv = defaults[n];
    final dj = dv == null ? null : rhsToJs(dv, initScope, classes);
    params.add(dj != null && dj != 'undefined'
        ? 'const $n = args.$n !== undefined ? args.$n : $dj;'
        : 'const $n = args.$n;');
  }
  return (params: params, inits: inits, body: bodyJs);
}

/// [_translateNamedCtors] 第一遍收集的签名事实。
class _NamedCtorDecl {
  const _NamedCtorDecl({
    required this.decl,
    required this.name,
    required this.isFactory,
    required this.params,
    required this.positional,
    required this.named,
    required this.defaults,
  });

  final ConstructorDeclaration decl;
  final String name;
  final bool isFactory;
  final List<String> params;
  final List<String> positional;
  final Set<String> named;
  final Map<String, Expression> defaults;
}

/// 组件 extends 的**项目内**基类名（SDK 基类返回 null：由 flutter.js 导出）。
String? _projectBaseName(String? superType, Map<String, ClassInfo> classTable) {
  final name = superType?.split('<').first.trim();
  if (name == null || name.isEmpty) return null;
  return classTable.containsKey(name) ? name : null;
}

/// 类 + 同文件 State 类（StatefulWidget 的字段 / 方法 / 依赖分布在两个类里，
/// 翻译与依赖发现都必须合并扫描）。非 StatefulWidget → 只返回自身。
List<ClassDeclaration> classAndStateDecls(
  ClassDeclaration decl,
  CompilationUnit unit,
) {
  final stateName = stateClassNameOf(decl);
  if (stateName == null) return [decl];
  for (final d in unit.declarations) {
    if (d is ClassDeclaration && d.name.lexeme == stateName) return [decl, d];
  }
  return [decl];
}

/// 取 StatefulWidget 的 State 类名：解析 createState() 返回的构造
/// （`_MyCardState()` 在无 resolution 下可能是 MethodInvocation）。
/// 未声明 createState → null（StatelessWidget / 普通类）。
///
/// 公开供跨包模块复用：State 类随 widget 类合并产出（见 [translateClass]），
/// 不单独成为一个模型类。
String? stateClassNameOf(ClassDeclaration widgetClass) {
  for (final m in widgetClass.members) {
    if (m is MethodDeclaration && m.name.lexeme == 'createState') {
      final e = _methodExpression(m);
      if (e is InstanceCreationExpression) {
        return e.constructorName.type.name2.lexeme;
      }
      if (e is MethodInvocation) {
        return e.methodName.name;
      }
    }
  }
  return null;
}

Expression? _methodExpression(MethodDeclaration m) {
  final body = m.body;
  if (body is ExpressionFunctionBody) return body.expression;
  if (body is BlockFunctionBody) {
    for (final s in body.block.statements) {
      if (s is ReturnStatement) return s.expression;
    }
  }
  return null;
}

/// 基础类型字段的默认初值：无初始化器且非常量初始化表达式时兜底。
/// 泛型容器按外层类型给空集合（`List<Spot>` → `[]`、`Map<K,V>` → `{}`），
/// 保证 JS 侧漏传 props 时遍历/取值不炸；对象类型（模型字段）给 `null`
/// ——给 `0` 会让「漏传」变成更难排查的假数据。
String _defaultInitial(String typeName) {
  // 可空类型（`String?` / `int?` / `List<T>?`）无初始化器时 Dart 语义就是 null，
  // 不能给类型默认值：`''`/`0`/`false` 会让 `x ?? 回退值` 直接取到该默认值而
  // 永不回退（订单页 `widget.initialStatus ?? kOrderStatus.first` 因此把「全部」
  // 筛成空列表）。
  if (typeName.trim().endsWith('?')) return 'null';
  final t = eraseType(typeName);
  if (t == 'String') return "''";
  if (t == 'bool') return 'false';
  if (t == 'List' || t == 'Set' || t == 'Iterable') return '[]';
  // Map 默认空值：原生 JS Map（成员由运行时 Map.prototype 补齐）。
  if (t == 'Map') return 'new Map()';
  if (isBasicType(t)) return '0'; // int / double / num
  return 'null';
}

/// 泛型容器类型（字段类型里的外层名）。
const Set<String> _containerTypes = {'List', 'Set', 'Iterable', 'Map'};

/// 函数值类型（事件回调字段）：JS 侧函数就是值，原样持有 / 传递即可。
/// `onTap` / `onPick` / `onReset` 这类字段不再被跳过。
const Set<String> _callbackTypes = {
  'Function',
  'VoidCallback',
  'ValueChanged',
  'ValueGetter',
  'ValueSetter',
  'AsyncCallback',
  'GestureTapCallback',
  'GestureLongPressCallback',
  'GestureTapDownCallback',
  'WidgetBuilder',
  'IndexedWidgetBuilder',
};

/// 可承载「元素值」的字段类型：JS 侧元素就是普通对象（`{type, props,
/// children}`），持有 / 转发没有障碍。`child` / `children` / `trailing` /
/// `leading` / `title` 这类 widget 字段因此能进实例属性，`Row(children:
/// children)` 也能拿到真实数组。
const Set<String> _widgetValueTypes = {'Widget', 'PreferredSizeWidget'};

/// 有 JS 运行时对应物的 SDK 字段类型（字段可持有 / 转发，初值走通用表达式翻译）：
///   - `Color` → `'#aarrggbb'`、`IconData` → 图标名（运行时映射回真实对象）；
///   - `ValueNotifier` → JS 侧注入的同名类实例（句柄式，见 hot_patch 的
///     change_notifier_js.dart），构造走 [sdkValueCtorJs] → `new ValueNotifier(0)`。
/// 缺了它，`_OrderCard.statusColor` / `_DevRow.icon` 这类字段会被整条跳过，
/// 传进来也用不上（子组件里 `color: statusColor` 解析失败）；`_count` 同理
/// （`ValueListenableBuilder(valueListenable: _count)` 会取不到字段）。
const Set<String> _valueSdkTypes = {'Color', 'IconData', 'ValueNotifier'};

/// 字段类型是否可翻译（进 JS 实例属性）：
///   - 基础类型（int/double/num/String/bool/dynamic）；
///   - JS 运行时同名代理类（ScrollController / TextEditingController / …）；
///   - 类表里能解析到的类（组件 / 模型）：字段持元素或普通对象；
///   - 有 JS 运行时对应物的 SDK 类型（Color / IconData / ValueNotifier）；
///   - 函数值类型（VoidCallback / `void Function(...)`）——事件回调字段；
///   - 元素值类型（`Widget` / `List<Widget>`）——JS 侧元素是普通对象；
///   - 泛型容器按**类型实参**递归判定：`List<Spot>` / `Map<String, int>` /
///     `List<Widget>` 可翻译，`Key?` 不可翻译；
///   - **类自身的类型参数**（`class Pair<K, V>` 的 `K` / `V`）：泛型擦除，字段
///     值任意，可翻译且不出声（[typeParams]）；
///   - 源码里的**简单枚举**：JS 侧是声明文件产物里的同名值对象，可翻译；
///   - **解析不到的类型**（如 `package:flutter` 的 `Text` / `Column`，或三方类型）：
///     按宿主 Widget 值处理并输出构建期告警——字段判定不做任何类型名单过滤。
bool _fieldTranslatable(
  String typeName,
  Map<String, ClassInfo> classTable, {
  Set<String> typeParams = const {},
  String sourcePath = '',
  AstNode? node,
}) {
  if (typeName.trim().endsWith('?')) {
    return _fieldTranslatable(
      typeName.trim().substring(0, typeName.trim().length - 1),
      classTable,
      typeParams: typeParams,
      sourcePath: sourcePath,
      node: node,
    );
  }
  // `ui.Image` / `math.Point` 这类**带 import 前缀**的类型：JS 侧没有前缀概念
  // （类型名一律擦除前缀），按简单名继续判定（`ui.Image` → `Image`）。
  final t = _stripImportPrefix(typeName.trim());
  if (isBasicType(t)) return true;
  final lt = t.indexOf('<');
  final base = lt >= 0 ? t.substring(0, lt).trim() : t;
  // 类自身的**类型参数**（`class Pair<K, V>` 的 `K` / `V`）：JS 侧泛型擦除，
  // 字段值是任意对象，按可翻译处理（不是「解析不到的类型」，不该出声）。
  if (typeParams.contains(base)) return true;
  // 函数值：`void Function(String, String)`（`Function(` 形态）与
  // `VoidCallback` / `ValueChanged<int>` 这类 typedef 都放行。
  if (_callbackTypes.contains(base) || t.contains('Function(')) return true;
  // 带类型实参的 SDK 类型（`ValueNotifier<int>`）：JS 侧没有泛型，实参只是
  // 静态信息，字段本体是可持有 / 转发的对象，直接放行。必须早于下面的
  // 容器分支——`ValueNotifier` 不在 `_containerTypes` 里，否则显式标注
  // `final ValueNotifier<int> _count = ValueNotifier<int>(0);` 会被整条跳过。
  if (lt >= 0 && t.endsWith('>') && _valueSdkTypes.contains(base)) return true;
  if (lt >= 0 && t.endsWith('>')) {
    if (_containerTypes.contains(base)) {
      final args = _typeArgs(t.substring(lt + 1, t.length - 1));
      return args.isNotEmpty &&
          args.every((a) => _fieldTranslatable(a, classTable,
              typeParams: typeParams, sourcePath: sourcePath, node: node));
    }
    // 非容器泛型（`GlobalKey<AnimatedListState>` / `ValueNotifier<int>` / 自定义
    // `Foo<T>`）：JS 无泛型，类型实参只是**静态信息**，字段本体是否可持有只看
    // base 类型。这里递归按 base 判定，等价于把类型实参擦除——与 Dart→JS 的
    // 类型擦除一致，不做任何类型名单过滤。
    return _fieldTranslatable(base, classTable,
        typeParams: typeParams, sourcePath: sourcePath, node: node);
  }
  if (t.isEmpty) return false;
  // 源码里能解析到构造的类（SDK / 依赖包 / 项目类）：JS 侧有同名类承载，
  // 字段可持有/转发。判据只看源码签名，与具体类名无关。
  if (CtorSignatures.instance?.of(t) != null) return true;
  // 有 JS 值形态的 SDK 类型（Color → '#aarrggbb'、IconData → 图标名）。
  if (_valueSdkTypes.contains(t)) return true;
  // 元素值字段（`Widget` / `PreferredSizeWidget`）：字段持元素对象。
  if (_widgetValueTypes.contains(t)) return true;
  // 类表里能解析到的类（组件 / 模型）。
  if (classTable.containsKey(t)) return true;
  // 源码里的简单枚举：JS 侧是声明文件产物里的同名值对象（`export const X`），
  // 字段持有的是枚举值，可翻译且不需要出声。
  if (CtorSignatures.instance?.isEnum(t) ?? false) return true;
  // 解析不到的其余类型：按宿主 Widget 值处理，并出声（避免静默误判）。
  log.warning(
    '[hot_patch_generator] ${sourceAt(sourcePath, node)}: 字段类型 $t 无法从本地源码解析，'
    '按宿主 Widget 值处理（组件 / 三方类型请确认其 JS 侧有同名类）',
  );
  return true;
}

/// 擦除类型名上的 **import 前缀**（`ui.Image` → `Image`、`math.Point` → `Point`）。
///
/// 前缀只存在于 Dart 源码（`import 'dart:ui' as ui`），JS 侧类型名一律不带前缀；
/// 字段判定按简单名继续走构造签名 / 类表 / 值类型，避免把 `ui.Image` 这类
/// 有宿主句柄的类型误判成「解析不到」。
String _stripImportPrefix(String t) {
  final lt = t.indexOf('<');
  final base = lt >= 0 ? t.substring(0, lt) : t;
  final dot = base.indexOf('.');
  if (dot <= 0) return t;
  // 只认小写开头的 import 前缀（类型名本身不允许带成员访问，点号只来自前缀）。
  if (!RegExp(r'^[a-z_$][A-Za-z0-9_$]*$').hasMatch(base.substring(0, dot))) {
    return t;
  }
  return t.substring(dot + 1);
}

/// 拆分泛型类型实参（按顶层逗号，忽略嵌套尖括号里的逗号）。
List<String> _typeArgs(String src) {
  final out = <String>[];
  var depth = 0;
  var start = 0;
  for (var i = 0; i < src.length; i++) {
    final c = src[i];
    if (c == '<') depth++;
    if (c == '>') depth--;
    if (c == ',' && depth == 0) {
      out.add(src.substring(start, i));
      start = i + 1;
    }
  }
  out.add(src.substring(start));
  return [for (final s in out) if (s.trim().isNotEmpty) s.trim()];
}

/// 提取 SnackBar 消息字符串：方法体为
/// `showSnackBar(SnackBar(content: Text('...')))` 时返回消息的 JS 字符串
/// 字面量（整体方法改译为 nativeToast 宿主通道）；否则 null。
String? _snackMessage(FunctionBody body, ElementTranslateContext ctx) {
  Expression? outer;
  if (body is ExpressionFunctionBody) {
    outer = body.expression;
  } else if (body is BlockFunctionBody) {
    for (final s in body.block.statements) {
      if (s is ExpressionStatement) {
        outer = s.expression;
        break;
      }
    }
  }
  if (outer is MethodInvocation && outer.methodName.name == 'showSnackBar') {
    final args = outer.argumentList.arguments;
    if (args.isNotEmpty) {
      final snack = args.first;
      // 无 const 的 Foo(...) 在无 resolution 的 parseString 下是 MethodInvocation，
      // 统一用 ctx.ctorOf 取构造名与参数。
      final (snackCtor, snackArgs) = ctx.ctorOf(snack);
      if (snackCtor == 'SnackBar') {
        final content = ctx.namedArg(snackArgs, 'content');
        if (content != null) {
          final (textCtor, textArgs) = ctx.ctorOf(content);
          if (textCtor == 'Text') {
            final data = ctx.positionalArg(textArgs, 0);
            if (data is StringLiteral) return ctx.jsString(data.stringValue ?? '');
          }
        }
      }
    }
  }
  return null;
}
