import 'package:analyzer/dart/ast/ast.dart';
import 'package:analyzer/dart/ast/visitor.dart';
import 'package:build/build.dart' show log;

import '../../shared/ctor_signatures.dart';
import '../../shared/js_class_defs.dart';
import '../../shared/source_index.dart';
import '../../shared/source_location.dart';
import 'js_translator.dart';
import 'js_value.dart';
import 'element_json.dart';

// ===========================================================================
// element2js：widget → JS（build 树的翻译与渲染）
//
// widget 在 JS 端没有等价物，需专门翻译：
//   - build 树解析：ElementNode / ElementTranslateContext（表达式 → 中立描述）
//   - 中立描述 → JS：`new Type(props)` 构造调用树（实参按原名进 props，
//     宿主包装类在构造期由 Component.__splitHost 拆分 props / __children）
//   - 统一翻译入口：element_json.dart（elementToJson）+ value_forms.dart（autoValue）
//   静态成员引用（`MyColors.background` / 类内 `fromJson(...)`）走通用
//   `类名.成员` 规则，与普通实例成员同一套作用域
// [ElementTranslateContext] 实现 js_translator 的 [ExprRenderer]，供
// 「Dart 类 → JS」在方法体里渲染返回的 widget。
//
// 扩展方式：**没有** per-widget 的翻译类。任意 widget（内建 / 自定义 / 三方）
// 都走同一条路径——按实参名约定（on* 事件 / delegate 子结点提供者 / 位置形参名）
// 与**值的形态**（字面量 / 构造 / 静态工厂 / 常量引用 / 列表 / 闭包）分派，
// 接入新组件零实现。
// ===========================================================================

/// 一个 widget 构造节点的中立表示（build() 树解析的中间产物）。
///
/// 不直接依赖某个具体 widget：type 是构造名（'Column'/'Text'/...）。
/// [args] 保留原始参数列表（含 NamedExpression，供 ctx 的 namedArg/
/// positionalArg/listArg 解析）；[positionalArgs]/[namedArgs] 是拆分视图。
class ElementNode {
  final String type;
  final List<Expression> args;
  final List<Expression> positionalArgs;
  final Map<String, Expression> namedArgs;

  /// 原始表达式（InstanceCreationExpression 等，取类型参数等用）。
  final Expression? expr;

  ElementNode(this.type, this.args, {this.expr})
    : positionalArgs = [
        for (final a in args)
          if (a is! NamedExpression) a,
      ],
      namedArgs = {
        for (final a in args)
          if (a is NamedExpression) a.name.label.name: a.expression,
      };
}

/// const 构造的缓存键分配器：给每个 const 站点分配本类内递增的短编号
/// （`0`、`1`…），生成代码用 `this.__k<编号>` 保存该站点构造出的实例。
///
/// 为什么按「实例」缓存而不是模块级：const 实例的生命周期应与使用它的组件
/// 实例一致——组件卸载（页面退出）后缓存随实例一起被 GC，不需要手动释放；
/// 而同一实例内的多次 build 仍拿到同一对象，父级重建时可按引用短路。
class ConstKeyAllocator {
  final Map<String, int> _byValue = {};
  int _seq = 0;

  int idFor(String canonicalCall) => _byValue.putIfAbsent(canonicalCall, () => _seq++);
}

/// 翻译上下文：持有注册表与组件元数据，并向 translator 提供通用解析能力。
///
/// translator 通过 [translate] 递归子节点、通过 [renderJs] 递归渲染子节点，
/// 通过 [jsDataExpr]/[eventOf]/[propOf] 等 helper 解析参数。
class ElementTranslateContext implements ExprRenderer {
  final Map<String, String> propByField;
  final Map<String, String> actionByMethod;
  final String sourcePath;

  /// 本类**全部**实例方法 / getter 名（含非动作方法，如返回字符串的
  /// `_likeText`）。JS 类根部会生成所有方法，故数据表达式里的裸调用
  /// （`Text(_likeText(post.like))`）应翻译成 `this._likeText(...)`，而不只限于
  /// 注册为动作的方法。缺了它，非动作方法调用会整条翻译失败。
  final Set<String> methodNames;

  /// 方法名 → 位置形参个数（含可选位置形参）。null = 含具名形参（具名实参走
  /// 尾参对象约定，只能 `...__a` 原样转发）。方法 tear-off 据此生成精确形参：
  /// 零参回调 `() => this._insert()`，避免无意义的 rest / spread。
  final Map<String, int?> methodArity;

  /// 本类 **getter** 名（`_visiblePosts` 这类）。getter 在 JS 类里是 `get` 访问器，
  /// 作为**函数值**传参时只能按值读（`this._visiblePosts`），不能像方法那样包装成
  /// 调用（`(...__a) => this._visiblePosts(...__a)` —— 访问器不可调用，传出去的
  /// 是函数而非 getter 的值，子组件拿到 `.length` 为 0 的空数据）。
  final Set<String> getterNames;

  /// 组件名 → 依赖产物 jsAsset 路径（null = 无法确定，渲染层走原生注入）。
  /// 由生成器注入：本文件私有/注解组件 → 本文件产物；跨文件组件 →
  /// 从 import directives 推导源文件产物。未注册/兜底组件结点据此产出 import，
  /// 运行时按 import 递归挂载嵌套组件（使用方无需知道依赖）。
  final String? Function(String component)? importResolver;

  /// 本文件可见的顶层常量名（同文件 + import 文件）：build 树里 `kBrand` /
  /// `kBanners` 这类引用与字段初值、方法体共用同一份作用域。
  @override
  final Set<String> globalConsts;

  /// 顶层 `@HostInjected` 函数名：事件表达式 / 数据表达式里的裸调用
  /// （`toast('x')`）要译成 `_app_host_.invoke("通道", 载荷)`——顶层函数没有
  /// 可承载的 JS 类。类上的宿主方法不走这里（调用点与 Dart 一比一）。
  final Set<String> hostFunctions;

  /// 翻译过程中遇到的未注册自定义组件（兜底结点），供生成器
  /// 收集后把本文件内可解析的私有组件（_Xxx）翻译成嵌套组件注册进产物。
  final Set<String> dependencies = {};

  /// 翻译/渲染过程中**实际用到**的 widget 类型：package → {type}。
  /// [renderJs] 在此登记，生成器据此按 package 产出 JS widget 模块并 import。
  final Map<String, Set<String>> usedWidgetPackages = {};

  /// import 前缀（`import '...' as p;`）→ 该前缀在 JS 侧的模块产物路径。
  ///
  /// Dart 用前缀消解同名类；JS 侧同一件事由**模块命名空间**承接（`p.Foo`）。
  /// 前缀不在表里（`dart:` 导入 / 没有 JS 模块的三方包）时退回裸类名。
  final Map<String, String> prefixProducts;

  /// 翻译/渲染过程中实际用到的前缀 → 产物路径。
  /// 生成器据此为产物补 `import * as <prefix> from '<产物>';`。
  final Map<String, String> namespaceImports = {};

  /// 是否产出过 `const` 元素缓存（产物头部需 `var __const = {};`）。
  /// const 缓存键的分配器：每个类一份（编号只在该类的 `this` 上做字段名，
  /// 因此不需要跨类唯一）。
  final ConstKeyAllocator? constKeyAllocator;
  final ConstKeyAllocator _localConstKeys = ConstKeyAllocator();

  ConstKeyAllocator get constKeys => constKeyAllocator ?? _localConstKeys;

  ElementTranslateContext({
    required this.propByField,
    required this.actionByMethod,
    required this.sourcePath,
    this.methodNames = const {},
    this.methodArity = const {},
    this.getterNames = const {},
    this.importResolver,
    this.globalConsts = const {},
    this.hostFunctions = const {},
    this.jsClassWidgets = const {},
    this.delegateClassWidgets = const {},
    this.ignoredTypes = const {},
    this.modelClassNames = const {},
    this.className,
    this.staticFieldNames = const {},
    this.staticMethodNames = const {},
    this.constKeyAllocator,
    this.prefixProducts = const {},
  });

  /// 本文件 / import 可见的**普通类（模型）**名（classTable 里 !isComponent）。
  /// 值位置上的构造只排除这些类与值对象，其余一律按组件构造翻译——不再维护
  /// 「哪些类型是 widget」的白名单。
  final Set<String> modelClassNames;

  /// 当前翻译的类名（静态成员引用 `ClassName.x` 的落点）；null = 不在类里
  /// （扩展 / 产物级常量求值）。
  final String? className;

  /// 当前类的 **static 字段** / **static 方法**名：build 树里裸引用静态成员
  /// （`background` / `fromJson(...)`）时落成 `ClassName.<name>`。
  final Set<String> staticFieldNames;
  final Set<String> staticMethodNames;

  /// 名字是否是产物可见的项目类（类表里的非组件类）——`Owner.member` 的
  /// owner 是它时按类静态成员引用，而不是枚举成员名字符串。
  bool isProjectClass(String name) => modelClassNames.contains(name);


  /// 有 JS 类实现的 widget 类型（组件、逻辑 widget、builder 代理）。
  /// 由生成器注入（builder 的模板表是唯一事实源）。
  final Set<String> jsClassWidgets;

  /// 仅 builder 形态才走 JS 类的类型（滚动视图/sliver 代理：普通
  /// `GridView(children: [...])`、`SliverList(delegate: ...)` 仍是宿主节点，
  /// `.builder` / `.separated` 形态才需要类来循环调用拥有者方法展开子树）。
  final Set<String> delegateClassWidgets;

  /// 本文件可见的 `@PatchIgnore()`（`isComponent` 非 true）类名：整类不翻译、
  /// 不产出任何 JS 类，使用方引用它的结点直接降级丢弃（构建期告警）。
  final Set<String> ignoredTypes;

  /// 记录一个被兜底为「保留具体类型名结点」的自定义组件名。
  void collectDependency(String name) => dependencies.add(name);

  // -------------------------------------------------------------------------
  // 递归入口：表达式 → JSON 描述 / JS 渲染
  // -------------------------------------------------------------------------

  /// 把 build() 里的一个 widget 表达式翻译成中立描述（渲染层据此产出 JS）。
  ///
  /// 返回 Map = 普通节点；返回 String = **单元素**位置的 JS 源码，渲染层原样
  /// 内联（widget 位置三目 `cond ? A() : B()` → `(condJs ? A : B)`，每支各是
  /// **一个**元素，不是数组——见 [_elementExprJs]）；返回 null = 翻译失败。
  ///
  /// **失败一律返回 null（由调用方丢弃该结点）+ 构建期告警，绝不伪造元素**：
  /// 早期实现兜底成 `SizedBox()`，结果是产物里出现一个「成功渲染的空盒子」，
  /// 把「翻译失败」变成看不出来的静默错误（列表被筛空、布局塌陷都源于此）。
  /// 单个叶子失败仍不影响兄弟结点（每次递归各自兜底），只是该结点不产出。
  @override
  Object? translate(Expression e) {
    try {
      return _translateExpr(e);
    } catch (err) {
      _warnDegrade(sourcePath, 'widget 表达式', e.toSource(), err, node: e);
      return null;
    }
  }

  Object? _translateExpr(Expression e) {
    if (e is ConditionalExpression) {
      // widget 位置三目：每支都是**单个**元素（`child: cond ? A : B`）。
      // 绝不能走 [_collectionArrayJs]——那产出的是「元素数组」，用在单子位置
      // 会变成 props.child 里的嵌套数组（`[ (cond ? [A] : [B]) ]`），宿主包装类
      // 抽 children 时 `mount` 拿到数组 → `el.type` undefined → `new el.type` 抛错。
      final cond = jsDataExpr(e.condition);
      // 分支翻译失败 → 该分支渲染成 `null`（= 没有元素）；魔术占位元素不允许。
      final thenJs = _elementExprJs(e.thenExpression) ?? 'null';
      final elseJs = _elementExprJs(e.elseExpression) ?? 'null';
      return '($cond ? $thenJs : $elseJs)';
    }
    // widget 位置上可能是「构造形态」的只有：InstanceCreationExpression
    // （`const Text(..)`）、无 receiver 的裸调用（`Text(..)` / `_LabeledDivider(..)`）、
    // 以及**静态工厂**（`Image.network(..)` / `Positioned.fill(..)`）。
    // 其余表达式——带实例 receiver 的方法调用（`_modelA.buildText()`）、
    // 字段/属性引用——都是**普通 JS 表达式**，运行时求值即得到元素；绝不能当
    // 组件类构造（否则会把实例方法 `_buildText` 误判成名为 `_buildText` 的组件，
    // 产出错误的兜底结点）。区分靠「构造名是否命中已注册 translator」：
    // 静态工厂的 receiver 是类名，必然命中；实例方法/字段的 receiver 不会命中。
    final (ctor, _) = ctorOf(e);
    if (ctor == null) return _exprAsElement(e);
    // 组件构造的构造名是**类名**（`Image.network(...)` / `Transform.translate(...)`
    // 这类命名构造与静态工厂都归一到类名）；实例方法调用（`_model.build()`、
    // `context.read<T>()`）与命中动作表的裸调用都是普通表达式。判据只看名字
    // 形态，与 widget 类型无关。
    if (e is MethodInvocation) {
      // 判据用**裸类名**：`p.Foo(...)` 的类型引用 token 带前缀，但「是不是
      // 类名形态」只取决于最后一段。
      final ctorName = bareTypeName(ctor);
      if (actionByMethod.containsKey(ctorName)) return _exprAsElement(e);
      if (!isClassName(ctorName)) return _exprAsElement(e);
    }
    // 统一翻译：任意构造 → 结点（不查注册表、不区分内建/自定义）。未识别的
    // 自定义与三方组件同样产出「保留具体类型名」的结点，运行时按需由宿主
    // jsWidgetRegistry 注册（jsWidgetRegistry.register）或给出可见占位。
    // 带 import 前缀的类定义在别的产物里（命名空间 import 已登记），不作为
    // 本产物的依赖递归，否则会按裸名把另一个同名的本地类拉进来。
    if (ctor == bareTypeName(ctor)) collectDependency(ctor);
    final node = _toNode(e);
    final json = elementToJson(node, this);
    // `key:` 是跨所有 widget 的通用参数（Key 是值不是结点），此处统一注入
    // props['key']（见 [_applyKeyProp]）。
    _applyKeyProp(json, node);
    // 显式 `const` 构造（`const HomePage()` / `const SizedBox(...)`）：Dart 会把
    // 它们规范化成同一 Widget 实例，父级重建时原生 `updateChild` 按引用短路。
    // 产物若每次 build 都 `new` 一次，就会把 const 子组件误判成“新 widget”，
    // 白跑一次 didUpdateWidget + build，故标记后由 [_renderCall] 做站点缓存。
    if (e is InstanceCreationExpression && e.isConst) {
      json['__constSite'] = true;
      // const 值的同一性只看「类型 + 实参值」，与命名实参的书写顺序无关：
      // `const SizedBox(width: 8, height: 12)` 与 `(height: 12, width: 8)` 在
      // Dart 里是同一个实例。产物按排序后的键渲染，缓存 key 因此也与顺序无关。
      json['props'] = _constCanonical(json['props']);
    }
    return json;
  }

  /// widget 位置上的「非构造表达式」→ JS 表达式字符串（运行时求值即元素）：
  /// `_buildText()` / `_modelA.buildText()` / 字段引用等。翻译不了则出声抛错。
  Object? _exprAsElement(Expression e) {
    try {
      return jsDataExpr(e);
    } catch (err) {
      throw FormatException(
        'hot_patch_generator: widget 位置的表达式无法翻译：'
        '${e.toSource()}（$err）',
      );
    }
  }

  /// 把 widget 构造里的 `key:` 实参注入到翻译产物的 props['key']。
  ///
  /// `key` 是**所有 widget 共有的通用参数**（Key 是**值**不是结点，见
  /// js_translator.keyCtorJs）——各 translator 只挑自己关心的参数，故 key 必须
  /// 在这里统一注入，否则被静默丢弃（曾导致 ReorderableListView 项的
  /// `key: ValueKey(item)` 丢失、重排后列表状态错位）。
  /// 产物 props['key'] 存 JS 表达式字符串（`new ValueKey(this._items[i])`），
  /// 运行时随 props 序列化下发，宿主侧还原成真实 Flutter Key（key_bridge）。
  /// key 是**附加**信息：翻译不出来只丢 key（并出声），不拖垮整个结点。
  void _applyKeyProp(Map<String, dynamic> json, ElementNode node) {
    final keyExpr = node.namedArgs['key'];
    if (keyExpr == null) return;
    final String js;
    try {
      js = jsDataExpr(keyExpr);
    } catch (err) {
      _warnDegrade(sourcePath, 'key', keyExpr.toSource(), err, node: keyExpr);
      return;
    }
    final props = json['props'];
    if (props is Map) {
      props['key'] = js;
    } else {
      json['props'] = <String, dynamic>{'key': js};
    }
    // 结点上另记一份 `json['key']`：**组件的**渲染路径（`new X(props)`）
    // 取的是 `json['key']`（见 _renderJsImpl），只写 props['key'] 会让挂在
    // 组件结点上的 key 静默丢失（宿主结点读 props['key']，故宿主不受影响）。
    // 两处值同源，读哪一份都一样。
    json['key'] = js;
  }

  /// children 列表项翻译：Expression → 节点 Map；IfElement / ForElement →
  /// JS spread 表达式字符串（`...(cond ? [a] : [b])` / `...(function(){...})()`），
  /// 渲染层对 String 原样嵌入（内联构造调用 + 条件/循环展开）。
  Object? translateElement(CollectionElement e) {
    try {
      if (e is Expression) return translate(e);
      if (e is IfElement) return '...${_ifAsArray(e)}';
      if (e is ForElement) return '...${_forAsArray(e)}';
      // `...<list>` 展开（`...[Positioned.fill(...), Positioned(...)]`）：把内层
      // 元素数组原样展开进 children（`...[a, b]` ≡ `a, b`）。
      // 注意传 [e] 而不是 `e.expression`：_collectionArrayJs 对 SpreadElement
      // 负责产出「被展开的数组表达式」，否则 `...items` 会被写成 `...[items]`
      // （多包一层数组，children 被运行时判为非元素列表，整列变空）。
      if (e is SpreadElement) return '...${_collectionArrayJs(e)}';
      throw FormatException('不支持的 collection element: ${e.toSource()}');
    } catch (err) {
      // 单个集合元素（如 `...[...]` spread）无法翻译：告警丢弃该元素，
      // 兄弟元素照常翻译（不伪造元素）。
      _warnDegrade(sourcePath, '集合元素', e.toSource(), err, node: e);
      return null;
    }
  }

  /// if/for 作为「元素数组」出现（数组字面量里嵌套、三目分支等），
  /// 不带 spread 前缀：`(cond ? [a] : [b])`。
  String _ifAsArray(IfElement e) {
    final cond = jsDataExpr(e.expression);
    final thenJs = _collectionArrayJs(e.thenElement);
    final elseJs = e.elseElement == null
        ? '[]'
        : _collectionArrayJs(e.elseElement!);
    return '($cond ? $thenJs : $elseJs)';
  }

  /// for 循环 → JS IIFE 展开数组（循环变量 var 提升在 IIFE 内，body 直接引用）。
  String _forAsArray(ForElement e) {
    final parts = e.forLoopParts;
    // 本循环推入的循环变量：渲染结束（含失败）后精确移除，避免异常路径
    // 把作用域泄漏给兄弟结点（放大器缺陷修复的一部分）。
    final pushed = <String>[];
    String head;
    try {
      if (parts is ForPartsWithDeclarations) {
        // 传统 for：`for (var i = 0; i < n; i++)` → JS 同构
        final vars = parts.variables.variables.toList();
        // 循环变量先入作用域：condition/updaters/body 里引用 i 都走 loopVars
        for (final v in vars) {
          pushLoopVar(v.name.lexeme);
          pushed.add(v.name.lexeme);
        }
        final varList = vars.isEmpty
            ? ''
            : 'let ${vars.map((v) => '${v.name.lexeme} = ${v.initializer == null ? '0' : jsDataExpr(v.initializer!)}').join(', ')}';
        final condJs = parts.condition == null
            ? ''
            : jsDataExpr(parts.condition!);
        final incJs = parts.updaters.isEmpty
            ? ''
            : parts.updaters.map((u) => jsDataExpr(u)).join(', ');
        head = 'for ($varList; $condJs; $incJs)';
      } else if (parts is ForPartsWithExpression) {
        // 无声明：`for (i = 0; i < n; i++)`（变量需为已收集的状态字段）
        final initJs = parts.initialization == null
            ? ''
            : jsDataExpr(parts.initialization!);
        final condJs = parts.condition == null
            ? ''
            : jsDataExpr(parts.condition!);
        final incJs = parts.updaters.isEmpty
            ? ''
            : parts.updaters.map((u) => jsDataExpr(u)).join(', ');
        head = 'for ($initJs; $condJs; $incJs)';
      } else if (parts is ForEachPartsWithDeclaration) {
        // for-in（带声明）：`for (final s in kOrderStatus)` → `for (let s of <iter>)`。
        // 用 `let` 而非 `var`：每次迭代一个独立绑定，迭代内产出的闭包才能
        // 捕获到**本次**的值（`var` 会让所有迭代共享末值）。
        final name = parts.loopVariable.name.lexeme;
        pushLoopVar(name);
        pushed.add(name);
        head = 'for (let $name of ${jsDataExpr(parts.iterable)})';
      } else if (parts is ForEachPartsWithIdentifier) {
        // for-in（无声明）：`for (s in kOrderStatus)`（变量为已收集的状态字段/局部量）
        final name = parts.identifier.name;
        head = 'for ($name of ${jsDataExpr(parts.iterable)})';
      } else {
        throw FormatException('不支持的 for 循环形式: ${e.toSource()}');
      }
      final bodyJs = _collectionArrayJs(e.body);
      // 必须用**箭头函数** IIFE：body 里常引用状态字段（`this.banners`），
      // 普通 function 立即调用时 this 丢失（严格模式下为 undefined）。
      return '(() => { var out = []; $head { out.push.apply(out, $bodyJs); } return out; })()';
    } finally {
      // 清除本循环的循环变量作用域（渲染完成后，body 内已引用 i）
      for (final n in pushed) {
        _loopVars.remove(n);
      }
    }
  }

  /// collection element → JS 数组字面量（元素数组语义；嵌套 if/for 递归展开）。
  ///
  /// 翻译/渲染失败的元素**不进入数组**（返回不带该项的数组）：绝不塞占位元素。
  String _collectionArrayJs(CollectionElement e) {
    if (e is Expression) {
      final t = translate(e);
      if (t == null) return '[]';
      if (t is String) return '[$t]';
      final r = renderJs(t, 2);
      return r == null ? '[]' : '[$r]';
    }
    if (e is IfElement) return _ifAsArray(e);
    if (e is ForElement) return _forAsArray(e);
    // `...<list>` / `...<field>`：展开内层元素。
    //   - 内层是**列表字面量**（widget 列表）：逐元素走 [translateElement]
    //     渲染成元素数组（`...[Positioned(...), Positioned(...)]`）。
    //   - 其余（运行时数组字段 / 局部变量 / 方法返回）：数组表达式本身就是被
    //     展开的内容，直接返回，不再包一层。
    if (e is SpreadElement) {
      final inner = e.expression;
      if (inner is ListLiteral) {
        final items = <String>[];
        for (final el in inner.elements) {
          final js = _elementJs(el);
          if (js != null) items.add(js);
        }
        return '[${items.join(', ')}]';
      }
      // 运行时数组（字段 / 局部变量 / 方法返回）：数组本身就是被展开的内容，
      // 不能再包一层 `[...x]`，否则调用方再拼 `...` 会变成 `...[x]`。
      final t = translate(inner);
      if (t == null) return '[]';
      if (t is String) return t;
      return renderJs(t, 2) ?? '[]';
    }
    throw FormatException('不支持的 collection element: ${e.toSource()}');
  }

  /// 单个 collection element → JS 数组项源码：String（已是 JS 表达式，含
  /// `...spread` / IIFE / 三目）原样内联，节点 Map 走 [renderJs]。
  /// 返回 null = 该项翻译失败，调用方丢弃它（不伪造元素）。
  String? _elementJs(CollectionElement e) {
    final t = translateElement(e);
    if (t == null) return null;
    if (t is String) return t;
    return renderJs(t, 2);
  }

  /// 单个 widget 表达式 → JS 源码（**单元素**语义）：节点 Map 走 [renderJs]，
  /// 已是 JS 表达式（三目 / 字段引用 / 方法调用）原样内联。
  ///
  /// 与 [_elementJs] 的分工：后者输入是「集合元素」（数组语义，可带 spread），
  /// 本方法输入是「元素本身」（如 `child: cond ? A : B` 的单支、单子组件的
  /// 实参）——绝不能产出数组字面量，否则会变成 props.child 里的嵌套数组。
  /// 返回 null = 翻译失败（调用方按「没有元素」处理）。
  String? _elementExprJs(Expression e) {
    final t = translate(e);
    if (t == null) return null;
    if (t is String) return t;
    return renderJs(t, 2);
  }

  /// 循环变量作用域：for 循环变量（i 等）在 body 翻译期间遮蔽状态字段查表。
  /// 入/出成对：[_forAsArray] 用 `finally` 精确移除本次循环推入的变量。
  final Set<String> _loopVars = {};
  void pushLoopVar(String name) => _loopVars.add(name);

  /// build() return 前的局部变量（`final isAdult = ...;`）：树里直接引用。
  final Set<String> _locals = {};

  /// 方法体局部的**源码类型**：widget 层按接收者类型做成员映射时要用。
  final Map<String, String> _localTypes = {};
  void addLocal(String name) => _locals.add(name);

  /// **方法体局部变量**（来自 [registerLocal]，即各方法体里 `var/final x = ...`）。
  ///
  /// 它们只在**本方法**内可见：懒加载 builder 被抽成实例方法
  /// （`_listViewBuilderN` / `_sliverBuilderN`）后看不到这些名字——只有被折算成
  /// 字段引用（[registerLocalAlias]）才安全，否则产物里就是未定义自由变量。
  final Set<String> _methodBodyLocals = {};

  /// 抽取出的 builder 方法里**真实可见**的名字（闭包形参 context/index +
  /// 块体前置语句声明的局部，见 [addBuilderLocal]）。判「捕获了方法体局部变量」
  /// 时用来排除。
  final Set<String> _extractedVisible = {};

  /// 懒加载 builder 自己的名字：闭包形参（context / index）与块体前置语句声明的
  /// 局部——它们会成为抽取方法的前置语句，方法体里天然可见。
  void addBuilderLocal(String name) {
    _locals.add(name);
    _extractedVisible.add(name);
  }

  /// [ExprRenderer.registerLocal] 实现：方法体翻译器声明局部变量时
  /// 同步登记，保证同一方法体里返回的 widget 树能解析这些名字。
  ///
  /// 同时记为「方法体局部变量」：被抽走的 builder 子树里引用了它就必须告警
  /// （见 [warnCapturedLocals]）。
  @override
  void registerLocal(String name, {String? type}) {
    _locals.add(name);
    _methodBodyLocals.add(name);
    if (type != null) _localTypes[name] = type;
  }

  /// 抽查懒加载 builder 闭包捕获的名字（构建期告警，不静默）。
  ///
  /// 会被抽成独立实例方法的子树里，只有**闭包形参与前置语句局部**、类成员
  /// （字段 / getter / 方法）、顶层常量可见；`build` 的方法体局部变量与循环变量
  /// 都不在其中——折算不出字段引用时产物就是未定义自由变量，运行时
  /// `ReferenceError`（子结点展开失败 → 页面停在 loading，且错误被求值层吞掉，
  /// 现场几乎无法定位）。
  ///
  /// 正常路径（`final spots = _feed.spots;` 这类字段派生的 final 局部）会先被
  /// [registerLocalAlias] 折算成 `this._feed.spots`，不会命中本告警。
  void warnCapturedLocals(Expression body) {
    final used = <String, SimpleIdentifier>{};
    body.accept(_SimpleIdentifierCollector(used));
    for (final e in used.entries) {
      final name = e.key;
      if (!_methodBodyLocals.contains(name) && !_loopVars.contains(name)) {
        continue;
      }
      if (_extractedVisible.contains(name) ||
          _localAliases.containsKey(name) ||
          propByField.containsKey(name) ||
          methodNames.contains(name) ||
          getterNames.contains(name) ||
          staticFieldNames.contains(name) ||
          staticMethodNames.contains(name) ||
          globalConsts.contains(name)) {
        continue;
      }
      log.warning(
        '[hot_patch_generator] ${sourceAt(sourcePath, e.value)}: "$name" 被懒加载 builder '
        '捕获，却折算不成字段引用（字段 / getter / 顶层常量）：抽取成实例方法'
        '后 JS 侧是未定义自由变量（运行时 ReferenceError，页面会停在 loading）。'
        '请把该值放到字段 / getter 上，或改用「字段派生的 final 局部」'
        '（如 `final spots = _feed.spots;`）。',
      );
    }
  }

  /// 局部别名（`final list = _list;` → `list → this._list`）。被抽成实例方法的
  /// 懒加载 builder 引用该名字时，必须落成真实字段引用（见 [jsDataExpr]）。
  final Map<String, String> _localAliases = {};
  @override
  void registerLocalAlias(String name, String jsExpr) =>
      _localAliases[name] = jsExpr;

  /// 当前正在翻译的方法形参（`withMethodParams` 期间有效）。
  final Set<String> _methodParams = {};

  /// [ExprRenderer.withMethodParams] 实现：翻译某方法体期间把形参登记进
  /// widget 层作用域，结束后恢复（连同本方法产生的局部别名一起回收，避免跨方法串味）。
  @override
  T withMethodParams<T>(Iterable<String> params, T Function() body) {
    final added = <String>[];
    for (final p in params) {
      if (_methodParams.add(p)) added.add(p);
    }
    final aliasesBackup = Map<String, String>.from(_localAliases);
    try {
      return body();
    } finally {
      for (final p in added) {
        _methodParams.remove(p);
      }
      _localAliases
        ..clear()
        ..addAll(aliasesBackup);
    }
  }

  /// 渲染一个已翻译的中立节点为统一类构造 `new Type(props)`（命名构造 `X.b(...)`）。
  ///
  /// 值契约：toJson 的叶子值一律是 JS 表达式字符串（`"Text"` 这类字符串
  /// 字面量由 [jsString] 产生），因此分发前剥离字符串字面量的引号取语义名。
  ///
  /// 渲染失败 → 告警并返回 null（调用方丢弃该结点），不伪造元素。
  @override
  String? renderJs(Object? json, int depth) {
    try {
      return _renderJsImpl(json, depth);
    } catch (err) {
      _warnDegrade(sourcePath, '结点', json, err);
      return null;
    }
  }

  @override
  String renderValue(Object? json, int depth) =>
      renderValueOrNull(json, depth) ?? 'null';

  /// 值渲染的可失败版本：翻译/渲不出来的值返回 null，由调用方丢弃该值
  /// （props 里就是「没有这个值」），不伪造任何对象。
  @override
  String? renderValueOrNull(Object? json, int depth) {
    try {
      return _renderValueImpl(json, depth);
    } catch (err) {
      _warnDegrade(sourcePath, '值', json, err);
      return null;
    }
  }

  /// 值渲染：无条件产出 **构造调用**（`new X({...})` / `X.b({...})`）。
  ///
  /// 与 [renderJs] 的唯一区别是不切「字符串结点」形态——那个形态是宿主
  /// widget 的兼容写法，属于结点语境；值语境里同名类总是存在的（注入类或
  /// 包装类），因此不需要兜底。组件使用方一律 `new X(...)`，不经过额外构造层。
  String _renderValueImpl(Object? json, int depth) {
    if (json is String) return json;
    if (json is! Map<String, dynamic>) throw FormatException('无法渲染的值: $json');
    final token = _typeToken(json['type'], node: nodeSourceOf(json));
    final name = bareTypeName(token);
    _assertTranslatable(name);
    // 值语境一律按类调用（`new X(...)`）：JS 侧没有这个类就是未定义全局。
    // 若类来自某个 pub 依赖包而宿主 `js/` 没提供该包模块，构建期直接报错。
    if (jsClassFileOf(name) == null) {
      _reportMissingHostJs(name, nodeSourceOf(json));
    }
    _registerWidgetImport(token, name);
    // 值语境一律按类调用：命名构造走包装类上的同名静态方法。
    return _renderCall(token, json, depth, asClass: true);
  }

  String _renderJsImpl(Object? json, int depth) {
    if (json is String) return json; // 三目/条件表达式（JS 源码字符串）
    if (json is! Map<String, dynamic>) {
      throw FormatException('无法渲染的节点: $json');
    }
    final token = _typeToken(json['type'], node: nodeSourceOf(json));
    final name = bareTypeName(token);
    // 元素 type 一律是**类引用**（组件使用方统一 `new X(...)`）：
    //   - 该类型有 JS 产物（importResolver 命中：@PatchEntry 嵌套组件、同文件
    //     私有组件）→ `new X(props)`；实例随元素一起下发，mount 直接复用；
    //   - 该类型在 JS 侧有类（逻辑组件 / builder 代理，含普通构造形态——代理类
    //     构造里自行判定没有 builder 时直接产出宿主结点）→ `new X(props)`；
    //   - 宿主 widget / 值对象：flutter.js 生成了同名包装类 → `new X(props)`；
    //   - `@PatchIgnore(isComponent: true)`：声明它的源文件产物里的同名包装类
    //     → `new X(props)`（与其它有产物的类同一条路径）。
    _assertTranslatable(name);
    // 判据只看「JS 侧有没有这个类」：有类就有同名静态方法（命名构造由
    // `X.b({...})` 一比一发射，静态方法负责把构造名写进 `props.factory`）。
    // 带前缀（`p.Foo`）的引用一定指向模块导出，按类处理。
    final classFile = jsClassFileOf(name);
    final asClass = token != name || classFile != null;
    // JS 侧既没有这个类、宿主也没有同名 widget 渲染器时，元素 type 只能退化成
    // 字符串 —— 宿主注册表查不到必然失败。若类来自某个 pub 依赖包而宿主 `js/`
    // 没提供该包模块（`js/<package>.js`），构建期直接报错（每个类型一次）。
    if (classFile == null) _reportMissingHostJs(name, nodeSourceOf(json));
    _registerWidgetImport(token, name);
    return _renderCall(token, json, depth, asClass: asClass);
  }

  /// 类型在 JS 侧没有类、且缺失的是宿主三方 JS 模块时报错（每类型一次）。
  ///
  /// 判据见 [missingHostJsPackageOf]（类声明所在包 + 宿主 `js/` 是否提供模块），
  /// 不涉及任何库名 / 类型名白名单。
  ///
  /// 用 `severe` 而不是 `warning`：产物里这个类型**没有类**，运行时必然失败
  /// （未注册类型 / 未定义全局），属于「影响运行」而不是「有风险但能跑」。
  void _reportMissingHostJs(String type, AstNode? node) {
    final pkg = missingHostJsPackageOf(type);
    if (pkg == null || !_missingHostJsReported.add(type)) return;
    log.severe(
      '[hot_patch_generator] ${sourceAt(sourcePath, node)}: 类型 "$type" 声明在 package:$pkg，'
      '但宿主 js/ 目录没有 $pkg.js（应在工程根 js/$pkg.js 提供该包 JS，'
      '构建时原样拷贝为 patch/packages/$pkg.js）。该类型在 JS 侧没有类，'
      '产物运行时会失败。',
    );
  }

  /// 已报错过的「三方包缺 JS 模块」类型（每类型一次，避免逐处刷屏）。
  final Set<String> _missingHostJsReported = {};

  /// 按「类的定义在哪个文件」登记 import（漏登记 = 产物里
  /// 「Can't find variable: X」）。
  ///
  ///   - 项目内类（有产物文件，含同文件）：由类依赖表负责 import，这里跳过；
  ///   - 类定义在 package 模块（宿主包装类 / 数据载体 / builder 代理 / 逻辑
  ///     组件）→ 按该类的 package 归属登记；
  ///   - 类定义由运行时统一注入（`TextSpan` / `Duration` 等全局同名类）→ 无
  ///     文件可 import，产物里直接 `new X(...)`。
  void _registerWidgetImport(String token, String name) {
    // 带 import 前缀（`p.Foo`）：类由模块命名空间提供，`_typeToken` 已登记
    // `import * as p from '<产物>'`，不能再按名字补一条命名 import。
    if (token != name) return;
    if (importResolver?.call(name) != null) return;
    if (jsClassFileOf(name) == null) return;
    (usedWidgetPackages[widgetPackageOf(name)] ??= <String>{}).add(name);
  }

  /// 结点 `type` 字面量 → JS 类型引用 token。
  ///
  /// 带 import 前缀（`p.Foo`）时：解析到该前缀的 JS 模块产物就保留前缀并登记
  /// 命名空间 import（Dart 用前缀消解同名类，JS 用模块命名空间做同一件事）；
  /// 解析不到（`dart:` 导入 / 没有 JS 模块的包）则退回裸类名并告警——产物里
  /// 绝不能留一个指向未定义命名空间的引用。
  String _typeToken(Object? v, {AstNode? node}) {
    final token = _semanticType(v);
    final dot = token.indexOf('.');
    if (dot <= 0) return token;
    final prefix = token.substring(0, dot);
    final name = token.substring(dot + 1);
    final product = prefixProducts[prefix];
    // 已知「无 JS 模块但按裸名成立」（`dart:` 导入的镜像类型）→ 静默退回裸名。
    if (product != null && product.isEmpty) return name;
    if (product == null) {
      if (_prefixFallbackWarned.add(prefix)) {
        log.warning(
          '[hot_patch_generator] ${sourceAt(sourcePath, node)}: import 前缀 "$prefix" 在 JS 侧'
          '没有可加载的模块（`$prefix.$name`），已按裸类名 "$name" 翻译；'
          '若两者不同名会引用到错误的类。',
        );
      }
      return name;
    }
    namespaceImports[prefix] = product;
    return token;
  }

  /// 已告警过的「前缀无 JS 模块」组合（每个前缀只告警一次，避免逐处刷屏）。
  final Set<String> _prefixFallbackWarned = {};

  /// 类型 token 的裸类名（`p.Foo` → `Foo`；无前缀原样返回）。
  ///
  /// 名字用于**判定**（类表 / 宿主类型 / 包归属 / 构造签名）；`p.Foo` 这种
  /// 引用形态只用于**渲染**。两者分开，判据不依赖前缀。
  static String bareTypeName(String token) {
    final dot = token.indexOf('.');
    return dot <= 0 ? token : token.substring(dot + 1);
  }

  /// `@PatchIgnore()`（`isComponent` 非 true）的类整类不翻译：引用它的结点没有
  /// JS 类可用，直接抛错交给降级路径（丢该结点并告警），不产出半截代码。
  void _assertTranslatable(String type) {
    if (ignoredTypes.contains(type)) {
      throw FormatException('@PatchIgnore 类 $type 未翻译（isComponent != true）');
    }
  }

  /// 结点级的 `key` 并入元素 props：Key 是**元素级参数**（见
  /// [ElementTranslateContext._applyKeyProp]），渲染时统一落在 `props.key` 上
  /// ——运行时 `keyOf` / 宿主 key 桥读的就是它。无 key 时 props 原样复制。
  static Map<String, dynamic> _propsWithKey(Object? props, Object? key) {
    final out = <String, dynamic>{};
    if (props is Map) {
      for (final e in props.entries) {
        out['${e.key}'] = e.value;
      }
    }
    if (key != null) out['key'] = key;
    return out;
  }

  /// const 值的规范化：Map 按键名排序（值递归），List 保持原序（子元素顺序有语义）。
  /// 只用于生成期，输出仍是等价的对象字面量，只是键序确定。
  static Object? _constCanonical(Object? v) {
    if (v is Map) {
      final keys = v.keys.map((k) => '$k').toList()..sort();
      final out = <String, dynamic>{};
      for (final k in keys) {
        out[k] = _constCanonical(v[k]);
      }
      return out;
    }
    if (v is List) {
      return v.map(_constCanonical).toList();
    }
    return v;
  }

  /// 把已翻译的 JSON 节点渲染成构造表达式 `new X({...})`（命名构造为
  /// `X.factory({...})`）。组件使用方一律 Dart 一比一构造，不经过额外构造层。
  ///
  /// 所有 Dart 实参都按原名进 props——`child` / `children` / `slivers` / `tabs`
  /// 也在 props 里，由宿主包装类在**构造期**经 `Component.__splitHost` 按值形态
  /// 拆分：元素值 / 元素数组 / `__builder` / delegate 进 `__children`，其余留 props；
  /// JS 组件类保留全部 props 供 `__applyProps`。因此这里不传第三参，也不区分单子/多子。
  String _renderCall(
    String type,
    Map<String, dynamic> json,
    int depth, {
    required bool asClass,
  }) {
    final props = _propsWithKey(json['props'], json['key']);
    // 命名构造 → 1:1 的 JS 静态方法：`ListView.separated({...})` / `SizedBox.shrink({...})`。
    // 构造名是**翻译期事实**（结点顶层 `ctor`），不进 props、不跨语言；语义由
    // JS 类上的同名静态方法承接（见 flutter.js 的包装类静态方法）。
    final ctor = json[ctorNodeKey];
    final ctorName = ctor is String && ctor.isNotEmpty ? ctor : null;
    if (asClass && ctorName != null) {
      final propsJs = props.isNotEmpty ? jsLiteral(props, depth + 1) : '{}';
      return _constCached(json, '$type.$ctorName($propsJs)');
    }
    final propsJs = props.isNotEmpty ? jsLiteral(props, depth + 1) : '{}';
    return _constCached(json, 'new $type($propsJs)');
  }

  /// const 构造的站点级懒缓存：同一处 `const X(...)` 每次 build 复用同一实例，
  /// 与 Dart 的 const 规范化一致（运行时再按实例缓存元素，见 `asElement`）。
  ///
  /// 缓存挂在**组件实例自身**（`this.__k<编号>`），不是模块全局：
  ///   - 生命周期与组件实例一致——页面退出 / 组件卸载后随实例一起被 GC，
  ///     无需手动释放，也不会像模块级缓存那样活到热更；
  ///   - 同一实例内的多次 build 仍拿到同一对象，父级重建可短路；
  ///   - 字段名按类内编号分配，不稳定编码进 key，产物更干净。
  ///
  /// JS 的 `const` 关键字解决不了这个问题：它只是「绑定不可重新赋值」，函数体
  /// 每次执行都会重新求出新对象，JS 没有 Dart 那样的 const 规范化。
  String _constCached(Map<String, dynamic> json, String call) {
    if (json['__constSite'] != true) { return call; }
    final id = constKeys.idFor(_stripNew(_compactJsExpr(call)));
    return '(this.__k$id || (this.__k$id = $call))';
  }

  /// 去掉 key 里的 `new` 关键字（含嵌套层）：`new Center({...new X()})` →
  /// `Center({...X()})`。同一 const 值靠「类型 + 实参」已能唯一区分，`new` 只是噪音。
  /// 按字符串/模板字面量边界扫描，不改动任何字面量内部内容。
  static String _stripNew(String s) {
    final out = StringBuffer();
    var quote = '';
    var i = 0;
    while (i < s.length) {
      final ch = s[i];
      if (quote.isNotEmpty) {
        out.write(ch);
        if (ch == r'\' && i + 1 < s.length) {
          out.write(s[i + 1]);
          i += 2;
          continue;
        }
        if (ch == quote) { quote = ''; }
        i += 1;
        continue;
      }
      if (ch == '"' || ch == "'" || ch == '`') {
        quote = ch;
        out.write(ch);
        i += 1;
        continue;
      }
      final isWordStart = i == 0 || !_identChar(s[i - 1]);
      if (isWordStart &&
          s.startsWith('new ', i) &&
          i + 4 < s.length &&
          _identChar(s[i + 4]) &&
          s[i + 4] != r'$') {
        i += 4;
        continue;
      }
      out.write(ch);
      i += 1;
    }
    return out.toString();
  }

  /// 压掉 JS 表达式里的换行与多余空格，只保留标识符之间必需的单个空格。
  /// 字符串 / 模板字面量内部原样保留（不改变任何字面量内容）。
  static String _compactJsExpr(String s) {
    final out = StringBuffer();
    var quote = '';
    var pendingSpace = false;
    var last = '';
    void emit(String c) {
      out.write(c);
      last = c;
    }

    for (var i = 0; i < s.length; i++) {
      final ch = s[i];
      if (quote.isNotEmpty) {
        emit(ch);
        if (ch == r'\' && i + 1 < s.length) {
          emit(s[i + 1]);
          i += 1;
        } else if (ch == quote) {
          quote = '';
        }
        continue;
      }
      if (ch == '"' || ch == "'" || ch == '`') {
        if (pendingSpace && _identChar(last) && _identChar(ch)) { emit(' '); }
        pendingSpace = false;
        quote = ch;
        emit(ch);
        continue;
      }
      if (ch == ' ' || ch == '\n' || ch == '\r' || ch == '\t') {
        pendingSpace = true;
        continue;
      }
      if (pendingSpace && _identChar(last) && _identChar(ch)) { emit(' '); }
      pendingSpace = false;
      emit(ch);
    }
    return out.toString();
  }

  /// 只有「两侧都是标识符字符」时才需要一个空格（如 `new` 与 `Text`），
  /// 其余标点相邻一律贴合，避免产物里出现 `[ `、`, ` 这类噪音。
  static bool _identChar(String c) {
    if (c.isEmpty) { return false; }
    final u = c.codeUnitAt(0);
    return (u >= 0x30 && u <= 0x39) ||
        (u >= 0x41 && u <= 0x5A) ||
        (u >= 0x61 && u <= 0x7A) ||
        c == '_' || c == r'$';
  }

  /// 剥离 JS 字符串字面量引号（`"Column"` → `Column`）；非字面量原样返回。
  static String _semanticType(Object? v) {
    final s = v?.toString() ?? '';
    if (s.length >= 2 && s.startsWith('"') && s.endsWith('"')) {
      return s.substring(1, s.length - 1);
    }
    return s;
  }

  // -------------------------------------------------------------------------
  // 通用 AST 解析 helper（translator 可直接复用）
  // -------------------------------------------------------------------------

  /// 取构造调用：`Foo(...)` 在无 resolution 的 parseString 下可能是
  /// InstanceCreationExpression 或 MethodInvocation（无 const 时），统一处理。
  ///
  /// 静态工厂形态（`Image.asset(...)` / `Image.network(...)`）把 ctor 名
  /// 归一为 target 名（'Image'），与注册表 {Image: ImageTranslator} 匹配。
  (String?, List<Expression>) ctorOf(Expression e) {
    if (e is InstanceCreationExpression) {
      // 带 `const` 的命名构造（`const EdgeInsets.all(8)`）在 AST 里把
      // `EdgeInsets.all` **整体**放进 `constructorName.type`，`name2` 只取最后
      // 一段（'all'）。这里取**类型引用**：先剥泛型再按 `.` 切段，保留 import
      // 前缀（`material.Padding` / `p.ChangeNotifierProvider.value`）。
      return (
        _typeRefOf(e.constructorName.type.toSource()),
        e.argumentList.arguments.toList(),
      );
    }
    if (e is MethodInvocation) {
      final target = e.target;
      if (target is PrefixedIdentifier) {
        // `p.Foo(...)` / `p.Foo.value(...)`：用源码文本还原带前缀的类型引用
        // （`PrefixedIdentifier.name` 只给出前缀，不能拿来当类型名）。
        return (
          _typeRefOf(target.toSource()),
          e.argumentList.arguments.toList(),
        );
      }
      if (target is SimpleIdentifier) {
        // `p.Foo(...)`：解析成「target = import 前缀、方法名 = 类型名」，
        // 类型引用 token 要还原成 `p.Foo`；其余 `Image.network(...)` 保持原规则。
        if (isImportPrefix(target.name)) {
          return (
            '${target.name}.${e.methodName.name}',
            e.argumentList.arguments.toList(),
          );
        }
        return (target.name, e.argumentList.arguments.toList());
      }
      return (e.methodName.name, e.argumentList.arguments.toList());
    }
    return (null, const []);
  }

  /// 构造名源码 → **类型引用 token**。
  ///
  ///   - `EdgeInsets.all` → `EdgeInsets`（最后一段是构造名，类型是前一段）；
  ///   - `p.ChangeNotifierProvider<T>.value` → `p.ChangeNotifierProvider`
  ///     （import 前缀原样保留：它是 JS 侧的模块命名空间，删掉会把两个库的
  ///     同名类合成同一个引用）；
  ///   - `Padding` → `Padding`。
  ///
  /// **先剥类型实参再按 `.` 切段**：`p.ChangeNotifierProvider<vm.CounterVm>.value`
  /// 里的泛型实参自身带 `.`（`vm.CounterVm`），先切段会把泛型文本当成类名。
  static String _typeRefOf(String ctorSource) {
    final src = _cutGenerics(ctorSource);
    final parts = [
      for (final seg in src.split('.'))
        if (seg.trim().isNotEmpty) seg.trim(),
    ];
    if (parts.isEmpty) return src.trim();
    final last = parts.last;
    final typeIndex = isClassName(last) ? parts.length - 1 : parts.length - 2;
    if (typeIndex < 0) return last;
    final typeName = parts[typeIndex];
    // 类型前一段是小写标识符 → import 前缀（`p.Foo` / `material.Padding`）。
    final prefixIndex = typeIndex - 1;
    if (prefixIndex >= 0) {
      final prefix = parts[prefixIndex];
      if (RegExp(r'^[a-z_$][\w$]*$').hasMatch(prefix)) return '$prefix.$typeName';
    }
    return typeName;
  }

  /// 去掉源码里所有类型实参（`<...>`，按嵌套深度配对），保留其余文本。
  static String _cutGenerics(String s) {
    final out = StringBuffer();
    var depth = 0;
    for (var i = 0; i < s.length; i++) {
      final ch = s[i];
      if (ch == '<') {
        depth++;
        continue;
      }
      if (ch == '>' && depth > 0) {
        depth--;
        continue;
      }
      if (depth == 0) out.write(ch);
    }
    return out.toString();
  }

  /// 去掉类型实参：`ChangeNotifierProvider<NetworkVm>` → 'ChangeNotifierProvider'。
  static String _stripGenerics(String s) {
    final lt = s.indexOf('<');
    return lt >= 0 ? s.substring(0, lt) : s;
  }

  Expression? namedArg(List<Expression> args, String name) {
    for (final a in args) {
      if (a is NamedExpression && a.name.label.name == name) {
        return a.expression;
      }
    }
    return null;
  }

  Expression? positionalArg(List<Expression> args, int i) =>
      i < args.length ? args[i] : null;

  /// 第一个非命名参数（单子组件的 child 定位）：
  /// `Container(width: 120)` 无 child 时，跳过命名参数，返回 null。
  Expression? nonNamedArg(List<Expression> args) {
    for (final a in args) {
      if (a is! NamedExpression) return a;
    }
    return null;
  }

  /// 方法名 → 事件名
  String eventOf(String method) {
    final event = actionByMethod[method];
    if (event != null) return event;
    throw FormatException('"$method" 不是组件方法（未注册为动作）');
  }

  /// `widget.<name>`（State 里引用 widget 自身成员）→ 成员名 `<name>`。
  ///
  /// widget 与 State 在 JS 侧合并成同一个类，`widget.x` 就是 `this.x`。
  /// 注意 analyzer 里 [PrefixedIdentifier] 是 [Identifier] 的子类且 `name` 是
  /// 整串 `widget.x`：不先识别出来，就会拿整串名字去查字段/动作表而必然失败。
  /// 非 `widget.` 前缀（或非简单 `x.y`）返回 null。
  String? widgetMemberName(Expression? e) =>
      e is PrefixedIdentifier && e.prefix.name == 'widget'
      ? e.identifier.name
      : null;

  /// 事件参数解析：`onTap: _tap` / `onTap: () => _tap()` → 组件方法调用；
  /// 带 receiver 的调用（Builder 闭包局部变量 `model.inc()`、
  /// `context.read<T>().reset()` 链式）→ 翻译为 JS 方法调用表达式
  /// （一比一，不查动作表——方法/属性全量生成，无需标注）。
  ///
  /// [scope] 缺省为事件作用域 [_eventScope]；事件闭包的**形参**（`(v) => ...`
  /// 里的 `v`）由调用方经 [FieldScope.withParams] 并入后传入，保证实参里的
  /// 形参名原样落成 JS 标识符。
  String eventExpr(Expression e, [FieldScope? scope, bool asStatement = false]) {
    final activeScope = scope ?? _eventScope();
    if (e is Identifier) {
      // `widget.<name>`（State 里引用 widget 自身的字段/方法，如
      // `onReset: widget.onReset`）：合并类里就是实例成员，调它即可。
      final wm = widgetMemberName(e);
      if (wm != null) {
        final prop = propByField[wm];
        if (prop != null) return 'this.$prop()';
        if (methodNames.contains(wm)) return 'this.$wm()';
        return eventOf(wm);
      }
      // 字段型回调（`onTap: onTap` / `onTap: _onTap`）：字段里存的就是可调用值，
      // 事件触发即调它。字段本身由父组件经函数实参传入（见 [functionJs]）。
      final prop = propByField[e.name];
      if (prop != null) return 'this.$prop()';
      return eventOf(e.name);
    }
    // 事件闭包体里的**单条调用语句**（`() { AppRouter.x(); }`）：与箭头体
    // `() => AppRouter.x()` 共用同一套解析（[asStatement] 直接把调用本身当
    // 内部调用处理，不再要求外层包一层闭包）。
    final inner = asStatement
        ? e
        : (e is FunctionExpression ? functionInner(e) : null);
    if (inner is MethodInvocation) {
        // `setState(() {...})`：组件自身的状态更新，不是 @PatchEntry 声明的方法
        // （Dart 的 State.setState 由框架提供）。翻译成 `this.setState(<closure>)`，
        // 运行时基类已提供 setState（见 mini_react_js）。
        if (inner.target == null && inner.methodName.name == 'setState') {
          return _setStateCallJs(inner, activeScope);
        }
        final target = inner.target;
        // 局部变量 / 形参 receiver：保留名字，由 [_eventFnJs] 生成的**构建期
        // 箭头闭包**天然捕获它（与 Dart 闭包同语义）。
        //   - 局部（`final model = context.watch<T>()` → `model.inc()`）；
        //   - 形参（`Widget _box(String label, FocusNode node)` 里的
        //     `node.requestFocus()` / `label.trim()`）：裸标识符是**变量**，
        //     不是实例字段，绝不能补 `this.`——否则渲染期会读到不存在的字段。
        //     有别名（`final list = _list;`）的局部落成真实字段引用。
        if (target is Identifier &&
            (_locals.contains(target.name) ||
                activeScope.params.contains(target.name))) {
          final recv = activeScope.fieldRef(target.name) ?? target.name;
          return '$recv.${inner.methodName.name}'
              '(${_eventArgsJs(inner.argumentList, activeScope)})';
        }
        // context.read<T>().reset() 链式：先翻译 receiver（jsDataExpr →
        // this.context.read('T')），再拼方法调用。
        if (target is MethodInvocation) {
          final recv = jsDataExpr(target, activeScope);
          return '$recv.${inner.methodName.name}'
              '(${_eventArgsJs(inner.argumentList, activeScope)})';
        }
        // `widget.onPick(key, v)`（`() => widget.onPick(key, v)`）：调用 widget
        // 自身成员——合并类里就是实例方法/字段回调，落成 `this.onPick(key, v)`。
        // 不拦下来会走下面的「组件字段 receiver」分支产出 `this.widget.onPick(...)`
        // ——`widget` 在 JS 侧根本没有这个字段，点击直接抛错失效。
        if (target is Identifier && target.name == 'widget') {
          final wm = inner.methodName.name;
          final args = _eventArgsJs(inner.argumentList, activeScope);
          final prop = propByField[wm];
          if (prop != null) return 'this.$prop($args)';
          if (methodNames.contains(wm)) return 'this.$wm($args)';
          return eventOf(wm);
        }
        // 组件字段/实例 receiver（非局部变量即组件成员）：`_controller.clear()`
        // / `_scrollController.jumpTo(...)` → this._controller.clear()，
        // 不查动作表（实例方法全量生成，与 Dart 写法一致）。
        // 例外：receiver 是**项目类**（`AppRouter.pop()` / `Network.post(...)`）→
        // 静态调用原样写成 `类名.方法(...)`，与 Dart 一比一；这类类在 JS 侧有
        // 同名类定义（`modelClassNames` 来自类表），补 `this.` 会访问不存在的字段。
        if (target is Identifier && modelClassNames.contains(target.name)) {
          return '${target.name}.${inner.methodName.name}'
              '(${_eventArgsJs(inner.argumentList, activeScope)})';
        }
        // 三方包顶层值（`Get.find<T>()`）：JS 侧是该模块导出的同名符号，
        // 原样 `Get.find(...)`；不能补 `this.`（实例上没有这个字段）。
        // 泛型参数名不是值符号，先排除。
        if (target is Identifier && !activeScope.typeParams.containsKey(target.name)) {
          final symbol = _thirdPartyValueRefJs(target.name);
          if (symbol != null) {
            return '$symbol.${inner.methodName.name}'
                '(${_eventArgsJs(inner.argumentList, activeScope)})';
          }
        }
        if (target is Identifier) {
          return 'this.${target.name}.${inner.methodName.name}'
              '(${_eventArgsJs(inner.argumentList, activeScope)})';
        }
        // 无 receiver 的裸调用 `_openMenu(context, i)` / `_go(text)`：本组件实例
        // 方法 → `this.<name>(<args>)`。必须保留「调用 + 实参」形态：只回方法名会
        // 让闭包体变成 `() => { _openMenu; }`（引用而非调用，点击无任何反应）。
        final method = inner.methodName.name;
        // 顶层 `@HostInjected` 函数（无 receiver，如 `toast('x')`）→ 宿主通道。
        final topHost = _hostFunctionCallJs(
          method,
          inner.argumentList,
          activeScope,
        );
        if (topHost != null) return topHost;
        // static 方法（`fromJson(e)` 这类在类内方法体里的裸调用）→ `<类名>.m(...)`，
        // 与实例方法同一名字空间，调用点看不出差别，靠静态方法表区分。
        if (staticMethodNames.contains(method) && className != null) {
          return '$className.$method'
              '(${_eventArgsJs(inner.argumentList, activeScope)})';
        }
        if (actionByMethod.containsKey(method) ||
            methodNames.contains(method)) {
          return 'this.$method(${_eventArgsJs(inner.argumentList, activeScope)})';
        }
        // 字段型回调用法（`() => onPick(key, v)` / `_FilterPanel` 里的分组循环）：
        // 字段存的是父组件传进来的函数，调它即 `this.<prop>(<args>)`。
        final prop = propByField[method];
        if (prop != null) {
          return 'this.$prop(${_eventArgsJs(inner.argumentList, activeScope)})';
        }
        return eventOf(method);
    }
    throw FormatException('事件参数需要直接引用方法（如 onTap: _tap 或 () => _tap()）');
  }

  /// 事件表达式 → JS 箭头函数源码（参数按 Dart 闭包签名逐字对应）。
  String _eventFnJs(Expression e) {
    if (e is FunctionExpression) {
      final params = _closureParamNames(e);
      final base = _eventScope();
      final scope = params.isEmpty ? base : base.withParams(params);
      final pjs = params.join(', ');
      final body = e.body;
      if (body is ExpressionFunctionBody) {
        // 表达式体在 Dart 里就是事件调用本身：箭头体直接返回，保留返回值
        // （可等待事件 EasyRefresh.onRefresh 靠它拿到 JS 侧 Promise）。
        try {
          return '($pjs) => ${eventExpr(e, scope)}';
        } catch (_) {
          // 非调用形态（赋值 / 自增等）退回语句翻译。
          final stmt = closureBodyStmtJs(body.expression, scope, const {});
          if (stmt == null) rethrow;
          return '($pjs) => { $stmt }';
        }
      }
      if (body is BlockFunctionBody) {
        // 空块体（`onPressed: () {}`）是**合法的空操作事件**：原样产出
        // `() => {}`，不当作翻译失败（否则会误报「事件闭包块体为空」）。
        if (body.block.statements.isEmpty) return '($pjs) => {}';
        // 表达式语句走**事件表达式**翻译（与箭头体同一管线）：事件作用域带
        // 构建期类表（`modelClassNames` / `@HostInjected` 静态方法），能解析
        // `AppRouter.openLogin()` 这类项目类静态调用；通用语句翻译的 `classes`
        // 是空表，会把它们判成「接收者不可解析」而丢弃（同一调用放箭头体却
        // 正常，表现为「写法一改就不生效」）。
        final parts = <String>[];
        for (final st in body.block.statements) {
          String? line;
          if (st is ExpressionStatement) {
            try {
              line = '${eventExpr(st.expression, scope, true)};';
            } catch (_) {
              // 事件管线不认的形态（如纯赋值）：落到下面的通用语句翻译。
              line = null;
            }
          }
          if (line == null) {
            final js = translateStmtList([st], scope, const {}, null);
            if (js.trim().isEmpty) {
              throw FormatException('事件闭包语句无法翻译：${st.toSource()}');
            }
            line = js.trim();
          }
          parts.add(line);
        }
        return '($pjs) => { ${parts.join('\n')} }';
      }
      throw const FormatException('不支持的事件闭包体');
    }
    // 方法 / 字段 / widget 成员引用（`onTap: _tap` / `onTap: widget.onTap` /
    // `onTap: onTap`）：触发时把实参原样转发（多参事件 onChanged / onReorder）。
    final ref = _eventRef(e);
    if (ref != null) return '(...__a) => $ref(...__a)';
    // 其余表达式形态：整体求值，无参。
    return '(...__a) => (${eventExpr(e)})';
  }

  /// 事件表达式里的闭包形参名（`(v) => ...` 的 `v`）。
  List<String> _closureParamNames(FunctionExpression fn) {
    final out = <String>[];
    for (final p in fn.parameters?.parameters ?? const <FormalParameter>[]) {
      final name = p is DefaultFormalParameter
          ? p.parameter.name?.lexeme
          : p.name?.lexeme;
      if (name != null && name.isNotEmpty) out.add(name);
    }
    return out;
  }

  /// 「可调用引用」形态（`onTap: _tap` / `widget.onTap` / 字段回调 `onTap`）
  /// → JS 成员引用（实例成员 `this.<name>`、静态方法 `<类名>.<name>`）；
  /// 非引用形态返回 null。
  String? _eventRef(Expression e) {
    final String name;
    if (e is SimpleIdentifier) {
      name = e.name;
    } else {
      final wm = widgetMemberName(e);
      if (wm == null) return null;
      name = wm;
    }
    if (staticMethodNames.contains(name) && className != null) {
      return '$className.$name';
    }
    final prop = propByField[name];
    if (prop != null) return 'this.$prop';
    if (methodNames.contains(name)) return 'this.$name';
    final event = actionByMethod[name];
    if (event != null) return 'this.$event';
    return null;
  }

  /// `setState(() {...})` / `setState(() => _x = v)` → `this.setState(() => {...})`。
  ///
  /// 闭包体走统一的语句/表达式翻译（状态字段 → `this.<field>`，与普通方法体
  /// 同一套作用域），翻译失败即抛错（由调用方决定丢弃或告警）。
  String _setStateCallJs(MethodInvocation call, FieldScope scope) {
    final args = call.argumentList.arguments;
    final fn = args.isNotEmpty ? args.first : null;
    if (fn is! FunctionExpression) {
      throw const FormatException('setState 需要函数实参');
    }
    final body = fn.body;
    String bodyJs;
    if (body is ExpressionFunctionBody) {
      // 箭头体通常是「赋值 / 自增 / 方法调用」语句（`() => _tab = t`）——走语句级
      // 翻译（赋值/自增由 [exprStmtToJs] 处理，纯表达式回退到 [exprToJs]）。
      final stmt = exprStmtToJs(body.expression, scope, const {});
      if (stmt != null) {
        bodyJs = '  $stmt';
      } else {
        final v = exprToJs(body.expression, scope, const {});
        if (v == null) {
          throw FormatException(
            'setState 闭包体无法翻译：${body.expression.toSource()}',
          );
        }
        bodyJs = '  $v;';
      }
    } else if (body is BlockFunctionBody) {
      bodyJs = translateStmtList(
        body.block.statements,
        scope,
        const {},
        null,
        depth: 1,
        returnsWidget: false,
      );
    } else {
      throw const FormatException('不支持的 setState 闭包体');
    }
    return 'this.setState(() => {\n$bodyJs\n})';
  }

  /// 事件参数列表翻译：逐参数走 [jsDataExpr]（字符串/字段/局部变量/字面量）。
  ///
  /// 作用域用 [_eventScope]（或调方传入的事件闭包作用域）：实参里的 `context`
  /// 照常翻译成 `this.context`（运行时按**执行位置**解析到对应代理），形参与
  /// 调用点一一对应，不做剔除。
  String _eventArgsJs(ArgumentList args, FieldScope scope) {
    final out = <String>[];
    for (final a in args.arguments) {
      if (a is NamedExpression) {
        out.add(jsDataExpr(a.expression, scope));
      } else {
        out.add(jsDataExpr(a, scope));
      }
    }
    return out.join(', ');
  }

  /// 事件表达式里的**顶层** `@HostInjected` 函数调用 → `_app_host_.invoke`。
  ///
  /// 类上的宿主方法是普通 JS 类方法（调用点与 Dart 一比一），只有顶层函数没有
  /// JS 载体，才需要在这里改写成宿主通道调用。[hostFunctions] 与数据表达式翻译
  /// 共用同一份集合，未命中返回 null。
  /// 位置 / 具名实参分开传，宿主侧用 `Function.apply` 还原 Dart 调用语义。
  String? _hostFunctionCallJs(
    String method,
    ArgumentList args,
    FieldScope scope,
  ) {
    if (!hostFunctions.contains(method)) return null;
    final pos = <String>[];
    final named = <String>[];
    for (final a in args.arguments) {
      // 形参与调用点一一对应，不做任何剔除（`context` → `this.context`，
      // 见 [_eventScope]：事件闭包里按执行位置解析）。
      if (a is NamedExpression) {
        named.add(
          '${jsString(a.name.label.name)}: '
          '${jsDataExpr(a.expression, scope)}',
        );
      } else {
        pos.add(jsDataExpr(a, scope));
      }
    }
    return '_app_host_.invoke(${jsString(method)}, '
        '${hostArgsJs(pos, named)})';
  }

  /// 数据表达式 → JS 表达式。
  ///
  /// 委托给**唯一**的表达式翻译器 [rhsToJs]（组件数据表达式与模型方法体、
  /// 语句翻译共用同一套语法支持——新增语法只改那一处），只是把作用域换成
  /// 组件侧：状态字段（[propByField]）+ 循环变量 + build 局部变量 + 组件方法。
  /// 无法翻译即抛错（组件数据绑定不允许静默丢表达式）。
  ///
  /// [scope] 可覆盖默认的组件数据作用域：事件路径传 [_eventScope]，把 `context`
  /// 落到 `this.context`（事件串在运行时隔离求值，看不见 build 形参，裸 `context`
  /// 必然 ReferenceError）。运行时 `this.context` 按**执行位置**解析——被委托的
  /// builder 方法里取的是**被委托组件**的代理，与 Dart 闭包捕获 `context` 形参同语义。
  String jsDataExpr(Expression e, [FieldScope? scope]) {
    return withExprRenderer(() {
      final js = rhsToJs(e, scope ?? _dataScope(), const {});
      if (js == null) {
        throw FormatException('文本内容只支持字符串/插值/状态字段/模型属性/三目，不支持 ${e.toSource()}');
      }
      return js;
    });
  }

  /// 把本渲染器发布给表达式翻译器，在这段作用域内翻译代码：任意表达式位置的
  /// 构造（含闭包体内的 `return Row(...)` / `var x = Container(...)`）都走属性
  /// 管线，与 children 里的子结点同一条路径（属性归一 + 类所在文件登记
  /// import）；同时静态成员调用（`Overlay.of(context)`）按「receiver 的类定义
  /// 在哪」解析成类引用。
  ///
  /// 翻译器是自由函数 + 单线程，拿不到渲染器实例，只能在这段作用域内发布出去
  /// （见 js_translator 的 `constructionHook` / `classRefHook`）。**唯一入口**：
  /// 数据表达式、函数值、整个类的方法体都用它，不按类角色 / 返回类型分支。
  T withExprRenderer<T>(T Function() body) {
    final prev = constructionHook;
    final prevClassRef = classRefHook;
    final prevSymbolRef = symbolRefHook;
    constructionHook = _constructionJs;
    classRefHook = _classRefJs;
    symbolRefHook = _symbolRefJs;
    try {
      return body();
    } finally {
      constructionHook = prev;
      classRefHook = prevClassRef;
      symbolRefHook = prevSymbolRef;
    }
  }

  /// 静态常量 / 枚举常量引用（`IndicatorResult.success` / `Colors.red`）的
  /// owner → 登记 import。
  ///
  /// 枚举不进类索引、值位置也不经过 [classRefHook]（那只覆盖 `X.m(...)`），所以
  /// 只能在真实引用点登记：归属按 [importedOwnerPackageOf]（枚举声明所在包 ∩
  /// 当前文件 import 的包集合）消歧；SDK / 项目类 / 顶层常量不命中三方模块，
  /// 仍走各自既有路径。
  ///
  /// 「Dart 包里有这个枚举」不等于「宿主模块导出了它」（get 包声明了 `Transition`
  /// 枚举，但 `js/get.js` 并未导出）：导入前按 [thirdPartyJsExports] 校验模块实际
  /// 导出，缺失时保留裸引用并出声——绝不 import 一个不存在的导出（那会让整个模块
  /// 加载失败）。
  void _symbolRefJs(String owner) {
    final declared =
        CtorSignatures.instance?.enumDeclaringPackages()[owner];
    if (declared == null || declared.isEmpty) return;
    // 以 Dart 源码 import 的包为准：多个已 import 的包都声明同名枚举时，
    // Dart 源码本身必须靠前缀 / show-hide 才能编译，这里不猜。
    final hits = declared.where(importedPackagesOf(sourcePath).contains).toSet();
    if (hits.length != 1) return;
    final pkg = hits.first;
    // 没有宿主 JS 模块的包（SDK 枚举由 flutter.js 承接，产物按
    // flutterExportTypes 文本补 import）不在这里处理。
    if (!thirdPartyJsPackages.contains(pkg)) return;
    if (!thirdPartyJsExports(pkg).contains(owner)) {
      if (_missingEnumExports.add('$pkg/$owner')) {
        log.warning(
          '[hot_patch_generator] ${sourceAt(sourcePath, null)}: 枚举 $owner 声明于 '
          '包 $pkg，但宿主 `js/$pkg.js` 未导出它；产物保留裸引用'
          '（执行到该值时会 ReferenceError）。请在 js/$pkg.js 里导出该枚举。',
        );
      }
      return;
    }
    (usedWidgetPackages[pkg] ??= <String>{}).add(owner);
  }

  /// 已告警的「三方枚举未导出」项（每个 input 只出声一次，避免刷屏）。
  final Set<String> _missingEnumExports = {};

  /// 静态成员调用的 receiver 是「类定义在某个产物模块里的类型」时 → 类引用串
  /// （并登记 import），否则 null（交给通用路径）。
  ///
  /// 与 [_constructionJs] 同一判据：[jsClassFileOf] 说明这个类型在 JS 侧确有类定义，
  /// 静态方法（`Overlay.of` / 项目类上的工厂方法）因此可以原样调用；运行时注入
  /// 的全局类（`MediaQuery` / `Theme`）没有文件归属，返回 null 由原规则承接。
  String? _classRefJs(String className) {
    // 带 import 前缀的静态引用（`p.Foo.bar`）：登记命名空间 import。
    final dot = className.indexOf('.');
    if (dot > 0) {
      final prefix = className.substring(0, dot);
      final product = prefixProducts[prefix];
      if (product != null && product.isNotEmpty) {
        namespaceImports[prefix] = product;
      }
    }
    final file = jsClassFileOf(className);
    if (file == null) return _thirdPartyValueRefJs(className);
    if (importResolver?.call(className) == null) {
      _registerWidgetImport(className, className);
    }
    return className;
  }

  /// 三方包**顶层变量**的引用（`Get.put(...)` 的 `Get`）→ 符号名并登记 import。
  ///
  /// 顶层变量不是类（[jsClassFileOf] 不命中），但它由该包的 JS 模块导出；
  /// 归属只由「变量声明文件 → 包 → 宿主 `js/` 是否有模块」判定。项目内同名值
  /// （[importResolver] 命中）优先走依赖 import，不在此处理。
  String? _thirdPartyValueRefJs(String name) {
    if (importResolver?.call(name) != null) return null;
    // 以 Dart import 的包为准（多个三方库都有同名顶层值时按源码消歧）；
    // import 未给出唯一归属时回退「声明包 ∩ 有宿主模块」的既有判据。
    final owner = importedOwnerPackageOf(name, sourcePath);
    final pkg = (owner != null &&
            thirdPartyJsPackages.contains(owner) &&
            thirdPartyJsExports(owner).contains(name))
        ? owner
        : thirdPartyValuePackageOf(name);
    if (pkg == null) return null;
    (usedWidgetPackages[pkg] ??= <String>{}).add(name);
    return name;
  }

  /// 三方模块**没有导出**该符号：出声并拒绝生成 import（导入不存在的导出会让
  /// 整个模块加载失败，比裸引用更糟）。
  void _warnMissingModuleExport(String package, String name) {
    if (!_missingModuleExports.add('$package/$name')) return;
    log.warning(
      '[hot_patch_generator] ${sourceAt(sourcePath, null)}: $name 声明于包 '
      '$package，但宿主 `js/$package.js` 未导出它；产物保留裸引用'
      '（执行到该符号时会 ReferenceError）。请在 js/$package.js 里导出它。',
    );
  }

  /// 已告警的「三方模块未导出」项（每个 input 只出声一次）。
  final Set<String> _missingModuleExports = {};

  /// 实参位置的构造表达式 → 属性管线（与 children 里的子结点同一条路径）。
  ///
  /// 只接管「JS 侧有该类定义」的类型（按类所在文件判定：项目内类有产物文件，
  /// 其余在 package 模块或运行时注入）；没有 JS 类的构造（`Duration` /
  /// `EdgeInsets` 等）保持通用构造翻译——它们本就由运行时的同名类承接。
  String? _constructionJs(Expression e) {
    if (ctorJsClassFile(e) == null) return null;
    final node = translate(e);
    if (node is! Map || node['type'] == null) return null;
    return renderValue(node, 0);
  }

  @override
  String? ctorJsClassFile(Expression e) {
    final ctor = _ctorNameOf(e);
    return ctor == null ? null : jsClassFileOf(ctor);
  }

  /// 是否确实是构造（判据与 [ctorJsClassFile] 同一个 [_ctorNameOf]）：
  /// `X.fromJson(...)` 这类**静态方法**在语法上也是 `X.member(...)`，
  /// 只有构造签名索引能区分，值翻译据此决定是否走元素属性管线。
  @override
  bool isConstruction(Expression e) => _ctorNameOf(e) != null;

  /// 名字是否是本文件的 import 前缀（`import '...' as p;` 里的 `p`）。
  ///
  /// 无 resolution 的 parseString 把 `p.Foo(...)` 解析成「target = p、
  /// 方法名 = Foo」，必须靠这张表才能把前缀还原成类型引用 `p.Foo`。
  bool isImportPrefix(String name) => prefixProducts.containsKey(name);

  /// target 是否是「import 前缀 + 类名」（`p.Foo` / `p.Foo.value` 的 target）。
  ///
  /// 只有本文件真实存在的 import 前缀才算，`widget.foo()` / `this.x()` 这类
  /// 成员访问不会因此被误判为构造。
  bool _isImportPrefixTarget(Expression? target) =>
      target is PrefixedIdentifier &&
      prefixProducts.containsKey(target.prefix.name);

  /// 类型的 JS 类定义**来自哪个产物文件**（null = JS 侧没有这个类）。
  ///
  /// 只按「类定义在哪」判断，不看它是不是组件——所有类一视同仁：
  ///   - 项目内类：按**类所在的源文件**解析出该文件的产物（[importResolver]，
  ///     含同文件类）；
  ///   - 导入前缀引用（`p.Foo`）：该前缀指向的模块产物；
  ///   - 宿主类型 / 运行时注入类 / 产物组织的代理类：类定义写在各 package
  ///     模块 `patch/<package>.js`（宿主类型归基础包 flutter）。
  String? jsClassFileOf(String type) {
    // 带 import 前缀的类型引用（`p.Foo`）：类定义就在该前缀指向的模块里。
    // `dart:` 前缀（值为空串）已知按裸名，递归判断裸名即可。
    final dot = type.indexOf('.');
    if (dot > 0) {
      final prefix = type.substring(0, dot);
      final name = type.substring(dot + 1);
      final product = prefixProducts[prefix];
      if (product != null && product.isNotEmpty) return product;
      if (product != null) return jsClassFileOf(name);
    }
    final product = importResolver?.call(type);
    if (product != null) return product;
    // 宿主 `js/<类名>.js`：`@PatchIgnore()` 的项目内类不翻译（importResolver 为
    // null），类定义由宿主手写的同名模块提供——文件名即**类名**（与
    // `js/<包名>.js` 同形，只是归属键从包名换成类名，判据同样是「JS 侧确有该
    // 导出」）。它自身没有翻译产物，因此必须先于下面的源文件产物判定。
    if (thirdPartyJsPackages.contains(type) &&
        thirdPartyJsExports(type).contains(type)) {
      return packageModulePath(type);
    }
    // 同名符号的归属以 **Dart 源码 import 的包**为准：flutter.js 与三方模块、
    // 或两个三方库都声明了同名类型时，不能按名字索引的命中顺序猜。
    // 顶层单例（`Get`）不参与：它不是类，由 [_thirdPartyValueRefJs] 承接。
    final owner = importedOwnerPackageOf(
      type,
      sourcePath,
      includeTopLevelValues: false,
    );
    if (owner != null) {
      if (owner == nodeHelperPackage) {
        // 声明在 flutter：只有 flutter.js 真的导出（宿主包装类 / 值类）时才
        // import；运行时注入类（Theme 等没有产物文件）返回 null，由裸引用承接。
        if (hostWrapperTypes.contains(type) || jsClassWidgets.contains(type)) {
          return packageModulePath(nodeHelperPackage);
        }
        return null;
      }
      if (thirdPartyJsPackages.contains(owner)) {
        if (!thirdPartyJsExports(owner).contains(type)) {
          _warnMissingModuleExport(owner, type);
          return null;
        }
        return packageModulePath(owner);
      }
      // 其它包（无宿主 JS 模块，如 cached_network_image）：回退既有判据
      // （多数是宿主注册的内建能力，归 flutter.js）。
    }
    if (hostWrapperTypes.contains(type) || jsClassWidgets.contains(type)) {
      return packageModulePath(widgetPackageOf(type));
    }
    // 三方库（provider 等）：类声明所在的包在宿主 `js/` 目录提供了 JS 模块
    // （`js/<package>.js` → `patch/packages/<package>.js`）。归属只由源码事实
    // （类声明文件 → 包 → 是否有宿主模块）判定，生成器不维护任何库/类型表。
    final thirdParty = thirdPartyPackageOf(type);
    if (thirdParty != null) return packageModulePath(thirdParty);
    return null;
  }

  /// 构造表达式（`const X(...)` / `X(...)` / `X.b(...)`）的类型名；调用形态
  /// 不是构造时返回 null。只认语法形态，不判断类型是不是组件。
  String? _ctorNameOf(Expression e) {
    final isCtor = e is InstanceCreationExpression ||
        (e is MethodInvocation &&
            (e.target == null ||
                e.target is SimpleIdentifier ||
                // `p.Foo(...)`：target 是 PrefixedIdentifier，仅当前缀确实是
                // 本文件的 import 前缀时才算构造（`widget.foo()` 等不算）。
                _isImportPrefixTarget(e.target)));
    if (!isCtor) return null;
    final (ctor, _) = ctorOf(e);
    if (ctor == null) return null;
    final factory = factoryNameOf(e, isPrefix: isImportPrefix);
    if (factory == null) return ctor;
    // `X.foo(...)` 的语法与「命名构造」完全一致，`Overlay.of(context)` 这类
    // **静态方法**也会命中，被误当成构造（产物成了 `Overlay.of({})` 元素）。
    // 判据用构造签名索引：只有 `foo` 确实是 X 声明的命名构造才算构造。
    // 源码索引不可得（类找不到）时保持既有假设，避免对无法索引的类型回归。
    final sigs = CtorSignatures.instance;
    if (sigs != null &&
        sigs.isClass(ctor) &&
        !sigs.ctorNamesOf(ctor).contains(factory)) {
      return null;
    }
    return ctor;
  }

  /// 组件侧数据作用域（文本插值 / 数据表达式 / 事件参数 / 闭包共用一份）：
  /// 状态字段 + 循环变量 + build 局部变量 + 方法形参 + 本类方法 + 顶层常量 +
  /// 宿主注入方法表 + 局部别名。
  ///
  /// 有别名（`final list = _list;` → `list → this._list`）的局部从形参表剔除：
  /// [FieldScope.fieldRef] 先查形参，若不剔除就会把 `list` 原样透传成未定义的
  /// 自由变量（懒加载 builder 抽成实例方法后尤其致命）。
  FieldScope _dataScope() => FieldScope(
    sourcePath: sourcePath,
    propByField: propByField,
    params: {
      ..._loopVars,
      ..._methodParams,
      for (final l in _locals)
        if (!_localAliases.containsKey(l)) l,
    },
    paramTypes: {
      for (final e in _localTypes.entries)
        if (_locals.contains(e.key)) e.key: e.value,
    },
    methods: {...actionByMethod.keys, ...methodNames},
    getterNames: getterNames,
    className: className,
    staticFields: staticFieldNames,
    staticMethods: staticMethodNames,
    hostFunctions: hostFunctions,
    globalConsts: globalConsts,
    localAliases: _localAliases,
  );

  /// 事件表达式作用域：在 [_dataScope] 基础上把 `context` 从形参表**剔除**、
  /// 改挂别名 `context → this.context`。
  ///
  /// 缘由：事件闭包由运行时在点击时调用，Dart 的 build 形参 `context` 不是
  /// 闭包形参；运行时 `this.context` 按**绑定时的执行位置**解析（见【10.7】与
  /// `augment` 的 context getter）：被委托的 builder 方法里取的是**被委托组件**
  /// 的代理（位于 provider 子树之内），与 Dart 闭包捕获 `context` 形参同语义；
  /// 组件自身作用域里则是 build 传参的同一代理。故改走 `this.context` 即可保持
  /// 「调用面与 Dart 一致」。
  /// [FieldScope.fieldRef] 的顺序是形参优先，因此这里必须同时把 `context`
  /// 移出 `params`，别名才会生效（否则渲染期翻译出的 `context.watch` 会占位）。
  FieldScope _eventScope() {
    final base = _dataScope();
    return FieldScope(
      sourcePath: base.sourcePath,
      propByField: base.propByField,
      instanceFields: base.instanceFields,
      params: {...base.params}..remove('context'),
      paramTypes: base.paramTypes,
      methods: base.methods,
      getterNames: base.getterNames,
      className: base.className,
      staticFields: base.staticFields,
      staticMethods: base.staticMethods,
      hostFunctions: base.hostFunctions,
      globalConsts: base.globalConsts,
      localVars: base.localVars,
      localAliases: {...base.localAliases, 'context': 'this.context'},
    );
  }

  /// 组件参数位置上的「函数值」翻译：返回 null = 不是函数形态。
  ///
  ///   - 闭包字面量（`onTap: () => ...` / `onPick: (k, v) => ...`）→ JS 箭头函数；
  ///   - 方法 tear-off（`onReset: _resetFilter` / `onReset: widget._resetFilter`）→
  ///     绑定宿主实例的箭头闭包（直接传 `this._resetFilter` 会在子组件调用时丢 this）；
  ///   - 字段型回调透传（`onTap: onTap` / `onReset: widget.onReset`）→ 原样函数值。
  /// 回调位置专用：在通用值翻译之上，额外支持「接收者成员」回调引用 /
  /// 条件表达式等**只有回调语义下才成立**的形态。值位置（`color: Colors.white`）
  /// 绝不能走这里——否则静态常量会被误包成闭包。
  String? callbackJs(Expression e) => functionJs(e, callback: true);

  String? functionJs(Expression e, {bool callback = false}) {
    if (e is FunctionExpression) {
      // 闭包体里可能 return 组件（`builder: (context, o) { ... return Row(...) }`），
      // 与 build 树走同一条管线：属性归一 + import 登记。
      final js = withExprRenderer(
        () => closureToJs(e, _dataScope(), const {}, this, true),
      );
      if (js != null) return js;
      // 通用闭包翻译翻不出的表达式（典型：闭包里是 @HostInjected 静态调用 /
      // setState 等**只有事件作用域支持**的写法）→ 用事件闭包翻译，但**仍然
      // 产出普通函数**：消费方自己决定怎么用（宿主边界再把函数换成句柄）。
      return _eventFnJs(e);
    }
    if (e is ParenthesizedExpression) {
      return functionJs(e.expression, callback: callback);
    }
    if (e is AsExpression) {
      return functionJs(e.expression, callback: callback);
    }
    if (callback && e is ConditionalExpression) {
      // 条件表达式选回调：两个分支都必须能翻译成普通函数，整体按值下发。
      final cond = rhsToJs(e.condition, _dataScope(), const {});
      final a = functionJs(e.thenExpression, callback: true);
      final b = functionJs(e.elseExpression, callback: true);
      if (cond != null && a != null && b != null) {
        return '($cond) ? ($a) : ($b)';
      }
      return null;
    }
    if (e is Identifier) {
      // `foo.onTap`（非 `widget.` 前缀）：**仅回调位置**把接收者成员视为回调引用
      // （绑定 receiver 的普通箭头闭包）。值位置必须返回 null，交给静态常量 /
      // 字段读取（`color: Colors.white` 不能被包成闭包）。
      if (callback && e is PrefixedIdentifier && widgetMemberName(e) == null) {
        final prefix = e.prefix.name;
        final scope = _dataScope();
        final String recv;
        if (prefix == 'this' || prefix == 'widget') {
          recv = 'this';
        } else if (_locals.contains(prefix) ||
            _loopVars.contains(prefix) ||
            _methodParams.contains(prefix)) {
          recv = scope.fieldRef(prefix) ?? prefix;
        } else {
          recv = scope.fieldRef(prefix) ?? 'this.$prefix';
        }
        return '(...__a) => $recv.${e.identifier.name}(...__a)';
      }
      // `widget.<name>`：State 里转发 widget 自身成员，合并类里就是实例成员。
      final name = e is PrefixedIdentifier ? widgetMemberName(e) : e.name;
      if (name == null) return null;
      // 局部可见的名字（build 局部 / 方法体局部 / 循环变量 / 闭包形参）优先于
      // 字段：它们是**值**（列表、数字…），不是回调引用，折成 `this.x` 会把
      // `Spot(id: id, tags: tags)` 里的局部列表换成同名字段（数据全丢）。
      if (name != 'context' &&
          !_localAliases.containsKey(name) &&
          (_locals.contains(name) ||
              _loopVars.contains(name) ||
              _methodParams.contains(name))) {
        return null;
      }
      // getter（`list: _visiblePosts`）：JS 侧是 `get` 访问器，按值读即可；
      // 包装成调用会传出去一个函数，子组件拿到空数据。
      if (getterNames.contains(name)) return 'this.$name';
      if (staticMethodNames.contains(name) && className != null) {
        return _methodRefJs(className!, name);
      }
      if (actionByMethod.containsKey(name) || methodNames.contains(name)) {
        return _methodRefJs('this', name);
      }
      final prop = propByField[name];
      if (prop != null) return 'this.$prop';
    }
    return null;
  }

  /// 方法引用 → 绑定接收者的箭头闭包。
  ///
  /// 形参个数来自源码方法声明（[methodArity]）：
  ///   - 零参 → `() => this._insert()`（无 rest / spread）；
  ///   - N 个位置形参 → `(__a0, …) => this.m(__a0, …)`（可选位置形参按
  ///     `undefined` 传入，与 Dart 缺省值在 JS 侧的语义一致）；
  ///   - 含具名形参（或 arity 不可得）→ `(...__a) => this.m(...__a)`。
  String _methodRefJs(String recv, String name) {
    final arity = methodArity[name];
    if (arity == null) return '(...__a) => $recv.$name(...__a)';
    final args = [for (var i = 0; i < arity; i++) '__a$i'];
    return '(${args.join(', ')}) => $recv.$name(${args.join(', ')})';
  }

  /// 方法 tear-off 或 `() => _inc()` 内部的方法调用表达式
  Expression? functionInner(FunctionExpression fn) {
    final body = fn.body;
    if (body is ExpressionFunctionBody) return body.expression;
    if (body is BlockFunctionBody) {
      for (final s in body.block.statements) {
        if (s is ExpressionStatement) return s.expression;
      }
    }
    return null;
  }

  /// 把 toJson 产物的值序列化为 JS 源码（构造调用树）。
  ///
  /// 值约定：toJson 输出的叶子值一律为 **JS 表达式字符串**（字符串字面量
  /// 用 [jsString] 带引号、数字/布尔/表达式原样），这里原样嵌入、不加引号。
  ///
  /// 容器：带结点标记 [nodeMarkerKey] 的 Map → 视作**结点**，递归 [renderJs]
  /// 产出构造调用（如 `Text(...)`）——props 里嵌套的节点（如 ListTile.leading）
  /// 据此还原；普通 Map/List → 递归容器。
  String jsLiteral(Object? value, int depth) => _jsLiteral(value, depth) ?? 'null';

  /// [jsLiteral] 的可失败版本：失败（含子结点渲染失败）→ null，
  /// 容器里据此**丢弃该项/该键**，绝不伪造元素填充。
  String? _jsLiteral(Object? value, int depth) {
    if (value is Map) {
      if (_isNodeMap(value)) {
        return renderJs(Map<String, dynamic>.from(value), depth);
      }
      if (value.isEmpty) return '{}';
      final ind = '  ' * depth;
      final ind2 = '  ' * (depth + 1);
      final parts = <String>[];
      for (final e in value.entries) {
        final v = _jsLiteral(e.value, depth + 1);
        if (v == null) continue;
        parts.add('"${e.key}": $v');
      }
      if (parts.isEmpty) return '{}';
      return '{\n$ind2${parts.join(',\n$ind2')}\n$ind}';
    }
    if (value is List) {
      final ind = '  ' * depth;
      final ind2 = '  ' * (depth + 1);
      final parts = <String>[];
      for (final v in value) {
        final s = _jsLiteral(v, depth + 1);
        if (s == null) continue;
        parts.add(s);
      }
      if (parts.isEmpty) return '[]';
      return '[\n$ind2${parts.join(',\n$ind2')}\n$ind]';
    }
    if (value == null) return 'null';
    // 叶子值 = JS 表达式字符串（已带引号的字符串 / 数字 / 表达式）
    final s = value.toString();
    if (!s.contains('\n')) return s;
    // 多行表达式（三元分支里的子结点、IIFE、节点构造）：**保留换行**，按当前
    // 缩进重排。压成单行会让 `this.__k2 = new Center({...})` 这类嵌套结点的
    // props 连成几百字符的一行，产物不可读、问题难定位。
    return _reindentMultiline(s, depth);
  }

  /// 把内嵌的多行表达式按 [depth] 重排缩进：
  /// 去掉各行公共缩进，再统一加上 `2*depth` 个空格；空行保持为空。
  static String _reindentMultiline(String s, int depth) {
    final lines = s.split('\n');
    var minIndent = -1;
    for (var i = 1; i < lines.length; i++) {
      final line = lines[i];
      if (line.trim().isEmpty) continue;
      final n = line.length - line.trimLeft().length;
      if (minIndent < 0 || n < minIndent) minIndent = n;
    }
    if (minIndent < 0) minIndent = 0;
    final indent = '  ' * depth;
    final b = StringBuffer(lines.first);
    for (var i = 1; i < lines.length; i++) {
      final line = lines[i];
      if (line.trim().isEmpty) {
        b.write('\n');
      } else {
        b.write('\n$indent${line.substring(minIndent)}');
      }
    }
    return b.toString();
  }

  /// 判断一个 Map 是「元素结点」还是「普通 props / args 容器」。
  ///
  /// 判据是结点生产者 [elementToJson] 打的**显式标记** [nodeMarkerKey]——
  /// 所有类一视同仁，不做任何结构猜测：props 里 `Foo(type: _type)` 这类普通容器
  /// 与结点同形（都可能有 `type` 键），按键集合 / 引号形态猜必然误判。
  static bool _isNodeMap(Map value) => value[nodeMarkerKey] == true;

  /// 生成 JS 双引号字符串字面量（委托 [jsStringLiteral]，与 js_translator 共用唯一实现）。
  String jsString(String s) => jsStringLiteral(s);

  ElementNode _toNode(Expression e) {
    final (ctor, args) = ctorOf(e);
    if (ctor == null) {
      throw FormatException('不支持的 UI 表达式: ${e.toSource()}');
    }
    return ElementNode(ctor, args, expr: e);
  }
}

// ---------------------------------------------------------------------------
// 单叶子失败的处理：丢弃该结点 + 构建期告警（不伪造元素）
//
// 原行为：build() 树里**任意一个叶子表达式**抛 FormatException 会一路冒泡，
// 最终让 `_widgetExprToJs` 返回 null，整棵 `return Column(...)` 被丢弃 → 页面
// 退化成空 build。现在把兜底放在每一次 [ElementTranslateContext.translate] /
// [translateElement] / [renderJs] 递归调用上：坏叶子只丢自己，兄弟结点与上层
// 结点照常产出，同时打印构建期告警（不静默）。
//
// **绝不产出 `SizedBox()` 之类的占位元素**：那会把「翻译失败」伪装成「渲染
// 成功的空盒子」——`where((o) => ...)` / `sort((a, b) => ...)` 编译成空盒子后
// 谓词恒假、比较器恒 0，产物里看不出任何异常，属于最坏的一类静默错误。
// 失败即「没有这个结点」：children 里少一项、单子位置是 null。
// ---------------------------------------------------------------------------

/// 构建期告警：出声（不静默丢代码），但不再抛错连累兄弟结点。
///
/// [json] 是元素的中间态描述：按身份取回来源 AST 结点，日志带上
/// `文件:行 | 源码行`，否则只能靠函数名猜位置。
void _warnDegrade(
  String sourcePath,
  String what,
  Object? json,
  Object err, {
  AstNode? node,
}) {
  final where = sourceAt(sourcePath, node ?? nodeSourceOf(json));
  log.warning(
    '[hot_patch_generator] $where: '
    '$what 无法翻译，已丢弃该结点：${json.toString()}（$err）',
  );
}

/// 名字是否形如**类名**：跳过前导下划线后首字母大写。
///
/// `Image` / `_OrderCard`（私有组件类）是类名；`_model` / `context` / `build`
/// 是实例成员。用于区分「组件构造」与「实例方法调用」等语法形态，与 widget
/// 类型无关。翻译层多处共用这一份判定（不得各自复制）。
bool isClassName(String name) {
  var n = name;
  while (n.startsWith('_')) {
    n = n.substring(1);
  }
  return n.isNotEmpty && n[0] == n[0].toUpperCase();
}

/// 收集表达式里出现的简单标识符名——[ElementTranslateContext.warnCapturedLocals]
/// 的构建期抽查用。
///
/// 成员名（`a.b` 里的 `b`）也会被收进来，误报面由「名字必须是**本类**的方法体
/// 局部变量 / 循环变量」这条过滤限制住；`Label`（具名实参名 / 语句标签）不是
/// 变量引用，单独排除。
class _SimpleIdentifierCollector extends RecursiveAstVisitor<void> {
  _SimpleIdentifierCollector(this.names);

  /// 名字 → 首次出现的结点（构建期告警定位用）。
  final Map<String, SimpleIdentifier> names;

  @override
  void visitSimpleIdentifier(SimpleIdentifier node) {
    // 只收**变量引用**。名字位置的标识符不是变量：具名实参 / 语句标签
    //（`Divider(height: 1)` 的 `height`）、成员名（`Icons.height` 的 `height`）、
    // 命名构造名（`Foo.named` 的 `named`）、带接收者的方法名（`a.build()`）。
    // 把它们当变量收集会误报「builder 捕获了方法体局部变量」——只要同名局部
    // 变量在别的方法里出现过（如 `_measureFixed` 的 `height`）。
    if (_isNamePosition(node)) return;
    names.putIfAbsent(node.name, () => node);
  }

  /// [node] 是否处于「名字」位置而非「变量引用」位置。
  static bool _isNamePosition(SimpleIdentifier node) {
    final parent = node.parent;
    if (parent is Label) return true;
    if (parent is PrefixedIdentifier) {
      return identical(parent.identifier, node);
    }
    if (parent is PropertyAccess) {
      return identical(parent.propertyName, node);
    }
    if (parent is ConstructorName) {
      return identical(parent.name, node);
    }
    // `a.foo()` 的 `foo` 是成员名；无接收者的 `foo()` 仍可能是局部闭包变量。
    if (parent is MethodInvocation) {
      return identical(parent.methodName, node) && parent.target != null;
    }
    return false;
  }
}
