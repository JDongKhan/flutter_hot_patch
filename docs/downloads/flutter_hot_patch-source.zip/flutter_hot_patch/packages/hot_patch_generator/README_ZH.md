# hot_patch_generator（简体中文）

[English](https://github.com/JDongKhan/flutter_hot_patch/blob/main/packages/hot_patch_generator/README.md)

构建期把带 `@PatchEntry` 注解的 Flutter widget **静态翻译**为 JS 模块，
供 `hot_patch` 运行时热更渲染。

全程使用 `analyzer` 静态解析源码，**不执行任何 Dart 代码**，也不要求组件做任何改造：
被翻译的类始终是一个完全正常的 Flutter widget。

## 安装

```yaml
dev_dependencies:
  hot_patch_generator: ^0.13.0
  build_runner: ^2.4.13
```

然后在项目根目录运行：

```sh
dart run build_runner build --delete-conflicting-outputs
```

## 产物

产物目录 `patch/` 与 `lib/` 源码路径**一一对应**，文件名与 Dart 源文件同名：

| 源码 | 产物 | 说明 |
| --- | --- | --- |
| `lib/components/counter.dart` | `patch/components/counter.js` | 含 `@PatchEntry` 的组件产物 |
| `lib/model/user.dart` | `patch/model/user.js` | 普通类 / 静态单例（`export class` / `export const`） |
| （包根伪资产 `$package$`） | `patch/flutter.js` | package 模块：`Component` 基类 + 宿主 widget 包装类 + 值类 + JS 逻辑组件 / builder 代理类，**每个 package 一个文件** |
| `js/<package>.js`（宿主维护的三方 JS） | `patch/packages/<package>.js` | 三方库 JS 由宿主放在工程根 `js/` 下（文件名 = Dart 包名），`ui_third_party_js` 按文件系统扫描原样拷贝（无需改 `build.yaml`）；业务产物按 `../packages/<package>.js` import |
| （包根伪资产 `$package$`） | `patch/runtime.js` | 整个 JS 运行时（mini-react / 句柄表 / 各能力片段）**一个文件**，分区用 `// ===== 【n】… =====` 注释隔开。随补丁发布，JS 修复无需发版；内容哈希写进 `G.__jsuiVersion`，哈希变化即原地重建运行时 |
| （包根伪资产 `$package$`） | `patch/manifest.json` | patch 清单：基本信息 + **产物协议版本**（`protocol`，当前 `0.13.0`）+ 打包时间 + 各 JS 资源的内容 hash。运行时拒绝载荷**主版本**与应用不匹配的包 |
| （包根伪资产 `$package$`） | `patch/patch.zip` | 补丁归档：`patch/` 下全部文件（生成的 JS + `manifest.json` + 手工放置的静态资源，如 `patch/assets/...`）；排在 `ui_patch_manifest` 之后打包，zip 里始终是最新清单 |

- 按**文件内容 + 引用可达性**分流（与目录无关）：含 `@PatchEntry` 的文件是根文件，产出这些组件；
  否则只有**真的被可达类引用到**的类才产出（模型 / 单例产物，`export class` / `export const`）；
  只有顶层常量的文件产出这些常量；既不可达也未被引用的文件不产出。
- package 级模块（`patch/<package>.js`）与清单都挂在包根伪资产 `$package$` 下：
  输入是整包、输出路径静态，**使用方无需任何种子文件或配置**——依赖本包并跑
  `build_runner` 即可产出。
- `patch/flutter.js` 定义 `Component` 基类，并为主机 widget（`Text`、`Column` …）与数据载体
  （`InputDecoration`）生成**同名包装类**：组件产物统一写 `new Text({...})`，包装类实例自身
  就是宿主元素（`__host=true`），props 由基类构造期拆成 `props` / `__children`。其它模块按需
  import 用到的类。用户代码 `new X(props)` 得到的就是元素；值对象里的嵌套 Widget 由
  `__descriptorOf` 归一化为元素描述。

示例 App 的实际产物（生成的 JS 文件）可在线查看：
[example/patch/](https://github.com/JDongKhan/flutter_hot_patch/tree/main/example/patch)。

> 注意：Flutter 的目录 asset 声明**不递归**，需在 `pubspec.yaml` 的 `assets:`
> 里逐目录（或逐文件）显式声明产物路径。

## 配置

`ui_widget`（package 模块）、`ui_runtime`（JS 运行时）、`patch_entry`（组件/模型产物）与
`ui_patch_archive`（`patch/patch.zip` 归档）**不读任何 options**。
其余两个 builder 的选项均为可选，缺省即开箱可用：

```yaml
targets:
  $default:
    builders:
      # 宿主注入注册产物（lib/generated/host_methods.dart）的目标运行时；
      # 仅当换用别的运行时实现时才需要覆盖。
      hot_patch_generator:ui_host_register:
        options:
          register_import: "package:<runtime>/<runtime>.dart"
          register_call: "<Runtime>.registerHostMethod"
      # patch/manifest.json 里的基本信息；缺省取包名 / 省略版本。
      hot_patch_generator:ui_patch_manifest:
        options:
          name: my_app
          version: 1.2.3
```

## 翻译设计原则

翻译产物必须与 Dart 源码**一比一对应**，这是本框架的核心约束：

1. **Dart 合法写法应被静态翻译，而不是绕开**。遇到不认识的语法形态，补正式翻译分支（表达式/语句翻译在 `translator/js_translator.dart`，类声明渲染在 `translator/dart2js.dart`，都一比一映射成等价 JS），**不要求用户改 Dart 写法来适配框架**。当前未覆盖的写法会在构建期告警并降级为占位结点；占位是**诊断兜底，不是长期方案**（见组件支持文档「已知限制」）。所有翻译只有一处实现，组件与普通类共用。
2. **禁止临时方案**。报错时不得在 demo 里加临时字段/中间层绕过（如为规避 setState 无 diff 而加的镜像触发字段）；产物 JS 应与 Dart 写法逐行对应，修就修翻译路径本身。
3. **能力按文件隔离**。新增运行时能力（如 ScrollController / TextEditingController id-bridge）时，宿主侧按能力放 `hot_patch/lib/src/js_ui/capabilities/` 独立文件，**不动 `js_widget_registry` / `js_ui_widget` 核心**；该能力的 JS 放本包 `builders/core_js_builder/js/runtime/`，随 `patch/runtime.js` 发布（JS 修复无需发版）。
4. **默认值与 Flutter 百分百一致**。宿主渲染时 nullable 属性缺省保持 `null`，不得默认成 `0` / `EdgeInsets.zero` 等覆盖 Flutter 主题默认。
5. **注册 key 与类名一致**。宿主 `r.register('X', ...)` 的 key 与产物 JS 里的 type 字符串保持同名，不另起别名。

## 扩展：新增 widget 支持

**没有 per-widget 的 translator**：内建、自定义、三方组件全部走同一条翻译路径
（`lib/src/builders/patch_entry/translator/element_json.dart`），分派依据只有两项：

- **产物协议**：build 树统一发射 `new Type(props)`。宿主 widget / 数据载体用 `flutter.js` 导出的
  同名包装类；自定义组件、逻辑组件与 builder 代理用各自产物导出的类。所有 Dart 实参按原名进
  props；`child` / `children` / `slivers` / `tabs` 都是**普通具名 props**，由宿主包装类在构造期
  经 `Component.__splitHost` 按**值形态**拆分——元素值 / 元素数组 / `__builder` / delegate 描述
  按原名移入 `__children`，与键名无关；
- **构造即元素**：生成类按普通类语义构造（`new X(props)` 即元素实例，带 `__element` / `__type`；
  宿主包装类写入 `__host=true`）；reconciler 只认 `__element`，不按原型上有没有 `build` 猜组件。
  值对象里的嵌套 Widget 由 `__descriptorOf` 归一化为元素描述。翻译层因此不再判断“这个类是不是
  widget”，只排除已知模型类与值对象；
- **值的形态**（`lib/src/builders/patch_entry/translator/value_forms.dart`）：字面量、构造、静态工厂、常量引用
  （枚举 / 颜色 / 图标）、列表、闭包——结构化样式的运行时值类在
  `lib/src/builders/core_js_builder/js/flutter/style_values_js.dart`。

翻译路径本身**无需 per-widget 代码**，但宿主侧仍需为该 widget 注册 renderer
（`JsWidgetRegistry` 或能力库），因为 Flutter widget 必须被重新构造；
若产物形态不同，还要调整 `lib/src/builders/shared/js_class_defs.dart` 的登记表：

| 表 | 用途 |
|---|---|
| `hostWidgetTypes` | 构建期从运行时源码自动抽取（`hot_patch/lib/src/js_ui/**` 的 `r.register('X', …)`）；决定 `flutter.js` 生成哪些宿主包装类、产物 import 哪些类名。生成器不维护组件表。值对象（装饰 / 条目等）不在此列，它们在 `flutter.js` 值类区是普通类 |
| `builderFormTypes` | 有 `.builder` / `.separated` 命名构造的类型；为它们生成 JS 代理类（运行时只认 `factory` / `__delegate` 协议，不再有类型白名单） |
| `lazyChildHostTypes` | 懒容器类型 → 触发懒的 props 键（空 = 无条件懒）。只作用于**生成包装类**：生成期写入 `flutter.js`（包装类 `static __lazy` / `Component.host` 的 lazyRule），由 `Component.__splitHost` 在构造期打 `lazyChildren` 标记；运行时只认元素标记、不认识类型。只适用于「子项尺寸由容器强制」的容器（分页 / 网格 / sliver 定高列表）；业务自维护的 `js/<package>.js` 类直接写 `static __lazy`，不受本表影响 |
| `pullChildHostTypes` | 子项由**宿主按槽位同步拉取**的容器（当前为 `ListView`）。生成期在 builder 代理里写 `p.__pullItems = true`，运行时折算成 `props.__pullItems = {id, count, sep}`；容器不展开子项，宿主 `ListView.builder` / `.separated` 的 itemBuilder 在布局到该 index 时调 `__jsui.pullSlot`。子项高度由宿主真实测量，因此按内容自适应高度的列表也能懒、不需要 `itemExtent` |

位置实参按**源码构造签名**自动抽取形参名（`shared/ctor_signatures.dart`）：`Text('hi')` → `{data: 'hi'}`、
`Image.network(url)` → `{src: url}`。不维护任何按类型的登记表；签名索引不到时构建期告警并丢弃该结点
（不再有 `$pos` 下标兜底）。

因此接入一个**视觉** widget 会触及两侧：宿主 renderer，以及（当产物形态不同时）上面的生成器登记表。

命名构造 / 静态工厂的名字会保留在产物里，运行时据此**按类型选工厂**：`ListView.builder` →
`{factory: 'builder', itemBuilder: …}`、`ListView.separated` → `{factory: 'separated', itemBuilder: …,
separatorBuilder: …}`、`Image.network` → `{factory: 'network', src: …}`、
`ChangeNotifierProvider.value` → `{factory: 'value', …}`。回调 / 尺寸 / 计数一律保留 Dart 形参名
（`itemBuilder` / `separatorBuilder` / `itemCount`）。

宿主没有对应 renderer 的 widget 不会被静默丢弃：产物保留其**具体类型名**，运行时由宿主
`jsWidgetRegistry.register(name, build)` 解析。回调收到完整的 `JsRenderContext`
（`props` + `children` slot + `invoke`），原生实现可以渲染子组件并把事件回传到 JS。

## 代码结构

本包按功能分目录组织（`lib/src/` 下），依赖单向无环：

| 目录 / 文件 | 作用 |
| --- | --- |
| `lib/builder.dart` | **对外入口**：`build.yaml` 的八个 builder 工厂函数 |
| `lib/src/builders/shared/` | 多 builder 共用的基础 |
| `lib/src/builders/patch_entry/` | `componentBuilder` 全链路：收集（`analysis/`）+ 翻译（`translator/`）+ 产物组装 |
| `lib/src/builders/ui_widget/`、`ui_host_register/`、`ui_patch_manifest/` | 每个 builder 一个目录 |

```
shared/  ←  patch_entry/{analysis,translator}  ←  builder.dart
```

`builders/shared/`：`source_index`（注解识别 / import 源解析）· `host_injected`（@HostInjected 识别 / 通道名 / 顶层宿主函数）·
`js_class_defs`（`nodeHelperPackage` / `packageModulePath` / widget 类型登记表）· `paths`（产物路径推导）。

`builders/patch_entry/`——只服务 `componentBuilder`：

- `component_builder`：收集本文件根类并统一调 `translateClass`，再把结果拼装为同名 JS 产物；
- `class_info`：收集与翻译共用的中立类模型；
- `analysis/`：`analyze_dart_class`（唯一收集入口）· `class_table` · `component_scope` ·
  `const_support` · `singleton_support` · `imported_components`；
- `translator/`：`js_translator`（公共语言层）· `js_value`（共享值工具）· `dart2js`（类声明）·
  `element2js`（widget 树）· `element_json`（统一翻译入口 `elementToJson`）· `value_forms`（值形态分派
  `autoValue`）。结构化样式值由 `builders/core_js_builder/js/flutter/style_values_js.dart` 生成到 `flutter.js`。

其余 builder 各自独立：

- `ui_widget/`：`widget_module_builder`（package 模块产物 + 各逻辑组件/sliver 代理的 JS 类源码，仅本
  builder 使用）
- `core_js_builder/`：`core_js_builder`（把 `js/runtime/` 的框架代码拼成 `patch/runtime.js`；
  `js/flutter/` 下的 Flutter SDK JS 面由 `ui_widget` 拼成 `patch/flutter.js`。运行时包只负责加载，
  JS 修复随补丁发布、无需发版；产区分区以 `// ===== 【n】… =====` 注释隔开）
- `ui_host_register/`：`host_register_builder`（宿主侧注册清单生成；@HostInjected 的识别口径在
  `builders/shared/host_injected.dart`）
- `ui_patch_manifest/`：`patch_manifest_builder`（产出 `patch/manifest.json`；靠
  `required_inputs: [".js"]` 排到 `patch_entry` / `ui_widget` 之后的阶段，用
  `findAssets('patch/**.js')` 列出全部 JS 产物逐个算 hash）
- `ui_patch_archive/`：`patch_archive_builder`（产出 `patch/patch.zip`；靠
  `required_inputs: [".json"]` 排到 `ui_patch_manifest` 之后，把 `patch/` 下的生成产物与静态资源
  一起打成归档）

框架的其它包：

| 包 | 作用 |
| --- | --- |
| `hot_patch_annotations` | 声明式注解 |
| `hot_patch_generator` | **本包**：`build.yaml` + 工厂入口 + 翻译/构建实现 |
| `hot_patch` | 运行时加载 JS 补丁渲染组件，由 JS 驱动逻辑 |

使用方只需在 `dev_dependencies` 里依赖 `hot_patch_generator`。

## License

MIT
