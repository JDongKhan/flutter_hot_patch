#!/bin/bash
# 去掉网页下载附加的 quarantine 属性后启动（App 为 ad-hoc 签名，未做 Apple 公证）。
cd "$(dirname "$0")" || exit 1
xattr -dr com.apple.quarantine flutter_hot.app 2>/dev/null
open flutter_hot.app
